JARVIS OFFLINE - PATCH v3.1
============================

NOVITA' rispetto alla v3:
  - voice_offline.py PATCHATO:
    * Selezione voce italiana migliorata (Cosimo/Elsa/Bianca/Carla/Luca > eSpeak)
    * Mappa pronuncia per nomi stranieri (kid yugi -> chid iughi, spotify -> spotifài,
      youtube -> iutùb, ecc.) cosi' la voce italiana li dice giusti
    * Rate auto-adattato (eSpeak piu' lento di SAPI)
    * Rimosso print "[stt] in ascolto..." ad ogni ciclo (sporcava i log)
  - Dizionario STT ENORME: aggiunte 100+ canzoni famose (Gilgamesh di Kid Yugi,
    Cenere, Tuta Gold, Sicko Mode, Bad Guy, Casa Mia, Tokyo Drift, ...)
  - Tutti gli artisti italiani principali del rap 2023-2025 piu' i big USA

Cosa cambia (ricap dalla v3):

1) WAKE WORD OBBLIGATORIO E SILENZIOSO
   - Jarvis NON stampa nulla finche' non senti "jarvis"
   - Varianti accettate: "jarvis", "ehi jarvis", "gia' jarvis", "hey jarvis",
     "ok jarvis", "okay jarvis", e tutti gli errori comuni di Vosk

2) DIZIONARIO STT
   - Artisti italiani: Kid Yugi (10+ varianti), Lazza, Geolier, Marracash, Tedua,
     Sfera Ebbasta, Mahmood, Ghali, Shiva, Paky, Bresh, Tony Effe, Massimo Pericolo,
     Salmo, Capo Plaza, Anna, Madame, Ernia, Achille Lauro, Sangiovanni, Blanco
   - Artisti internazionali: The Weeknd, Drake, Travis Scott, Kendrick Lamar,
     Eminem, Kanye West, Billie Eilish, Post Malone
   - Canzoni: Il Filmografo, Gilgamesh, Cremlino, Atena, Neon, Bottiglie Prive,
     Cenere, Tuta Gold, Sesso e Samba, Casa Mia, Tokyo Drift, Sicko Mode, ...
   - App / Brand: chrome (cromo/crome), firefox, youtube, whatsapp, telegram,
     discord, visual studio code, notepad
   - Comandi base: mettici/mettimi/mettere -> metti, paolo sa -> pausa,
     ridotti -> riproduci, errori comuni su play/spotify

3) PRONUNCIA TTS IT
   La voce italiana ora pronuncia bene anche i nomi stranieri:
     - "kid yugi" letto come "chid iughi"
     - "spotify" letto come "spotifai"
     - "youtube" letto come "iutub"
     - "the weeknd" letto come "de uiken"
   Il TESTO STAMPATO resta corretto (solo la sintesi vocale viene "tradotta").

4) FILTRO RUMORE
   Frasi spazzatura ("piste riprendi", "abbracciarlo mense", "woolrich",
   "dopo", "boh", parole singole < 4 lettere) scartate prima del wake-word
   check, cosi' non sporcano i log.

----------------------------------------------------------------------
FILE INCLUSI IN QUESTO ZIP
----------------------------------------------------------------------

- jarvis_offline.py            (main loop - wake-word obbligatorio silenzioso)
- ai_brain_enhanced.py         (cervello + correttore STT 100+ regole)
- voice_offline.py             (TTS + STT - voce italiana + pronuncia)
- local_ai.py                  (Ollama + 50+ canzoni note nel contesto)
- system_actions_enhanced.py   (invariato)
- spotify_api.py               (invariato)
- README_v3.1.txt              (questo file)

Sostituiscili nella cartella del progetto Jarvis sovrascrivendo i precedenti.

----------------------------------------------------------------------
SUGGERIMENTO TTS PROFESSIONALE (opzionale)
----------------------------------------------------------------------
Se vuoi una voce italiana MOLTO piu' naturale, installa Piper TTS:
    https://github.com/rhasspy/piper
Modello consigliato: it_IT-paola-medium oppure it_IT-riccardo-x_low.
Si integra bene con pyttsx3 sostituendo l'engine init nella funzione _init_tts_engine().
