"""App finder POTENZIATO - Trova, lancia e chiude applicazioni Windows."""
import os
import re
import json
import subprocess
import platform
from pathlib import Path
from typing import Optional, Tuple, List
import config

CACHE_FILE = config.ROOT / "apps_cache.json"

def _scan_apps() -> dict:
    """Scansiona le app installate su Windows."""
    apps = {}
    
    if platform.system() != "Windows":
        return apps
    
    # Percorsi comuni per le app
    search_paths = [
        Path(os.environ.get("ProgramFiles", "C:\\Program Files")),
        Path(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")),
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs",
        Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    ]
    
    for base_path in search_paths:
        if not base_path.exists():
            continue
        
        try:
            for exe in base_path.rglob("*.exe"):
                if exe.is_file():
                    name = exe.stem
                    apps[name.lower()] = str(exe)
        except (PermissionError, OSError):
            continue
    
    return apps

def _load_cache() -> dict:
    """Carica la cache delle app."""
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {}

def _save_cache(apps: dict):
    """Salva la cache delle app."""
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(apps, f, ensure_ascii=False, indent=2)
    except:
        pass

def find_app(target: str, brain=None) -> Tuple[Optional[str], Optional[str]]:
    """Trova un'applicazione.
    
    Returns:
        (nome_app, comando) o (None, None) se non trovata
    """
    target_lower = target.lower().strip()
    
    # App comuni hardcoded
    common_apps = {
        "chrome": "chrome.exe",
        "google chrome": "chrome.exe",
        "firefox": "firefox.exe",
        "edge": "msedge.exe",
        "microsoft edge": "msedge.exe",
        "spotify": "spotify.exe",
        "discord": "discord.exe",
        "vscode": "code.exe",
        "visual studio code": "code.exe",
        "notepad": "notepad.exe",
        "blocco note": "notepad.exe",
        "calcolatrice": "calc.exe",
        "calculator": "calc.exe",
        "paint": "mspaint.exe",
        "word": "winword.exe",
        "excel": "excel.exe",
        "powerpoint": "powerpnt.exe",
        "outlook": "outlook.exe",
        "steam": "steam.exe",
        "vlc": "vlc.exe",
        "obs": "obs64.exe",
        "photoshop": "photoshop.exe",
    }
    
    # Match esatto
    if target_lower in common_apps:
        return (target.title(), common_apps[target_lower])
    
    # Match parziale
    for key, cmd in common_apps.items():
        if target_lower in key or key in target_lower:
            return (key.title(), cmd)
    
    # Cerca nella cache
    cache = _load_cache()
    if target_lower in cache:
        return (target.title(), cache[target_lower])
    
    # Scansione completa (lenta)
    apps = _scan_apps()
    _save_cache(apps)
    
    if target_lower in apps:
        return (target.title(), apps[target_lower])
    
    # Match parziale nella cache
    for key, cmd in apps.items():
        if target_lower in key or key in target_lower:
            return (key.title(), cmd)
    
    return (None, None)

def launch(cmd: str) -> bool:
    """Lancia un'applicazione.
    
    Args:
        cmd: Comando o path dell'eseguibile
    
    Returns:
        True se lanciata con successo
    """
    try:
        subprocess.Popen(cmd, shell=True)
        return True
    except Exception as e:
        print(f"[app] errore lancio: {e}")
        return False

def close_app(target: str) -> Tuple[bool, str]:
    """Chiude un'applicazione.
    
    Args:
        target: Nome dell'app da chiudere
    
    Returns:
        (success, message)
    """
    if platform.system() != "Windows":
        return (False, "Chiusura app disponibile solo su Windows.")
    
    target_lower = target.lower().strip()
    
    # Mappatura nome -> nome processo
    process_names = {
        "chrome": "chrome.exe",
        "google chrome": "chrome.exe",
        "firefox": "firefox.exe",
        "edge": "msedge.exe",
        "microsoft edge": "msedge.exe",
        "spotify": "spotify.exe",
        "discord": "discord.exe",
        "vscode": "code.exe",
        "visual studio code": "code.exe",
        "notepad": "notepad.exe",
        "blocco note": "notepad.exe",
        "steam": "steam.exe",
        "vlc": "vlc.exe",
        "obs": "obs64.exe",
        "word": "winword.exe",
        "excel": "excel.exe",
        "powerpoint": "powerpnt.exe",
        "outlook": "outlook.exe",
    }
    
    # Trova il nome del processo
    process_name = None
    
    if target_lower in process_names:
        process_name = process_names[target_lower]
    else:
        # Match parziale
        for key, proc in process_names.items():
            if target_lower in key or key in target_lower:
                process_name = proc
                break
    
    if not process_name:
        # Prova con il nome diretto
        if not target_lower.endswith(".exe"):
            process_name = target_lower + ".exe"
        else:
            process_name = target_lower
    
    try:
        # Usa taskkill per chiudere il processo
        result = subprocess.run(
            ["taskkill", "/F", "/IM", process_name],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return (True, f"{target.title()} chiuso.")
        else:
            return (False, f"{target.title()} non è in esecuzione o non può essere chiuso.")
    
    except Exception as e:
        return (False, f"Errore nella chiusura di {target}: {e}")
