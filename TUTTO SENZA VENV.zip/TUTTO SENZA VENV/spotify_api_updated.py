"""spotify_api_updated - alias che ri-esporta spotify_api del progetto originale.

Mantenuto per compatibilita' con il system_actions originale che provava a importare
sia spotify_api_updated sia spotify_api. La logica di play Spotify e' INVARIATA
rispetto alla repo originale (richiesta esplicita dell'utente).
"""
from spotify_api import *  # noqa: F401, F403
from spotify_api import search_track, search_and_play  # noqa: F401
