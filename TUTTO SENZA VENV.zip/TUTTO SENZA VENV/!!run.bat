@echo off
echo ========================================
echo JARVIS DESKTOP OFFLINE - Avvio
echo ========================================
echo.

call venv\Scripts\activate.bat
python jarvis_offline.py

if errorlevel 1 (
    echo.
    echo [ERRORE] Jarvis non si è avviato correttamente.
    echo Assicurati di aver eseguito install.bat prima.
    pause
)
