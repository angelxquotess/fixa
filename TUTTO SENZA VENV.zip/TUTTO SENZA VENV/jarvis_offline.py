"""JARVIS DESKTOP OFFLINE - Assistente vocale italiano POTENZIATO.

NUOVE FUNZIONALITÀ v3:
- STT 100% offline con Vosk
- Jarvis PARLA SOLO DOPO aver sentito il wake word "jarvis"
- ASCOLTO SILENZIOSO: non stampa nulla finché non senti "jarvis"
- Wake word accetta varianti: "jarvis", "ehi jarvis", "già jarvis", "hey jarvis", "ok jarvis"
- Modalità silenziosa attivabile con comando vocale
- Controllo Spotify DESKTOP (play, pause, resume, next, previous)
- Chiusura app, Timer, Calcolatrice, Info sistema, Note vocali, Data/Ora
- Risposte istantanee (nessun blocco)
- Correzione STT con Ollama 3.2 locale (100% offline)
- Filtro rumore: scarta automaticamente falsi positivi
"""
import re
import sys
import time
import webbrowser
import urllib.parse
import config
from ai_brain_enhanced import JarvisBrainEnhanced, _normalize_vosk_text, _strip_noise
from voice_offline import speak, listen_once, calibrate, set_voice_mode, is_voice_enabled
import app_finder_enhanced as app_finder
import system_actions_enhanced as system_actions

# Wake word regex accetta sia "jarvis" da solo sia varianti (gia normalizzate da _normalize_vosk_text)
WAKE_REGEX = re.compile(rf"\b{re.escape(config.WAKE_WORD)}\b", re.IGNORECASE)


def strip_wake_word(text: str) -> str:
    """Rimuovi wake word e punteggiatura adiacente."""
    new = WAKE_REGEX.sub("", text, count=1).strip()
    new = re.sub(r"^[,\s.;:!?]+", "", new)
    new = re.sub(r"\s+", " ", new).strip()
    return new


def handle_intent(brain: JarvisBrainEnhanced, user_text: str):
    """Gestisce tutti gli intent (inclusi i nuovi)."""
    cls = brain.classify(user_text)
    intent = (cls.get("intent") or "chat").lower()

    if intent == "voice_mode":
        mode = cls.get("mode", "speak")
        if mode == "silent":
            set_voice_mode(False)
            speak("Modalità silenziosa attivata. Non parlerò più fino a nuovo ordine.", force=True)
        else:
            set_voice_mode(True)
            speak("Modalità vocale riattivata. Torno a parlare normalmente.", force=True)
        return

    if intent == "open_app":
        target = (cls.get("target") or "").strip()
        if not target:
            speak("Quale app vuoi aprire, capo?")
            return

        name, cmd = app_finder.find_app(target, brain=brain)
        if not cmd:
            speak(f"Non sono riuscito a trovare {target} sul sistema.")
            return

        ok = app_finder.launch(cmd)
        if ok:
            speak(f"Apro {name}.")
        else:
            speak(f"Ho trovato {name} ma non riesco a lanciarlo.")
        return

    if intent == "close_app":
        target = (cls.get("target") or "").strip()
        if not target:
            speak("Quale app vuoi chiudere?")
            return

        success, msg = app_finder.close_app(target)
        speak(msg)
        return

    if intent == "spotify_play":
        song = (cls.get("song") or "").strip()
        if not song:
            speak("Quale canzone vuoi che metta?")
            return
        msg = system_actions.spotify_search_and_play(song)
        speak(msg)
        return

    if intent == "spotify_control":
        action = cls.get("action", "").strip()
        msg = system_actions.spotify_control(action)
        speak(msg)
        return

    if intent == "web_search":
        q = (cls.get("query") or user_text).strip()
        url = "https://www.google.com/search?q=" + urllib.parse.quote(q)
        webbrowser.open(url)
        speak(f"Cerco '{q}' su Google.")
        return

    if intent == "system":
        action = (cls.get("action") or "").strip()
        msg = system_actions.execute(action)
        speak(msg)
        return

    if intent == "timer":
        seconds = cls.get("seconds", 0)
        text = cls.get("text", "")
        if seconds > 0:
            msg = system_actions.set_timer(seconds, text)
            speak(msg)
        else:
            speak("Non ho capito la durata del timer.")
        return

    if intent == "calculate":
        expression = cls.get("expression", "")
        result = system_actions.calculate(expression)
        speak(result)
        return

    if intent == "system_info":
        info_type = cls.get("type", "all")
        info = system_actions.get_system_info(info_type)
        speak(info)
        return

    if intent == "datetime":
        dt = system_actions.get_datetime()
        speak(dt)
        return

    if intent == "save_note":
        note = cls.get("note", "").strip()
        if note:
            msg = system_actions.save_note(note)
            speak(msg)
        else:
            speak("Cosa vuoi annotare?")
        return

    if intent == "read_notes":
        notes = system_actions.read_notes()
        speak(notes)
        return

    reply = brain.chat(user_text)
    speak(reply)


def main():
    print("=" * 60)
    print("  JARVIS DESKTOP OFFLINE v3 - Assistente Vocale Italiano")
    print("  Wake-word obbligatorio - Ascolto silenzioso senza 'jarvis'")
    print("=" * 60)
    print()
    print("COME USARLO:")
    print("  - Di' 'jarvis' (o 'ehi jarvis', 'già jarvis', 'hey jarvis') seguito dal comando")
    print("  - Tutto cio' che dici SENZA dire 'jarvis' viene IGNORATO (e non stampato)")
    print()
    print("COMANDI:")
    print("  - 'jarvis modalita silenziosa' / 'jarvis modalita vocale'")
    print("  - 'jarvis metti [canzone]' / 'jarvis pausa' / 'jarvis riprendi'")
    print("  - 'jarvis prossima' / 'jarvis precedente'")
    print("  - 'jarvis apri [app]' / 'jarvis chiudi [app]'")
    print("  - 'jarvis timer 5 minuti' / 'jarvis calcola 25 per 4'")
    print("  - 'jarvis quanta RAM ho' / 'jarvis che ore sono'")
    print("  - 'jarvis annota comprare il latte' / 'jarvis leggi note'")
    print("  - 'jarvis stop' per uscire")
    print("=" * 60)
    print()

    calibrate()
    brain = JarvisBrainEnhanced()

    speak("Sistemi online. Jarvis a rapporto, signore. Cosa combiniamo oggi?")

    # WAKE WORD SEMPRE OBBLIGATORIO: l'utente vuole che parli SOLO dopo aver detto "jarvis"
    wake_required = True
    print(f"[wake] modalita': SEMPRE ON. Mi senti solo se dici 'jarvis' (o varianti).")
    print(f"[voice] modalita' vocale: {'ATTIVA' if is_voice_enabled() else 'SILENZIOSA'}")
    print(f"[mic] in ascolto silenzioso...\n")

    while True:
        try:
            text = listen_once(timeout=None, phrase_time_limit=10)
        except KeyboardInterrupt:
            print("\n[exit] arrivederci.")
            break
        except Exception as e:
            print(f"[mic] errore: {e}")
            time.sleep(0.5)
            continue

        if not text:
            continue

        # 1) Filtra rumore evidente (es. "piste riprendi", "abbracciarlo mense", parole singole)
        cleaned_raw = _strip_noise(text)
        if cleaned_raw is None:
            # rumore -> non stampare niente, continua ad ascoltare in silenzio
            continue

        # 2) Correggi errori comuni di Vosk PRIMA del matching wake-word
        #    (questo trasforma "gia jarvis", "ehi jarvis", "carvis" -> "jarvis")
        text = _normalize_vosk_text(cleaned_raw)

        t_lower = text.lower()

        # 3) Wake word presente?
        if not WAKE_REGEX.search(text):
            # NESSUN wake word -> ignora silenziosamente, non stampare nulla
            # (utente vuole che Jarvis "tace" finche' non sente il suo nome)
            continue

        # 4) Wake word presente -> stampa il comando e processalo
        print(f"> Tu: {text}")

        # comandi globali di wake-word / uscita
        if any(p in t_lower for p in ["jarvis stop", "spegniti", "esci jarvis", "chiuditi",
                                       "jarvis spegniti", "jarvis chiuditi"]):
            speak("A presto, capo.")
            break

        user_text = strip_wake_word(text)
        if not user_text:
            # ha detto solo "jarvis" senza comando -> rispondi presente
            speak("Sono qui, dimmi.")
            continue

        try:
            handle_intent(brain, user_text)
        except Exception as e:
            print(f"[err] handler: {e}")
            speak("Mi sa che qualcosa e' andato storto. Riprova.")


if __name__ == "__main__":
    main()
