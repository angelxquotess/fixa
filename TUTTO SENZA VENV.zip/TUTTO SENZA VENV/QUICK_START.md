# 🚀 GUIDA RAPIDA - JARVIS Arc Reactor Edition

## Installazione Express (3 minuti)

1. **Scarica e estrai** il file ZIP in una cartella (es. `C:\JARVIS`)

2. **Installa Python 3.8+** se non lo hai già:
   - Scarica da: https://www.python.org/downloads/
   - ⚠️ IMPORTANTE: Spunta "Add Python to PATH"

3. **Doppio click su `install_migliorato.bat`**
   - Aspetta 2-3 minuti
   - Il modello Vosk (~40MB) verrà scaricato automaticamente

4. **Avvia con `run_migliorato.bat`**

## Primo Utilizzo

Quando avvii JARVIS vedrai:
- Console con log
- Interfaccia Arc Reactor animata (in alto a destra)

Prova subito:
```
"Jarvis ciao"
"Jarvis che ore sono?"
"Jarvis apri Chrome"
```

## Comandi Base

### Musica
- `Jarvis riproduci [canzone]`
- `Jarvis pausa`
- `Jarvis prossima`

### Applicazioni
- `Jarvis apri [app]`
- `Jarvis chiudi [app]`

### Utilità
- `Jarvis timer 5 minuti`
- `Jarvis calcola 25 per 4`
- `Jarvis quanta RAM ho?`

### Modalità
- `Jarvis modalità silenziosa` - Non parla più
- `Jarvis modalità vocale` - Riprende a parlare

### Uscita
- `Jarvis stop`

## Personalizzazione

Copia `.env.example` in `.env` e modifica:

```env
TTS_RATE=180              # Velocità voce
ARC_REACTOR_UI=true       # Attiva UI
```

## Problemi?

### Microfono non funziona
- Verifica impostazioni audio Windows
- Imposta come dispositivo predefinito

### Spotify non risponde
- Installa app desktop Spotify
- Apri Spotify prima di usare i comandi

### Voce troppo veloce/lenta
- Modifica `TTS_RATE` nel file `.env`

## Requisiti Sistema

- Windows 10/11 (64-bit)
- Python 3.8+
- Microfono
- ~200MB RAM
- ~120MB spazio disco

## Link Utili

- README completo: `README_MIGLIORATO.md`
- Configurazione: `.env.example`

---

**Buon divertimento con JARVIS Arc Reactor Edition!** 🔥🤖

"Sistemi online. Jarvis a rapporto, signore!"
