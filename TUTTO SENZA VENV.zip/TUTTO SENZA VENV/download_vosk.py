"""Script per scaricare automaticamente il modello Vosk per italiano."""
import os
import sys
import urllib.request
import zipfile
from pathlib import Path

MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip"
MODEL_NAME = "vosk-model-small-it-0.22"
MODELS_DIR = Path(__file__).parent / "models"

def download_vosk_model():
    """Scarica e estrae il modello Vosk italiano."""
    MODELS_DIR.mkdir(exist_ok=True)
    
    model_path = MODELS_DIR / MODEL_NAME
    if model_path.exists():
        print(f"[✓] Modello Vosk già presente in: {model_path}")
        return
    
    zip_path = MODELS_DIR / f"{MODEL_NAME}.zip"
    
    print(f"[*] Download modello Vosk italiano (~40 MB)...")
    print(f"    URL: {MODEL_URL}")
    
    try:
        urllib.request.urlretrieve(MODEL_URL, zip_path)
        print(f"[✓] Download completato")
        
        print(f"[*] Estrazione in corso...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(MODELS_DIR)
        
        print(f"[✓] Modello estratto in: {model_path}")
        
        # Rimuovi zip
        zip_path.unlink()
        print(f"[✓] Installazione completata!")
    
    except Exception as e:
        print(f"[✗] Errore durante il download: {e}")
        print(f"\nScarica manualmente da: {MODEL_URL}")
        print(f"Ed estrai nella cartella: {MODELS_DIR}")
        sys.exit(1)

if __name__ == "__main__":
    print("=" * 60)
    print("  JARVIS - Download Modello Vosk Italiano")
    print("=" * 60)
    print()
    download_vosk_model()
    print()
    print("[✓] Puoi ora avviare Jarvis con: python jarvis_offline.py")
    print("=" * 60)
