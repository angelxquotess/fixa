"""Configurazione Jarvis - Versione Offline Ottimizzata"""
import os
from pathlib import Path

ROOT = Path(__file__).parent
ENV_PATH = ROOT / ".env"

try:
    from dotenv import load_dotenv
    if ENV_PATH.exists():
        load_dotenv(ENV_PATH)
    else:
        load_dotenv()
except ImportError:
    pass

def _b(v: str, default: bool = False) -> bool:
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y", "si", "sì", "on")

# --- Wake word ---
WAKE_WORD_ENABLED = _b(os.getenv("WAKE_WORD_ENABLED", "true"), True)
WAKE_WORD = os.getenv("WAKE_WORD", "jarvis").strip().lower()

# --- STT Offline (Vosk) ---
STT_LANGUAGE = os.getenv("STT_LANGUAGE", "it-IT").strip()
VOSK_MODEL_PATH = os.getenv("VOSK_MODEL_PATH", "").strip()

# --- TTS Locale (pyttsx3) ---
TTS_RATE = int(os.getenv("TTS_RATE", "190"))
TTS_VOLUME = float(os.getenv("TTS_VOLUME", "0.9"))

# --- Note vocali ---
NOTES_DIR = ROOT / "notes"
NOTES_DIR.mkdir(exist_ok=True)

# --- Timer e allarmi ---
TIMERS_FILE = ROOT / "timers.json"

# --- Modalità Vocale (NUOVO) ---
VOICE_MODE_ENABLED = True  # Jarvis parla sempre di default
