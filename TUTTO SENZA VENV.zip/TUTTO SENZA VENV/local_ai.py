"""AI locale 100% OFFLINE.

Strategia:
1) Knowledge base locale (ricette, FAQ, cultura generale) -- SEMPRE disponibile.
2) Se l'utente ha installato Ollama (https://ollama.com) e ha un modello in esecuzione
   su http://127.0.0.1:11434, lo usiamo per:
     - risposte chat ricche e generative
     - CORREZIONE STT (Vosk small confonde parole foneticamente simili)
     - inferenza intent quando l'heuristica fallisce
3) Se neppure Ollama è disponibile, fallback su risposta generica.

NESSUNA API KEY, NESSUN SERVER ESTERNO, NESSUN CLOUD. 100% OFFLINE.
"""
import json
import re
import socket
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

# ------------------------------------------------------------------
# Knowledge base locale (espandibile)
# ------------------------------------------------------------------

KNOWLEDGE_BASE = [
    {
        "keywords": ["carbonara"],
        "answer": (
            "La carbonara romana si prepara così. "
            "Ingredienti per due persone: duecento grammi di spaghetti, cento grammi di guanciale, "
            "due tuorli e un uovo intero, cinquanta grammi di pecorino romano, pepe nero. "
            "Taglia il guanciale a listarelle e rosolalo in padella senza olio finché non è croccante. "
            "In una ciotola sbatti i tuorli con il pecorino e abbondante pepe. "
            "Cuoci la pasta al dente, scolala tenendo un mestolo d'acqua di cottura. "
            "Spegni il fuoco, versa la pasta nella padella col guanciale, aggiungi le uova mescolando velocemente "
            "e un poco di acqua di cottura per cremare. Niente panna, mai. Servi subito con altro pecorino e pepe."
        ),
    },
    {
        "keywords": ["amatriciana"],
        "answer": (
            "Per l'amatriciana ti servono: bucatini o spaghetti, guanciale, pomodoro pelato, pecorino romano, "
            "pepe e un goccio di vino bianco. Rosola il guanciale, sfuma col vino, aggiungi il pomodoro e cuoci "
            "dieci minuti. Manteca con la pasta al dente, finisci con pecorino e pepe."
        ),
    },
    {
        "keywords": ["cacio e pepe", "cacio pepe"],
        "answer": (
            "Cacio e pepe: tonnarelli o spaghetti, pecorino romano grattugiato finissimo, pepe nero in grani. "
            "Tosta il pepe in padella, aggiungi un mestolo di acqua di cottura. Scola la pasta molto al dente e "
            "saltala in padella. Spegni e aggiungi il pecorino mescolando con energia per creare la crema."
        ),
    },
    {
        "keywords": ["tiramisù", "tiramisu"],
        "answer": (
            "Tiramisù classico: monta quattro tuorli con cento grammi di zucchero, unisci cinquecento grammi di "
            "mascarpone. A parte monta gli albumi a neve e incorporali delicatamente. Inzuppa i savoiardi nel caffè "
            "amaro freddo, fai uno strato di biscotti, uno di crema, ripeti. Finisci con cacao amaro setacciato. "
            "Riposo in frigo almeno tre ore."
        ),
    },
    {
        "keywords": ["pesto", "genovese"],
        "answer": (
            "Pesto alla genovese nel mortaio: basilico genovese DOP, pinoli, aglio, sale grosso, parmigiano e "
            "pecorino, olio extravergine ligure. Pesta aglio e pinoli, aggiungi il basilico con un pizzico di sale, "
            "poi i formaggi e infine l'olio a filo. Mai scaldare, mai frullare a lungo."
        ),
    },
    {
        "keywords": ["pizza margherita", "pizza"],
        "answer": (
            "Pizza margherita napoletana: cinquecento grammi di farina forte, trecentocinquanta grammi di acqua, "
            "due grammi di lievito di birra, dieci grammi di sale. Impasta, fai lievitare otto ore a temperatura "
            "ambiente, forma i panetti e lasciali altre quattro ore. Stendi a mano, pomodoro San Marzano, "
            "fior di latte, basilico, olio. Cottura nel forno più caldo che hai."
        ),
    },
    {
        "keywords": ["risotto"],
        "answer": (
            "Per un buon risotto: tosta il riso a secco, sfuma con vino bianco, aggiungi brodo caldo un mestolo "
            "alla volta mescolando. Cottura sedici-diciotto minuti. A fuoco spento manteca con burro freddo e "
            "parmigiano. Copri un minuto e servi."
        ),
    },
    {
        "keywords": ["lasagne", "lasagna"],
        "answer": (
            "Lasagne alla bolognese: prepara un ragù lungo almeno due ore con macinato di manzo e maiale, "
            "soffritto, pomodoro, vino rosso. Fai una besciamella morbida. Alterna sfoglie, ragù, besciamella e "
            "parmigiano. Forno a centottanta gradi per trentacinque minuti, ultimi cinque a duecento per gratinare."
        ),
    },
    {
        "keywords": ["caffè", "caffe", "espresso"],
        "answer": (
            "Espresso perfetto in moka: acqua fredda fino alla valvola, caffè macinato medio senza pressarlo, "
            "fuoco basso. Quando senti il primo gorgoglio togli dal fuoco e mescola in caraffa per uniformare."
        ),
    },
    {
        "keywords": ["pasta al pomodoro", "pomodoro semplice", "sugo al pomodoro"],
        "answer": (
            "Sugo al pomodoro: in padella aglio in camicia e olio, aggiungi i pelati schiacciati a mano, "
            "sale, basilico. Cuoci venti minuti a fuoco medio. Salta la pasta in padella per gli ultimi minuti."
        ),
    },
    {
        "keywords": ["python", "cos'è python", "che cosa è python"],
        "answer": (
            "Python è un linguaggio di programmazione interpretato, di alto livello e general purpose, "
            "noto per la sintassi leggibile e per l'ampia libreria standard. È molto usato per AI, web, scripting e data science."
        ),
    },
    {
        "keywords": ["intelligenza artificiale", "cos'è ai", "che cos'è l'ia", "ia"],
        "answer": (
            "L'intelligenza artificiale è la disciplina che studia e realizza sistemi capaci di svolgere compiti "
            "che richiedono tipicamente intelligenza umana, come comprendere il linguaggio, riconoscere immagini, "
            "ragionare e prendere decisioni."
        ),
    },
    {"keywords": ["roma capitale", "capitale d'italia", "capitale italia"], "answer": "La capitale d'Italia è Roma."},
    {"keywords": ["capitale francia"], "answer": "La capitale della Francia è Parigi."},
    {"keywords": ["capitale spagna"], "answer": "La capitale della Spagna è Madrid."},
    {"keywords": ["capitale germania"], "answer": "La capitale della Germania è Berlino."},
    {"keywords": ["capitale inghilterra", "capitale regno unito", "capitale uk"], "answer": "La capitale del Regno Unito è Londra."},
]


def _normalize(s: str) -> str:
    s = s.lower()
    s = s.replace("'", " ").replace("à", "a").replace("è", "e").replace("é", "e")
    s = s.replace("ì", "i").replace("ò", "o").replace("ù", "u")
    return " ".join(s.split())


def search_knowledge_base(question: str) -> Optional[str]:
    """Cerca nella knowledge base locale."""
    q = _normalize(question)
    for entry in KNOWLEDGE_BASE:
        keywords = entry.get("keywords", [])
        for kw in keywords:
            kw_norm = _normalize(kw)
            if kw_norm in q:
                return entry.get("answer")
    return None


# ------------------------------------------------------------------
# Ollama locale (100% offline su 127.0.0.1:11434)
# ------------------------------------------------------------------

OLLAMA_HOST = "127.0.0.1"
OLLAMA_PORT = 11434
OLLAMA_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/api/generate"

_ollama_checked = False
_ollama_model_cache = None


def _ollama_running() -> bool:
    """Controlla se Ollama è in esecuzione (NON bloccante)."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((OLLAMA_HOST, OLLAMA_PORT))
        sock.close()
        return result == 0
    except Exception:
        return False


def _ollama_pick_model() -> Optional[str]:
    """Trova il primo modello installato in Ollama, preferendo i più piccoli/veloci."""
    global _ollama_model_cache, _ollama_checked

    if _ollama_checked:
        return _ollama_model_cache

    _ollama_checked = True

    if not _ollama_running():
        return None

    try:
        req = urllib.request.Request(f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/api/tags")
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        models = [m.get("name", "") for m in data.get("models", []) if m.get("name")]

        if not models:
            return None

        preferred = ["llama3.2", "llama3.1", "qwen2.5", "mistral", "phi3", "gemma"]
        for pref in preferred:
            for m in models:
                if m.lower().startswith(pref):
                    _ollama_model_cache = m
                    return m

        _ollama_model_cache = models[0]
        return _ollama_model_cache

    except Exception:
        return None


def _ollama_generate(prompt: str, temperature: float = 0.3, num_predict: int = 220,
                    timeout: float = 20.0) -> Optional[str]:
    """Chiamata generica a Ollama. Ritorna testo o None."""
    model = _ollama_pick_model()
    if not model:
        return None

    try:
        payload = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": num_predict},
        }).encode("utf-8")

        req = urllib.request.Request(
            OLLAMA_URL, data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )

        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        text = (data.get("response") or "").strip()
        return text or None

    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, socket.timeout):
        return None
    except Exception:
        return None


def ask_ollama(question: str, timeout: float = 30.0) -> Optional[str]:
    """Interroga Ollama in locale per CHAT. Restituisce la risposta o None se non disponibile."""
    prompt = (
        "Sei Jarvis, assistente vocale italiano con tono elegante e leggermente sarcastico. "
        "Rispondi in italiano in modo breve, chiaro e diretto, in non più di tre frasi. "
        "Domanda: " + question
    )
    return _ollama_generate(prompt, temperature=0.4, num_predict=220, timeout=timeout)


# ------------------------------------------------------------------
# NUOVO: CORREZIONE STT VIA OLLAMA (100% offline)
# ------------------------------------------------------------------

# Comandi che il sistema Jarvis sa eseguire (per dare contesto a Ollama)
_KNOWN_COMMANDS = (
    "apri <app>, chiudi <app>, "
    "riproduci/metti <canzone> su spotify, pausa, riprendi, prossima, precedente, "
    "cerca <query> su google, "
    "alza/abbassa volume, muto, spegni pc, riavvia, blocca, chiudi finestra, "
    "timer <durata>, calcola <espressione>, "
    "ram/cpu/disco/batteria, che ore sono, "
    "annota <nota>, leggi note, "
    "modalità silenziosa, modalità vocale"
)

# Artisti italiani / nomi propri famosi che Vosk italiano small NON ha nel dizionario.
# Servono come contesto a Ollama per riconoscere il nome anche se trascritto male
# (es. "kit u gi" -> "kid yugi", "geolieri" -> "geolier").
_KNOWN_ARTISTS = (
    "Sfera Ebbasta, Kid Yugi, Lazza, Marracash, Tedua, Capo Plaza, Geolier, "
    "Rondodasosa, Tony Effe, Massimo Pericolo, Salmo, Gue, Fabri Fibra, Ernia, "
    "Madame, Anna, Rose Villain, Mahmood, Blanco, Ultimo, Irama, Sangiovanni, "
    "Achille Lauro, Ghali, Rkomi, Shiva, Paky, Baby Gang, Simba La Rue, Tha Supreme, "
    "Bresh, Artie 5ive, Niky Savage, Side Baby, Drillionaire, "
    "The Weeknd, Drake, Travis Scott, Kendrick Lamar, Eminem, Kanye West, Billie Eilish"
)

# Canzoni / brani famosi 2023-2025 che Vosk tende a sbagliare.
# Usati come contesto a Ollama per riconoscere il titolo anche se trascritto male.
_KNOWN_SONGS = (
    # Kid Yugi
    "Il Filmografo - Kid Yugi, Gilgamesh - Kid Yugi, I Nomi del Diavolo - Kid Yugi, "
    "Cremlino - Kid Yugi, Atena - Kid Yugi, RIP Boss - Kid Yugi, DSL - Kid Yugi, "
    # Sfera Ebbasta
    "Neon - Sfera Ebbasta, Bottiglie Privè - Sfera Ebbasta, Tran Tran - Sfera Ebbasta, "
    "Cupido - Sfera Ebbasta, BHMG - Sfera Ebbasta, Salem - Sfera Ebbasta, "
    # Lazza
    "Cenere - Lazza, Ouverture - Lazza, 100 Messaggi - Lazza, Dolcevita - Lazza, "
    "Sirio - Lazza, Zonda - Lazza, Locura - Lazza, Hollywood - Lazza, "
    # Marracash
    "Crazy Love - Marracash, Cosplay - Marracash, Pagliaccio - Marracash, "
    "Persona - Marracash, Insta Lova - Marracash, Quelli che non Pensano - Marracash, "
    # Tedua
    "La Divina Commedia - Tedua, Vertigine - Tedua, Pugili - Tedua, "
    "Mare delle Sirene - Tedua, "
    # Geolier
    "I p' me, tu p' te - Geolier, Chiagne - Geolier, El Pibe de Oro - Geolier, "
    "Money Money - Geolier, "
    # Mahmood / Tony Effe / Ghali
    "Tuta Gold - Mahmood, Soldi - Mahmood, Brividi - Mahmood, "
    "Sesso e Samba - Tony Effe, Cigno Nero - Tony Effe, Wesh - Tony Effe, "
    "Casa Mia - Ghali, Cara Italia - Ghali, Habibi - Ghali, "
    # Shiva / Massimo Pericolo / Salmo
    "Tokyo Drift - Shiva, Fuori dal Mondo - Shiva, Auto Blu - Shiva, "
    "Sabbie Mobili - Massimo Pericolo, USB - Massimo Pericolo, "
    "Charles Manson - Salmo, Sparare alla Luna - Salmo, "
    # Capo Plaza / Anna / Madame
    "Allenamento 3 - Capo Plaza, Tesla - Capo Plaza, Forte e Chiaro - Capo Plaza, "
    "Bando - Anna, 30 Gradi - Anna, "
    "Voce - Madame, Il Bene nel Male - Madame, "
    # Internazionali
    "Blinding Lights - The Weeknd, Starboy - The Weeknd, Save Your Tears - The Weeknd, "
    "God's Plan - Drake, In My Feelings - Drake, One Dance - Drake, "
    "Sicko Mode - Travis Scott, Goosebumps - Travis Scott, Antidote - Travis Scott, "
    "HUMBLE - Kendrick Lamar, DNA - Kendrick Lamar, Not Like Us - Kendrick Lamar, "
    "Lose Yourself - Eminem, Rap God - Eminem, Stan - Eminem, "
    "Sunflower - Post Malone, Rockstar - Post Malone, "
    "Bad Guy - Billie Eilish, Lovely - Billie Eilish, "
    "Stronger - Kanye West, Heartless - Kanye West, Power - Kanye West"
)


def improve_stt_with_ollama(raw_text: str, timeout: float = 4.0) -> Optional[str]:
    """Usa Ollama per correggere errori STT di Vosk e restituire il comando 'pulito'.

    Esempio: 'beth neon di sfera ebbasta su sporti fai' -> 'metti neon di sfera ebbasta su spotify'

    Ritorna il testo corretto, oppure None se Ollama non è disponibile o non corregge.
    """
    raw = (raw_text or "").strip()
    if not raw or len(raw) < 3:
        return None

    prompt = (
        "Sei un correttore di trascrizioni vocali italiane fatte da un STT offline (Vosk small) "
        "che spesso confonde parole foneticamente simili (es. 'beth'/'betti'->'metti', 'sporti fai'->'spotify', "
        "'carvis'->'jarvis', 'sona'->'suona', 'pley'->'play') e SBAGLIA SEMPRE i nomi stranieri "
        "(rapper, artisti, brand) perchè non li ha nel dizionario. "
        "Ti viene dato un comando vocale grezzo. Restituisci SOLO il comando corretto in italiano, "
        "senza spiegazioni, senza virgolette, senza prefissi. Mantieni i nomi propri il piu' fedeli "
        "possibile MA correggi gli artisti riconoscibili dal contesto.\n\n"
        f"Comandi che l'assistente riconosce: {_KNOWN_COMMANDS}\n\n"
        f"Artisti/rapper noti (correggi a questi se il nome grezzo somiglia foneticamente): {_KNOWN_ARTISTS}\n\n"
        f"Canzoni famose (correggi al titolo se senti qualcosa di simile): {_KNOWN_SONGS}\n\n"
        "Esempi:\n"
        "  'metti kit u gi su spotify' -> 'metti kid yugi su spotify'\n"
        "  'beth neon di sfera ebasta' -> 'metti neon di sfera ebbasta'\n"
        "  'metti geolieri' -> 'metti geolier'\n"
        "  'metti il filmografia' -> 'metti il filmografo di kid yugi'\n\n"
        f"Trascrizione grezza: {raw}\n"
        "Comando corretto:"
    )

    out = _ollama_generate(prompt, temperature=0.1, num_predict=80, timeout=timeout)
    if not out:
        return None

    # Pulizia output: rimuovi virgolette, prefissi tipo "Comando corretto:" se l'LLM li ripete
    cleaned = out.strip().strip('"').strip("'").strip()
    # Prendi solo prima riga (Ollama a volte aggiunge spiegazioni)
    cleaned = cleaned.split("\n", 1)[0].strip()
    # Rimuovi prefissi comuni
    for prefix in ("comando corretto:", "corretto:", "risposta:", "output:"):
        if cleaned.lower().startswith(prefix):
            cleaned = cleaned[len(prefix):].strip()

    if not cleaned or cleaned.lower() == raw.lower():
        return None

    # Sanity: se l'output è troppo lungo rispetto al raw, scartalo (probabile allucinazione)
    if len(cleaned) > len(raw) * 3 + 30:
        return None

    return cleaned


def answer_offline(question: str) -> Optional[str]:
    """Prova a rispondere usando, in ordine: knowledge base locale, poi Ollama (se installato)."""
    kb = search_knowledge_base(question)
    if kb:
        return kb

    ol = ask_ollama(question)
    if ol:
        return ol

    return None
