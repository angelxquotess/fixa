"""Voce OFFLINE: STT con Vosk + TTS con pyttsx3 (nessuna connessione internet richiesta)

MIGLIORAMENTI v3:
- Jarvis parla SEMPRE ad ogni risposta
- Modalita' silenziosa attivabile/disattivabile
- Gestione robusta degli errori TTS
- NUOVO v3: selezione voce italiana prioritizzata (Cosimo/Elsa/Bianca > eSpeak)
- NUOVO v3: pronuncia foneticamente corretta per nomi stranieri prima del TTS
            (es. "kid yugi" -> "chid iughi", "spotify" -> "spotifai", "youtube" -> "iutub")
- NUOVO v3: rate auto-adattato in base alla voce (eSpeak piu' lento di SAPI)
"""
import os
import re
import json
import queue
import threading
import sounddevice as sd
import numpy as np
from typing import Optional
import config

# --- STATO VOCALE GLOBALE ---
_voice_enabled = True
_voice_lock = threading.Lock()

def set_voice_mode(enabled: bool):
    global _voice_enabled
    with _voice_lock:
        _voice_enabled = enabled

def is_voice_enabled() -> bool:
    with _voice_lock:
        return _voice_enabled

# --- TTS Offline con pyttsx3 ---
_pyttsx_engine = None
_tts_lock = threading.Lock()
_current_voice_id = None
_is_espeak = False

# Ordine preferenza voci italiane (qualita' alta -> bassa)
# Microsoft SAPI italiane > Apple > eSpeak
_VOICE_PRIORITY = [
    "cosimo",          # SAPI ita maschile (Win 10/11) - migliore
    "elsa",            # SAPI ita femminile (Win 10/11)
    "bianca",          # SAPI ita femminile (Win 10) - solo IT-IT
    "carla",           # Apple ita femminile (macOS)
    "alice",           # Apple ita femminile (macOS) - non TutorIA
    "luca",            # Apple ita maschile (macOS)
    "italian",         # generic fallback
    "italiano",
    "italia",
    "it_it",
    "it-it",
    "it_",
    "it-",
]


def _pick_best_italian_voice(voices):
    """Sceglie la voce italiana migliore disponibile usando _VOICE_PRIORITY."""
    if not voices:
        return None, False
    # cerca in ordine di priorita'
    for keyword in _VOICE_PRIORITY:
        for v in voices:
            blob = ((v.name or "") + " " + (v.id or "")).lower()
            if keyword in blob:
                is_espeak = "espeak" in blob or "mb-" in blob
                return v, is_espeak
    return None, False


def _init_tts_engine():
    """Inizializza il motore TTS con la migliore voce italiana disponibile."""
    global _current_voice_id, _is_espeak
    try:
        import pyttsx3
        engine = pyttsx3.init()
        voices = engine.getProperty("voices") or []
        best_voice, is_espeak = _pick_best_italian_voice(voices)

        if best_voice:
            engine.setProperty("voice", best_voice.id)
            _current_voice_id = best_voice.id
            _is_espeak = is_espeak
            print(f"[tts] voce: {best_voice.name} (id: {best_voice.id})")
        else:
            print("[tts] nessuna voce italiana trovata, uso default")
            _is_espeak = False

        # eSpeak suona piu' naturale a un rate piu' basso, SAPI invece tollera 175-200
        default_rate = getattr(config, "TTS_RATE", 175)
        if _is_espeak:
            engine.setProperty("rate", min(default_rate, 160))
        else:
            engine.setProperty("rate", default_rate)

        engine.setProperty("volume", getattr(config, "TTS_VOLUME", 1.0))
        return engine
    except Exception as e:
        print(f"[tts] errore inizializzazione: {e}")
        return None


def _reinit_tts():
    global _pyttsx_engine
    try:
        if _pyttsx_engine:
            try:
                _pyttsx_engine.stop()
            except Exception:
                pass
        _pyttsx_engine = _init_tts_engine()
        print("[tts] motore reinizializzato")
    except Exception as e:
        print(f"[tts] errore reinit: {e}")


try:
    import pyttsx3
    _pyttsx_engine = _init_tts_engine()
    if _pyttsx_engine:
        print("[tts] pyttsx3 OFFLINE attivo")
    else:
        print("[tts] pyttsx3 non disponibile")
except Exception as e:
    print(f"[tts] pyttsx3 non disponibile: {e}")
    _pyttsx_engine = None


# ===================================================================
# MAPPA PRONUNCIA: convertiamo termini stranieri in fonetica italiana
# PRIMA di darli al TTS, cosi' che la voce italiana li pronunci giusto.
# Es. la voce ita legge "kid yugi" come "kidd iughi" (storpiato);
# se invece le passiamo "chid iughi" lo dice molto meglio.
# Queste sostituzioni vengono fatte SOLO per la sintesi vocale,
# NON sul testo stampato.
# ===================================================================
PRONUNCIATION_MAP = [
    # === BRAND / APP ===
    (r"\bspotify\b", "spotifài"),
    (r"\byoutube\b", "iutùb"),
    (r"\bgoogle\b", "gùgol"),
    (r"\bchrome\b", "cròm"),
    (r"\bfirefox\b", "fàiarfox"),
    (r"\bwhatsapp\b", "uòtsap"),
    (r"\btelegram\b", "telegràm"),
    (r"\bdiscord\b", "discòrd"),
    (r"\bvisual studio code\b", "visciual stùdio cod"),
    (r"\bvisual studio\b", "visciual stùdio"),
    (r"\bgithub\b", "ghithàb"),
    (r"\bnetflix\b", "netflix"),
    (r"\bamazon\b", "àmazon"),
    (r"\binstagram\b", "instagràm"),
    (r"\btiktok\b", "tic toc"),
    (r"\bfacebook\b", "feisbùk"),
    (r"\bmicrosoft\b", "maicrosòft"),
    (r"\bapple\b", "àpol"),
    (r"\bandroid\b", "àndroid"),
    (r"\biphone\b", "àifon"),
    (r"\bmacbook\b", "mecbùk"),
    (r"\bopenai\b", "open ei ài"),
    (r"\bchatgpt\b", "ciat gi pi ti"),
    # === ARTISTI RAP ITA (con grafia esotica) ===
    (r"\bkid yugi\b", "chid iùghi"),
    (r"\bsfera ebbasta\b", "sfera ebàsta"),
    (r"\bcapo plaza\b", "capo plàza"),
    (r"\btha supreme\b", "ta suprìm"),
    (r"\brkomi\b", "èrre còmi"),
    (r"\bartie 5ive\b", "àrti fàiv"),
    (r"\bniky savage\b", "nàiki sàvich"),
    (r"\bbaby gang\b", "bèibi gheng"),
    (r"\bsimba la rue\b", "sìmba la rù"),
    (r"\brondodasosa\b", "rondo da sòsa"),
    (r"\brose villain\b", "ros vìllen"),
    (r"\btony effe\b", "toni èffe"),
    (r"\bguè\b", "guè"),
    (r"\bgué\b", "guè"),
    (r"\bgue pequeno\b", "guè pechèno"),
    (r"\bmadame\b", "madàm"),
    # === ARTISTI INTERNAZIONALI ===
    (r"\bthe weeknd\b", "de uìken"),
    (r"\bdrake\b", "drèik"),
    (r"\btravis scott\b", "trèvis scot"),
    (r"\bkendrick lamar\b", "kendric lamàr"),
    (r"\beminem\b", "èminem"),
    (r"\bkanye west\b", "kènie uèst"),
    (r"\bbillie eilish\b", "bili àilisc"),
    (r"\bpost malone\b", "pòst malòn"),
    (r"\bbad bunny\b", "bed bàni"),
    (r"\bdua lipa\b", "dùa lìpa"),
    (r"\bbillie\b", "bili"),
    # === TERMINI TECH GENERICI ===
    (r"\bplaylist\b", "plèilist"),
    (r"\blive\b", "làiv"),
    (r"\bnext\b", "next"),
    (r"\bback\b", "bec"),
    (r"\bdownload\b", "daunlòd"),
    (r"\bupload\b", "aplòd"),
    (r"\bonline\b", "onlàin"),
    (r"\boffline\b", "offlàin"),
    (r"\bemail\b", "imèil"),
    (r"\bsmartphone\b", "smartfòn"),
    (r"\blaptop\b", "lèptop"),
    (r"\bsoftware\b", "softuère"),
    (r"\bhardware\b", "harduère"),
]


def _to_phonetic_italian(text: str) -> str:
    """Trasforma termini stranieri in grafia foneticamente italiana per il TTS.
    Usato SOLO per la sintesi vocale, non per la stampa."""
    out = text
    for pattern, replacement in PRONUNCIATION_MAP:
        out = re.sub(pattern, replacement, out, flags=re.IGNORECASE)
    # piccoli aggiustamenti generici: "y" da sola fra vocali -> "i"
    return out


def speak(text: str, force: bool = False):
    """Sintetizza e riproduce OFFLINE con pyttsx3.

    Args:
        text: Testo da pronunciare
        force: Se True, parla anche se in modalita' silenziosa
    """
    text = (text or "").strip()
    if not text:
        return

    # Stampa sempre la risposta cosi' l'utente legge il testo originale
    print(f"< Jarvis: {text}")

    # Controlla se la voce e' abilitata (a meno che non sia forzato)
    if not force and not is_voice_enabled():
        return

    # Converti termini stranieri in pronuncia italiana SOLO per il TTS
    spoken_text = _to_phonetic_italian(text)

    if _pyttsx_engine is not None:
        try:
            with _tts_lock:
                _pyttsx_engine.stop()
                _pyttsx_engine.say(spoken_text)
                _pyttsx_engine.runAndWait()
        except RuntimeError as e:
            print(f"[tts] errore runtime, reinizializzo: {e}")
            try:
                _reinit_tts()
                if _pyttsx_engine:
                    _pyttsx_engine.say(spoken_text)
                    _pyttsx_engine.runAndWait()
            except Exception as e2:
                print(f"[tts] errore dopo reinit: {e2}")
        except Exception as e:
            print(f"[tts] errore: {e}")


# --- STT Offline con Vosk ---
_vosk_model = None
_vosk_recognizer = None

try:
    from vosk import Model, KaldiRecognizer
    model_path = config.VOSK_MODEL_PATH
    if not model_path or not os.path.isdir(model_path):
        possible_paths = [
            config.ROOT / "models" / "vosk-model-small-it-0.22",
            config.ROOT / "models" / "vosk-model-it-0.22",
            config.ROOT / "models" / "vosk-model-small-en-us-0.15",
        ]
        for p in possible_paths:
            if p.exists():
                model_path = str(p)
                break

    if model_path and os.path.isdir(model_path):
        _vosk_model = Model(model_path)
        _vosk_recognizer = KaldiRecognizer(_vosk_model, 16000)
        _vosk_recognizer.SetWords(True)
        print(f"[stt] Vosk OFFLINE attivo ({model_path})")
    else:
        print("[stt] Modello Vosk non trovato. Usa: python download_vosk.py")
except Exception as e:
    print(f"[stt] Vosk non disponibile: {e}")


def listen_once(timeout: Optional[float] = None, phrase_time_limit: Optional[float] = 8.0) -> str:
    """Ascolta una frase OFFLINE con Vosk e restituisce testo."""
    if _vosk_recognizer is None:
        print("[stt] Vosk non configurato")
        return ""

    import time

    timeout_val = float(timeout) if timeout is not None else float("inf")
    phrase_limit_val = float(phrase_time_limit) if phrase_time_limit is not None else float("inf")

    try:
        q = queue.Queue()

        def callback(indata, frames, time_info, status):
            if status:
                pass
            q.put(bytes(indata))

        with sd.RawInputStream(samplerate=16000, blocksize=8000, dtype='int16',
                               channels=1, callback=callback):
            # rimosso il print "[stt] in ascolto..." per non sporcare i log
            # (l'ascolto e' continuo quindi non serve segnalarlo ogni volta)
            _vosk_recognizer.Reset()

            silence_threshold = 1.2
            silence_time = 0.0
            recording_started = False
            start_time = time.time()
            phrase_start = None

            while True:
                now = time.time()

                if (now - start_time) > timeout_val:
                    break

                if phrase_start is not None and (now - phrase_start) > phrase_limit_val:
                    break

                try:
                    data = q.get(timeout=0.1)
                except queue.Empty:
                    continue

                if _vosk_recognizer.AcceptWaveform(data):
                    result = json.loads(_vosk_recognizer.Result())
                    text = result.get("text", "").strip()
                    if text:
                        return text
                else:
                    partial = json.loads(_vosk_recognizer.PartialResult())
                    partial_text = partial.get("partial", "")
                    if partial_text:
                        if not recording_started:
                            recording_started = True
                            phrase_start = time.time()
                        silence_time = 0.0
                    elif recording_started:
                        silence_time += 0.1
                        if silence_time > silence_threshold:
                            break

            result = json.loads(_vosk_recognizer.FinalResult())
            text = result.get("text", "").strip()
            return text

    except Exception as e:
        print(f"[stt] errore: {e}")
        return ""


def calibrate():
    print("[stt] Vosk pronto (nessuna calibrazione necessaria)")
