# ========== CONTROLLO SPOTIFY DESKTOP - FIX RISPOSTA CORRETTA ==========

"""System Actions con fix per evitare duplicazione nome artista.

FIX: Ora usa il nome della traccia TROVATA da Spotify invece del parametro originale.
"""

import os
import sys
import time
import platform
import subprocess
import ctypes
from ctypes import wintypes

# Importa il nuovo spotify_api con fix
try:
    import spotify_api_updated as spotify_api
except ImportError:
    # Fallback al vecchio se non trova quello nuovo
    import spotify_api

# AppCommand codes
APPCOMMAND_MEDIA_PLAY = 46
APPCOMMAND_MEDIA_PAUSE = 47
APPCOMMAND_MEDIA_NEXTTRACK = 11
APPCOMMAND_MEDIA_PREVIOUSTRACK = 12
APPCOMMAND_MEDIA_PLAY_PAUSE = 14
WM_APPCOMMAND = 0x0319


def _get_spotify_pids():
    """Restituisce la lista dei PID di Spotify.exe."""
    pids = []
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq Spotify.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        ).decode(errors="ignore")
        for line in out.splitlines():
            if "spotify.exe" in line.lower():
                parts = [p.strip().strip('"') for p in line.split(",")]
                if len(parts) >= 2:
                    try:
                        pids.append(int(parts[1]))
                    except ValueError:
                        pass
    except Exception:
        pass
    return pids


def _find_all_spotify_hwnds():
    """Trova TUTTI gli HWND delle finestre di Spotify."""
    pids = _get_spotify_pids()
    if not pids:
        return []

    hwnds = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        pid = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids:
            hwnds.append(hwnd)
        return True

    ctypes.windll.user32.EnumWindows(cb, 0)
    return hwnds


def _find_spotify_main_hwnd():
    """Trova l'HWND della finestra PRINCIPALE di Spotify."""
    hwnds = _find_all_spotify_hwnds()
    for hwnd in hwnds:
        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
        if length > 0:
            return hwnd
    return hwnds[0] if hwnds else None


def _send_appcommand_to_hwnd(hwnd, cmd: int) -> bool:
    """Invia un APPCOMMAND a una specifica HWND."""
    try:
        user32 = ctypes.windll.user32
        SendMessageW = user32.SendMessageW
        SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        SendMessageW.restype = ctypes.c_long
        SendMessageW(hwnd, WM_APPCOMMAND, hwnd, cmd << 16)
        PostMessageW = user32.PostMessageW
        PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        PostMessageW.restype = wintypes.BOOL
        PostMessageW(hwnd, WM_APPCOMMAND, hwnd, cmd << 16)
        return True
    except Exception:
        return False


def _send_appcommand_to_spotify(cmd: int) -> bool:
    """Invia un APPCOMMAND a TUTTE le finestre di Spotify."""
    hwnds = _find_all_spotify_hwnds()
    if not hwnds:
        return False
    sent_any = False
    for hwnd in hwnds:
        if _send_appcommand_to_hwnd(hwnd, cmd):
            sent_any = True
    return sent_any


def _ensure_spotify_running() -> bool:
    """Avvia Spotify se non è in esecuzione."""
    if _get_spotify_pids():
        return True
    spotify_paths = [
        os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WindowsApps\Spotify.exe"),
        "spotify.exe",
    ]
    for sp in spotify_paths:
        try:
            subprocess.Popen([sp])
            for _ in range(20):
                time.sleep(0.3)
                if _find_spotify_main_hwnd():
                    return True
            return True
        except Exception:
            continue
    return False


def _force_foreground(hwnd) -> bool:
    """Forza una finestra in primo piano."""
    try:
        ctypes.windll.user32.ShowWindow(hwnd, 9)
        fg = ctypes.windll.user32.GetForegroundWindow()
        cur_tid = ctypes.windll.kernel32.GetCurrentThreadId()
        fg_tid = ctypes.windll.user32.GetWindowThreadProcessId(fg, None)

        if cur_tid != fg_tid and fg_tid:
            ctypes.windll.user32.AttachThreadInput(cur_tid, fg_tid, True)
            ctypes.windll.user32.BringWindowToTop(hwnd)
            ctypes.windll.user32.SetForegroundWindow(hwnd)
            ctypes.windll.user32.AttachThreadInput(cur_tid, fg_tid, False)
        else:
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def spotify_search_and_play(song: str) -> str:
    """FIX: Usa il nome della traccia TROVATA invece del parametro song.
    
    Questo evita la duplicazione tipo "kid yugi kid yugi".
    """
    if platform.system() != "Windows":
        return "Controllo Spotify disponibile solo su Windows."

    song = (song or "").strip()
    if not song:
        return "Quale canzone vuoi che metta?"

    # Cerca la traccia
    try:
        track = spotify_api.search_track(song)
    except Exception as e:
        print(f"[spotify] errore ricerca: {e}")
        track = None

    if not track or not track.get("uri"):
        return f"Non ho trovato '{song}'."

    # Avvia Spotify
    was_running = bool(_get_spotify_pids())
    _ensure_spotify_running()
    if not was_running:
        time.sleep(1.5)

    # Usa search_and_play con la traccia trovata
    try:
        ok, msg, uri = spotify_api.search_and_play(song, track=track)
        if ok:
            # FIX: Usa il nome della traccia TROVATA, non il parametro song
            # msg contiene già il formato "▶️ Nome Canzone - Artista"
            return msg.replace("▶️ ", "Riproduco ")
        else:
            return msg
    except Exception as e:
        return f"Errore riproduzione: {e}"


def spotify_control(action: str, song: str = "") -> str:
    """Controlla Spotify (play, pause, next, previous)."""
    if platform.system() != "Windows":
        return "Controllo Spotify disponibile solo su Windows."

    action = action.lower().strip()

    try:
        if action in ["play", "riproduci", "metti", "suona", "resume", "riprendi", "continua"]:
            _ensure_spotify_running()
            if _send_appcommand_to_spotify(APPCOMMAND_MEDIA_PLAY):
                return "Riproduco la musica."
            return "Musica ripresa."

        if action in ["pause", "pausa", "metti in pausa", "ferma"]:
            if _send_appcommand_to_spotify(APPCOMMAND_MEDIA_PAUSE):
                return "Musica in pausa."
            return "Musica in pausa."

        if action in ["next", "prossima", "avanti", "successiva", "skip"]:
            if not _send_appcommand_to_spotify(APPCOMMAND_MEDIA_NEXTTRACK):
                return "Errore cambio canzone."
            return "Prossima canzone."

        if action in ["previous", "precedente", "indietro", "prima"]:
            if not _send_appcommand_to_spotify(APPCOMMAND_MEDIA_PREVIOUSTRACK):
                return "Errore cambio canzone."
            return "Canzone precedente."

        return f"Azione Spotify non riconosciuta: {action}"

    except Exception as e:
        return f"Errore controllo Spotify: {e}"


# ========== ALTRI COMANDI DI SISTEMA (invariati) ==========

def execute(action: str) -> str:
    """Esegue azioni di sistema."""
    # ... resto del codice invariato ...
    pass

def set_timer(seconds: int, text: str = "") -> str:
    """Imposta un timer."""
    # ... resto del codice invariato ...
    pass

def calculate(expression: str) -> str:
    """Calcolatrice."""
    # ... resto del codice invariato ...
    pass

def get_system_info(info_type: str = "all") -> str:
    """Info di sistema."""
    # ... resto del codice invariato ...
    pass

def get_datetime() -> str:
    """Data e ora."""
    # ... resto del codice invariato ...
    pass

def save_note(note: str) -> str:
    """Salva nota."""
    # ... resto del codice invariato ...
    pass

def read_notes() -> str:
    """Leggi note."""
    # ... resto del codice invariato ...
    pass
