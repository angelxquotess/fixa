@echo off
echo ========================================
echo JARVIS DESKTOP OFFLINE - Installazione
echo ========================================
echo.

REM Controlla se Jarvis e' in esecuzione (python.exe del venv potrebbe essere lockato)
if exist "venv\Scripts\python.exe" (
    echo [1/4] Ambiente virtuale gia' presente, lo riuso.
) else (
    echo [1/4] Creazione ambiente virtuale Python...
    python -m venv venv
    if errorlevel 1 (
        echo [ERRORE] Impossibile creare ambiente virtuale.
        echo Assicurati di avere Python 3.8+ installato e che Jarvis NON sia in esecuzione.
        pause
        exit /b 1
    )
)

echo [2/4] Attivazione ambiente virtuale...
call venv\Scripts\activate.bat

echo [3/4] Installazione/aggiornamento dipendenze Python...
python -m pip install --upgrade pip
if exist "requirements.txt" (
    pip install -r requirements.txt
)
REM requests serve per il controllo Spotify (cerca e riproduci canzone via token guest)
pip install requests
if errorlevel 1 (
    echo [AVVISO] Installazione dipendenze incompleta.
    echo Se l'errore e' "Access denied" o "in use": chiudi Jarvis e rilancia.
    pause
)

echo [4/4] Download modello Vosk italiano...
python download_vosk.py
if errorlevel 1 (
    echo [AVVISO] Download modello fallito. Scarica manualmente.
)

echo.
echo ========================================
echo Installazione completata!
echo.
echo "Jarvis metti [canzone]" funziona subito senza altri setup.
echo Importante: Spotify Desktop deve essere installato.
echo.
echo Per avviare Jarvis: run.bat
echo ========================================
pause
