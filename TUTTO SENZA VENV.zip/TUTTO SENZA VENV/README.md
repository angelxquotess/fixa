# 🤖 JARVIS DESKTOP OFFLINE - POTENZIATO

**Assistente vocale italiano COMPLETAMENTE OFFLINE** con riconoscimento vocale Vosk, controllo Spotify desktop, modalità vocale avanzata e molto altro.

---

## ⚡ NOVITÀ VERSIONE POTENZIATA

### 🎯 100% Offline
- ✅ **Nessuna connessione internet richiesta**
- ✅ **Risposte istantanee** (nessun blocco o attesa)
- ✅ **Privacy totale** (tutto rimane sul tuo PC)
- ✅ **Funziona ovunque** (anche senza rete)

### 🆕 NUOVE FUNZIONALITÀ ESCLUSIVE

#### 🔊 Sistema Vocale Avanzato
- **Jarvis PARLA SEMPRE** ad ogni risposta (non solo all'inizio!)
- **Modalità silenziosa**: `Jarvis modalità silenziosa` - smette di parlare
- **Riattiva voce**: `Jarvis modalità vocale` - torna a parlare normalmente
- Gestione robusta degli errori TTS con auto-reinizializzazione

#### 🎵 Controllo Spotify DESKTOP Completo
- **Play con ricerca**: `Jarvis riproduci Bohemian Rhapsody`
- **Pausa**: `Jarvis pausa` / `Jarvis metti in pausa`
- **Riprendi**: `Jarvis riprendi` / `Jarvis continua`
- **Prossima canzone**: `Jarvis prossima` / `Jarvis avanti` / `Jarvis skip`
- **Canzone precedente**: `Jarvis precedente` / `Jarvis indietro`
- Usa i **tasti multimediali** per controllare l'app desktop (non il browser!)

#### 🧠 AI Potenziata
- Riconoscimento intent migliorato con più varianti naturali
- Knowledge base locale espansa
- Supporto opzionale **Ollama** per risposte generative illimitate
- Comprensione naturale del linguaggio italiano

---

## 🚀 Funzionalità Complete

### 📱 Controllo Applicazioni
- **Apri app**: `Jarvis apri Spotify / Chrome / Discord / ...`
- **Chiudi app**: `Jarvis chiudi Chrome / Spotify / ...`
- Riconoscimento intelligente con fuzzy matching

### ⏰ Timer e Allarmi
- `Jarvis timer 5 minuti`
- `Jarvis timer 30 secondi`
- `Jarvis sveglia tra 1 ora`
- Supporto per ore, minuti, secondi

### 🧮 Calcolatrice Vocale
- `Jarvis calcola 25 per 4`
- `Jarvis quanto fa 100 diviso 8`
- Supporta: +, -, *, /, parentesi, potenze
- Comprende linguaggio naturale italiano

### 💻 Informazioni Sistema
- `Jarvis quanta RAM ho?`
- `Jarvis quanto spazio disco?`
- `Jarvis quanto usa la CPU?`
- `Jarvis livello batteria?`

### 📝 Appunti Vocali
- `Jarvis annota comprare il latte`
- `Jarvis prendi nota chiamare Mario domani`
- `Jarvis leggi le mie note`
- Note salvate permanentemente in JSON

### 🕐 Data e Ora
- `Jarvis che ore sono?`
- `Jarvis che giorno è oggi?`

### 🔧 Controllo Sistema
- **Volume**: `Jarvis alza/abbassa volume`, `Jarvis muto`
- **Finestre**: `Jarvis chiudi finestra`
- **PC**: `Jarvis spegni/riavvia/blocca il PC`

### 🔍 Ricerca Web
- `Jarvis cerca come fare la carbonara`
- Apre Google con la ricerca

### 💬 Conversazione Intelligente
- Risponde a domande generiche
- Personalità sarcastica stile Iron Man
- Knowledge base per ricette italiane, cultura generale, ecc.

---

## 📦 Installazione Rapida (2 minuti)

### Requisiti
- **Windows 10/11**
- **Python 3.8+** → [Scarica qui](https://www.python.org/downloads/)
  - ⚠️ Durante l'installazione: **spunta "Add Python to PATH"**
- **Microfono funzionante**

### Procedura

1. **Estrai questa cartella** dove preferisci (es. `C:\Jarvis`)

2. **Doppio click su `install.bat`**
   - Crea ambiente virtuale Python
   - Installa tutte le dipendenze
   - Scarica modello Vosk per STT offline (~40MB)

3. **Aspetta il completamento** (1-2 minuti)

4. **Fatto!** Avvia con `run.bat`

---

## 🎮 Utilizzo

### Avvio
Doppio click su **`run.bat`**

### Comandi Vocali Completi

```bash
# ========== MODALITÀ VOCALE (NUOVO!) ==========
Jarvis modalità silenziosa     # Smette di parlare
Jarvis modalità vocale         # Riprende a parlare
Jarvis silenzioso
Jarvis parla

# ========== SPOTIFY DESKTOP (NUOVO!) ==========
Jarvis riproduci Bohemian Rhapsody
Jarvis metti Imagine Dragons
Jarvis pausa                   # Mette in pausa
Jarvis riprendi                # Riprende la musica
Jarvis prossima                # Canzone successiva
Jarvis precedente              # Canzone precedente
Jarvis avanti                  # Skip
Jarvis indietro

# ========== CONTROLLO APP ==========
Jarvis apri Spotify
Jarvis apri Chrome
Jarvis chiudi Chrome
Jarvis chiudi Spotify

# ========== TIMER ==========
Jarvis timer 10 minuti
Jarvis timer 30 secondi
Jarvis sveglia tra 1 ora

# ========== CALCOLI ==========
Jarvis calcola 15 per 3
Jarvis quanto fa 100 diviso 4

# ========== SISTEMA ==========
Jarvis quanta RAM ho?
Jarvis quanto spazio disco?
Jarvis che ore sono?
Jarvis che giorno è oggi?

# ========== NOTE ==========
Jarvis annota studiare per esame
Jarvis leggi le mie note

# ========== VOLUME ==========
Jarvis alza il volume
Jarvis abbassa il volume
Jarvis muto

# ========== RICERCA ==========
Jarvis cerca ricetta tiramisù

# ========== WAKE WORD ==========
Jarvis disattiva wake word     # Ascolto continuo
Jarvis attiva wake word        # Richiede "Jarvis" prima di ogni comando

# ========== USCITA ==========
Jarvis stop
```

---

## ⚙️ Configurazione Avanzata

Modifica il file **`.env`** per personalizzare:

```env
# Wake word on/off
WAKE_WORD_ENABLED=true
WAKE_WORD=jarvis

# Voce (velocità e volume)
TTS_RATE=190        # 100-250 (più alto = più veloce)
TTS_VOLUME=0.9      # 0.0-1.0
```

---

## 🧠 AI Generativa Offline con Ollama (Opzionale)

Di default Jarvis usa una **knowledge base locale** integrata (ricette italiane, FAQ, ecc).

Per risposte generative su **QUALSIASI argomento**, sempre **senza internet** e **senza API key**:

1. **Installa Ollama**: https://ollama.com/download (gratis, open source)

2. **Scarica un modello leggero**:
   ```bash
   ollama pull llama3.2:3b
   # oppure
   ollama pull qwen2.5:3b
   ```

3. **Fatto!** Jarvis rileva Ollama automaticamente e lo usa per risposte avanzate

Esempi con Ollama:
- `Jarvis raccontami una barzelletta`
- `Jarvis spiegami la fotosintesi`
- `Jarvis cos'è l'intelligenza artificiale`

**Tutto rimane in locale**, sul tuo PC. Nessun dato esce mai dalla tua macchina.

---

## 🔧 Risoluzione Problemi

### Microfono non rilevato
- Verifica nelle impostazioni audio di Windows
- Imposta il microfono come dispositivo predefinito

### "Modello Vosk non trovato"
- Riesegui `install.bat` e accetta il download
- Oppure scarica manualmente:
  1. [Modello italiano](https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip)
  2. Estrai nella cartella `models/`

### Voce robotica o troppo veloce
- Modifica `TTS_RATE` in `.env` (valori: 100-250)
- Esempio: `TTS_RATE=150` (più lento)

### "Python non trovato"
- Reinstalla Python e **spunta "Add Python to PATH"**

### Spotify non risponde ai comandi
- Assicurati che l'app desktop Spotify sia installata
- I comandi funzionano meglio con Spotify già aperto
- Verifica che i tasti multimediali della tastiera funzionino

### Jarvis non parla più
- Potresti aver attivato la modalità silenziosa
- Dì: `Jarvis modalità vocale` per riattivare

---

## 📂 Struttura Progetto

```
jarvis_offline/
├── jarvis_offline.py           # Main loop
├── ai_brain_enhanced.py        # Classificazione intent potenziata
├── voice_offline.py            # STT Vosk + TTS pyttsx3 + modalità vocale
├── app_finder_enhanced.py      # Trova/apri/chiudi app
├── system_actions_enhanced.py  # Azioni sistema + Spotify + nuove funzioni
├── local_ai.py                 # Knowledge base + Ollama
├── config.py                   # Configurazione
├── requirements.txt            # Dipendenze Python
├── .env                        # Configurazione utente
├── install.bat                 # Installer automatico
├── run.bat                     # Avvio rapido
├── download_vosk.py            # Download modello STT
├── models/                     # Modelli Vosk (scaricati automaticamente)
└── notes/                      # Note vocali salvate
```

---

## 🎯 Performance

- **Tempo risposta**: <100ms (vs 1-3s con API cloud)
- **RAM utilizzata**: ~150MB
- **CPU idle**: <5%
- **Dimensione totale**: ~100MB (con modello Vosk)

---

## 🆚 Differenze con Versione Originale

| Caratteristica | Originale | Potenziato |
|----------------|-----------|------------|
| **Jarvis parla** | Solo all'inizio | SEMPRE ad ogni risposta ✅ |
| **Modalità silenziosa** | ❌ | ✅ Attivabile con comando |
| **Spotify** | Solo web browser | App DESKTOP + play/pause/next ✅ |
| **Controllo musica** | ❌ | ✅ Pause, resume, skip |
| **Varianti comandi** | Limitate | Moltiplicate (comprensione naturale) ✅ |
| **Gestione errori** | Base | Robusta con auto-recovery ✅ |
| **Knowledge base** | Piccola | Espansa ✅ |
| **STT** | Vosk | Vosk (uguale) |
| **Privacy** | 100% locale | 100% locale |
| **Velocità** | Istantaneo | Istantaneo |

---

## 🚀 Caratteristiche Tecniche

### Tecnologie
- **STT**: Vosk (offline, nessuna API)
- **TTS**: pyttsx3 (offline, sistema Windows)
- **AI**: Knowledge base locale + Ollama opzionale
- **Pattern matching**: Regex + euristiche
- **Controllo sistema**: ctypes + pywin32
- **Controllo Spotify**: Tasti multimediali Windows

### Architettura
- Modular design con separazione responsabilità
- Thread-safe per TTS e timer
- Cache intelligente per ricerca app
- Gestione robusta degli errori con recovery

---

## 🤝 Contributi

Sentiti libero di:
- Espandere la knowledge base in `local_ai.py`
- Aggiungere nuove funzionalità in `system_actions_enhanced.py`
- Migliorare il riconoscimento intent in `ai_brain_enhanced.py`
- Aggiungere app comuni in `app_finder_enhanced.py`

---

## 📜 Licenza

Open Source - Modificabile e distribuibile liberamente

---

## 🙏 Crediti

- **Vosk** per STT offline
- **pyttsx3** per TTS
- **Ollama** per AI generativa locale opzionale
- **psutil** per info sistema
- **Community** per feedback e suggerimenti

---

## 📞 Supporto

Per problemi o domande, verifica prima la sezione **Risoluzione Problemi** sopra.

---

**Versione**: 3.0 Potenziato Offline Complete Edition  
**Autore**: Jarvis Offline Enhanced Team  
**Data**: 2025

---

## 🎊 Divertiti con Jarvis!

Jarvis è ora il tuo assistente personale perfetto: parla sempre, capisce tutto, controlla la musica e molto altro. Tutto offline, tutto privato, tutto istantaneo.

**"Sistemi online. Jarvis a rapporto, signore. Cosa combiniamo oggi?"**
