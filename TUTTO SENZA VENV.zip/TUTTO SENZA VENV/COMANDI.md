# 🎤 JARVIS - GUIDA RAPIDA COMANDI

## 🆕 NUOVI COMANDI PRINCIPALI

### 🔊 Modalità Vocale
```
Jarvis modalità silenziosa     → Smette di parlare
Jarvis modalità vocale         → Riprende a parlare
Jarvis silenzioso
Jarvis parla
```

### 🎵 Spotify Desktop
```
Jarvis riproduci Bohemian Rhapsody
Jarvis metti Imagine Dragons
Jarvis riproduci Coldplay su Spotify

Jarvis pausa
Jarvis metti in pausa
Jarvis ferma la musica

Jarvis riprendi
Jarvis continua
Jarvis vai avanti

Jarvis prossima
Jarvis avanti
Jarvis skip
Jarvis prossima canzone

Jarvis precedente
Jarvis indietro
Jarvis canzone precedente
```

---

## 📱 TUTTI I COMANDI DISPONIBILI

### Applicazioni
```
Jarvis apri Chrome
Jarvis apri Spotify
Jarvis apri Discord
Jarvis chiudi Chrome
Jarvis chiudi Spotify
```

### ⏰ Timer
```
Jarvis timer 5 minuti
Jarvis timer 30 secondi
Jarvis timer 1 ora
Jarvis sveglia tra 10 minuti
```

### 🧮 Calcolatrice
```
Jarvis calcola 25 per 4
Jarvis quanto fa 100 diviso 8
Jarvis calcola 15 più 7
```

### 💻 Info Sistema
```
Jarvis quanta RAM ho?
Jarvis quanto spazio disco?
Jarvis quanto usa la CPU?
Jarvis livello batteria?
```

### 🕐 Data e Ora
```
Jarvis che ore sono?
Jarvis che giorno è oggi?
Jarvis dimmi l'ora
Jarvis data di oggi
```

### 📝 Note Vocali
```
Jarvis annota comprare il latte
Jarvis prendi nota chiamare Mario
Jarvis ricorda appuntamento domani
Jarvis leggi le mie note
Jarvis mostra note
```

### 🔊 Volume
```
Jarvis alza il volume
Jarvis abbassa il volume
Jarvis muto
Jarvis silenzia
```

### 🔧 Sistema
```
Jarvis chiudi finestra
Jarvis blocca il PC
Jarvis spegni il PC
Jarvis riavvia il PC
```

### 🔍 Ricerca Web
```
Jarvis cerca ricetta carbonara
Jarvis googla intelligenza artificiale
Jarvis trova come fare la pizza
```

### 💬 Conversazione
```
Jarvis ciao
Jarvis come stai?
Jarvis chi sei?
Jarvis cosa sai fare?
Jarvis ci sei?
Jarvis grazie
```

### ⚙️ Wake Word
```
Jarvis attiva wake word         → Serve dire "Jarvis" prima di ogni comando
Jarvis disattiva wake word      → Ascolto continuo
```

### 🚪 Uscita
```
Jarvis stop
Jarvis spegniti
Jarvis esci
```

---

## 🎯 ESEMPI DI UTILIZZO

### Scenario 1: Lavoro
```
Jarvis apri Chrome
Jarvis apri Spotify
Jarvis riproduci musica ambient
Jarvis modalità silenziosa
[lavori in silenzio]
Jarvis modalità vocale
Jarvis timer 25 minuti
```

### Scenario 2: Musica
```
Jarvis riproduci Queen
[ascolta]
Jarvis prossima
[non ti piace]
Jarvis prossima
[meglio]
Jarvis alza il volume
```

### Scenario 3: Promemoria
```
Jarvis annota comprare il pane
Jarvis annota chiamare medico
Jarvis timer 1 ora per ricordare
[dopo un'ora]
Jarvis leggi le mie note
```

### Scenario 4: Info
```
Jarvis che ore sono?
Jarvis quanta RAM uso?
Jarvis quanto spazio disco?
Jarvis livello batteria?
```

---

## 💡 TIPS & TRICKS

### 1. Varianti Naturali
Jarvis capisce MOLTE varianti dello stesso comando:
- "Jarvis pausa" = "Jarvis metti in pausa" = "Jarvis ferma"
- "Jarvis riprendi" = "Jarvis continua" = "Jarvis vai avanti"
- "Jarvis prossima" = "Jarvis avanti" = "Jarvis skip"

### 2. Modalità Silenziosa
- Utile quando lavori e non vuoi disturbi
- Jarvis continua a funzionare, solo non parla
- Riattiva quando vuoi con "modalità vocale"

### 3. Spotify Desktop
- I comandi funzionano anche con altre app musicali
- Usa i tasti multimediali della tastiera
- Funziona meglio con Spotify già aperto

### 4. Wake Word
- ON: devi dire "Jarvis" prima di ogni comando
- OFF: basta parlare, ascolta sempre
- Scegli in base alle tue preferenze

### 5. Timer Multipli
- Puoi impostare più timer contemporaneamente
- Jarvis parla anche in modalità silenziosa per i timer

---

## 🚀 COMANDI RAPIDI PREFERITI

```bash
# Setup musica + lavoro
Jarvis apri Spotify
Jarvis riproduci lofi hip hop
Jarvis modalità silenziosa
Jarvis timer 25 minuti

# Info rapida sistema
Jarvis quanta RAM ho?
Jarvis livello batteria?

# Controllo musica veloce
Jarvis pausa
Jarvis riprendi
Jarvis prossima

# Promemoria
Jarvis annota [cosa fare]
Jarvis timer [tempo]
```

---

## 📞 RISOLUZIONE PROBLEMI

### Jarvis non risponde
→ Verifica wake word: "Jarvis attiva wake word"

### Non sento Jarvis
→ Potresti essere in modalità silenziosa: "Jarvis modalità vocale"

### Spotify non funziona
→ Assicurati che l'app desktop sia installata e aperta

### Microfono non rileva
→ Verifica impostazioni audio Windows

---

## 🎊 DIVERTITI CON JARVIS!

Jarvis è il tuo assistente personale perfetto:
- ✅ Completamente offline
- ✅ Privacy totale
- ✅ Risposte istantanee
- ✅ Comprende linguaggio naturale
- ✅ Sempre pronto ad aiutarti

**"Sistemi online. Jarvis a rapporto, signore!"** 🤖
