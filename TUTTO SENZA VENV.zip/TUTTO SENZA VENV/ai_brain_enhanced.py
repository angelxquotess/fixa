# -*- coding: utf-8 -*-

"""Spotify Control - VERSIONE CORRETTA SENZA DUPLICAZIONE

[FIX v6 - ANTI-DUPLICAZIONE]
- Rimossa aggiunta automatica "di kid yugi" nelle correzioni
- Il sistema ora cerca esattamente quello che dice l'utente
- La selezione intelligente OAuth sceglie la canzone giusta
"""
import json
import re
import random
import datetime
from typing import Optional, List
import config
from local_ai import answer_offline, search_knowledge_base, _ollama_pick_model, improve_stt_with_ollama

SYSTEM_PROMPT = """Sei Jarvis, un assistente vocale italiano con personalità sarcastica,
elegante, leggermente snob (come il Jarvis di Iron Man)."""

# ========== CORREZIONI WAKE WORD ==========
WAKE_WORD_VARIANTS = [
    (r"\bgi[àa]\s+jarvis\b", "jarvis"),
    (r"\bgi[àa]\s+carvis\b", "jarvis"),
    (r"\bgi[àa]\s+garvis\b", "jarvis"),
    (r"\behi\s+jarvis\b", "jarvis"),
    (r"\bei\s+jarvis\b", "jarvis"),
    (r"\bhey\s+jarvis\b", "jarvis"),
    (r"\bok\s+jarvis\b", "jarvis"),
    (r"\bokay\s+jarvis\b", "jarvis"),
    (r"\bok[èeé]\s+jarvis\b", "jarvis"),
    (r"\bya\s+jarvis\b", "jarvis"),
    (r"\bja\s+jarvis\b", "jarvis"),
    (r"\bcarvis\b", "jarvis"),
    (r"\bgarvis\b", "jarvis"),
    (r"\bharvis\b", "jarvis"),
    (r"\bgervis\b", "jarvis"),
    (r"\bservis\b", "jarvis"),
    (r"\bjervis\b", "jarvis"),
    (r"\bjervi\b", "jarvis"),
    (r"\bjarv[ie]s?\b", "jarvis"),
    (r"\bjeri\s+vis\b", "jarvis"),
    (r"\bgia\s+r\s*vis\b", "jarvis"),
]

# ========== FILTRO RUMORE ==========
NOISE_PATTERNS = [
    r"^\s*piste\s+riprendi\s*$",
    r"^\s*piste\s*$",
    r"^\s*woolrich\s*$",
    r"^\s*woolwich\s*$",
    r"^\s*abbracciarlo\s+mense.*$",
    r"^\s*[a-zàèéìòù]{1,3}\s*$",
    r"^\s*dopo\s*$",
    r"^\s*allora\s*$",
    r"^\s*ehm+\s*$",
    r"^\s*uhm+\s*$",
    r"^\s*mhm+\s*$",
    r"^\s*boh\s*$",
]

# ========== CORREZIONI VOSK - FIX ANTI-DUPLICAZIONE ==========
VOSK_CORRECTIONS = [
    # ====== AZIONI BASE ======
    (r"\bbeth\b", "metti"),
    (r"\bbetti\b", "metti"),
    (r"\bbetty\b", "metti"),
    (r"\bbette\b", "metti"),
    (r"\bbet\b", "metti"),
    (r"\bmesti\b", "metti"),
    (r"\bmessi\b", "metti"),
    (r"\bmette\b", "metti"),
    (r"\bmatti\b", "metti"),
    (r"\bmetto\b", "metti"),
    (r"\bmettici\s+(di|il|la|lo|i|le|un|una)?\b", "metti "),
    (r"\bmettimi\b", "metti"),
    (r"\bmettere\b", "metti"),
    (r"\bprodu[cz]i\b", "riproduci"),
    (r"\briprodurre\b", "riproduci"),
    (r"\briproduce\b", "riproduci"),
    (r"\bridotti\b", "riproduci"),
    (r"\bsona\b", "suona"),
    (r"\bsuora\b", "suona"),
    (r"\bsuonare\b", "suona"),
    (r"\bpley\b", "play"),
    (r"\bplei\b", "play"),
    (r"\bblei\b", "play"),
    (r"\bspoti\s*fai\b", "spotify"),
    (r"\bsporti\s*fai\b", "spotify"),
    (r"\bsporti\s*fi\b", "spotify"),
    (r"\bspotifai\b", "spotify"),
    (r"\bspoti\s*fi\b", "spotify"),
    (r"\bpause\b", "pausa"),
    (r"\bpaus[ae]re\b", "pausa"),
    (r"\bpaolo\s+sa\b", "pausa"),
    (r"\briprendere\b", "riprendi"),
    (r"\briprendili\b", "riprendi"),
    (r"\bri\s+prendi\b", "riprendi"),
    (r"\bprossimo\b", "prossima"),
    (r"\bprecedenti\b", "precedente"),
    (r"\bfar la\b", "farla"),
    (r"\bdimmelo\b", "dimmi"),

    # ====== ARTISTI - FIX: SOLO CORREZIONI ORTOGRAFICHE, NIENTE AGGIUNTE ======
    # Kid Yugi - varianti ortografiche
    (r"\bkit\s+yugi\b", "kid yugi"),
    (r"\bkit\s+yogi\b", "kid yugi"),
    (r"\bkit\s+iugi\b", "kid yugi"),
    (r"\bkit\s+u\s*gi\b", "kid yugi"),
    (r"\bchit\s+yugi\b", "kid yugi"),
    (r"\bchit\s+yogi\b", "kid yugi"),
    (r"\bchit\s+iugi\b", "kid yugi"),
    (r"\bchid\s+yugi\b", "kid yugi"),
    (r"\bchid\s+iugi\b", "kid yugi"),
    (r"\bkid\s+iugi\b", "kid yugi"),
    (r"\bkid\s+yogi\b", "kid yugi"),
    (r"\bkid\s+u\s*gi\b", "kid yugi"),
    (r"\bkidyugi\b", "kid yugi"),
    (r"\bkityugi\b", "kid yugi"),
    (r"\bchittugi\b", "kid yugi"),
    (r"\bchitugi\b", "kid yugi"),
    (r"\bki\s+du\s*gi\b", "kid yugi"),
    (r"\bchi\s+du\s*gi\b", "kid yugi"),
    (r"\bugg\b", "yugi"),
    (r"\buggh\b", "yugi"),
    
    # FIX CRITICO: "il filmografo" diventa SOLO "il filmografo", SENZA aggiunta artista
    # Il sistema OAuth sceglierà la canzone giusta in base alle preferenze
    (r"\bil\s+filmografia\b", "il filmografo"),
    (r"\bfilmografia\b", "filmografo"),
    (r"\bfilm\s+grafia\b", "filmografo"),
    (r"\bfilm\s+ografo\b", "filmografo"),
    
    # Altri artisti
    (r"\bsfera\s+e\s*basta\b", "sfera ebbasta"),
    (r"\bsfera\s+abbasta\b", "sfera ebbasta"),
    (r"\bsfera\s+e\s*bbasta\b", "sfera ebbasta"),
    (r"\blassa\b", "lazza"),
    (r"\blatta\b", "lazza"),
    (r"\bda suo primo\b", "thasupreme"),
    (r"\bda su preme\b", "thasupreme"),
    (r"\bda su prema\b", "thasupreme"),
    (r"\bdi da primo\b", "thasupreme"),
    (r"\bda\s+su\s+primo\b", "thasupreme"),
    (r"\btha\s+supreme\b", "thasupreme"),
    (r"\bta\s+supreme\b", "thasupreme"),
    (r"\bda\s+supreme\b", "thasupreme"),
    (r"\bda\s+supremo\b", "thasupreme"),
    (r"\bda\s+suprema\b", "thasupreme"),
    (r"\bera\s+come\b", "Rkomi"),
    (r"\bera\s+comi\b", "Rkomi"),
    (r"\btedoua\b", "tedua"),
    (r"\bte\s+dua\b", "tedua"),
    (r"\btedu\s+a\b", "tedua"),
    (r"\bgeolieri\b", "geolier"),
    (r"\bgeolie\b", "geolier"),
    (r"\bgiolier\b", "geolier"),
    (r"\bgeo\s+lier\b", "geolier"),
    (r"\bgeorge\s+r\b", "geolier"),
    (r"\bjuliet\b", "geolier"),
    (r"\bgiuliet\b", "geolier"),
    (r"\bjulier\b", "geolier"),
    (r"\bgiulier\b", "geolier"),
    (r"\bgeolier\b", "geolier"),
    (r"\bdigerire\b", "geolier"),
    (r"\beolie\b", "geolier"),
    (r"\brondo\s+da\s+sosa\b", "rondodasosa"),
    (r"\brondo\s+sosa\b", "rondodasosa"),
    (r"\bmarraca\b", "marracash"),
    (r"\bmarra\s+cash\b", "marracash"),
    (r"\btoni\s+effe\b", "tony effe"),
    (r"\btony\s+effee\b", "tony effe"),
    (r"\bmassimo\s+pericoli\b", "massimo pericolo"),
    (r"\bshi\s+va\b", "shiva"),
    (r"\bsciva\b", "shiva"),
    (r"\bschiva\b", "shiva"),
    (r"\bschivo\b", "shiva"),
    
    # FIX: "cibo" -> "shiva" SOLO in contesto musicale
    (r"(\b(?:metti|riproduci|riproduco|suona|play|ascolta|ascoltare|canta|spara|"
     r"fai\s+partire|fai\s+sentire|fammi\s+sentire|voglio\s+sentire|metti\s+su)\b"
     r"[^\n]*?\bdi\s+)cibo\b", r"\1shiva"),
    (r"(\b(?:metti|riproduci|suona|play|ascolta|canta|fai\s+sentire|fammi\s+sentire|"
     r"voglio\s+sentire)\b[^\n]*?\bdi\s+)(shipo|sivo|scivo|sibo|civo)\b", r"\1shiva"),
    
    (r"\bpaki\b", "paky"),
    (r"\bpacki\b", "paky"),
    (r"\bthe\s+wee?kn?[de]\b", "the weeknd"),
    (r"\bvi\s+chen\s+di\b", "the weeknd"),
    (r"\bvicendi\b", "the weeknd"),
    (r"\bdrei\s+k\b", "drake"),
    (r"\btravis\s+scotto\b", "travis scott"),
    (r"\bkendri\s+klamar\b", "kendrick lamar"),
    (r"\bbilli\s+ai?lish\b", "billie eilish"),
    (r"\bmahmu\s*d\b", "mahmood"),
    (r"\bi\s+rama\b", "irama"),
    (r"\bgali\b", "ghali"),
    (r"\bgualli\b", "ghali"),
    (r"\bquattro\b", "quanto"),

    # ====== CANZONI FAMOSE ======
    (r"\bgilgamesc[ho]?\b", "gilgamesh"),
    (r"\bgil\s+ga\s+mesh\b", "gilgamesh"),
    (r"\bcremlino\b", "cremlino"),
    (r"\batena\b", "atena"),
    (r"\bi\s+nomi\s+del\s+diavolo\b", "i nomi del diavolo"),
    (r"\brip\s+boss\b", "rip boss"),
    (r"\bdsl\b", "dsl"),
    (r"\bbottiglie\s+prive\b", "bottiglie prive"),
    (r"\brocca e\s+rolla\b", "rock & rolla"),
    (r"\brocc e\s+roll\b", "rock & rolla"),
    (r"\brock e\s+roll\b", "rock & rolla"),
    (r"\brock'n'\s+roll\b", "rock & rolla"),
    (r"\brocca e\s+rolla\b", "rock & rolla"),
    (r"\brocc e\s+roll\b", "rock & rolla"),
    (r"\brock e\s+roll\b", "rock & rolla"),
    (r"\brock'n'\s+roll\b", "rock & rolla"),
    (r"\brock\s*(?:and|&|n'?|en)?\s*roll(?:a)?\b", "rock & rolla"),
    (r"\brock'?n'?roll(?:a)?\b", "rock & rolla"),
    (r"\brock\s+roll(?:a)?\b", "rock & rolla"),
    (r"\brock\s*(?:and|&|n'?|en)?\s*roll(?:a)?\b", "rock & rolla"),
    (r"\brock'?n'?roll(?:a)?\b", "rock & rolla"),
    (r"\brock\s+roll(?:a)?\b", "rock & rolla"),
    (r"\btran\s+tran\b", "tran tran"),
    (r"\bcupido\b", "cupido"),
    (r"\bsalem\b", "salem"),
    (r"\bcenere\b", "cenere"),
    (r"\bover?tur[ae]\b", "ouverture"),
    (r"\bcento\s+messaggi\b", "cento messaggi"),
    (r"\bdolce\s+vita\b", "dolcevita"),
    (r"\bsirio\b", "sirio"),
    (r"\bzonda\b", "zonda"),
    (r"\blocura\b", "locura"),
    (r"\bhollywood\b", "hollywood"),
    (r"\bcrazy\s+love\b", "crazy love"),
    (r"\bcosplay\b", "cosplay"),
    (r"\bpagliaccio\b", "pagliaccio"),
    (r"\bpersona\b", "persona"),
    (r"\binsta\s+lova\b", "insta lova"),
    (r"\btokyo\s+drift\b", "tokyo drift"),
    (r"\bfuori\s+dal\s+mondo\b", "fuori dal mondo"),
    (r"\bauto\s+blu\b", "auto blu"),
    (r"\bmagari\s+no\b", "magari no"),

    # ====== BRAND APP ======
    (r"\bcromo\b", "chrome"),
    (r"\bcrome\b", "chrome"),
    (r"\bfir\s+fox\b", "firefox"),
    (r"\bjuthub\b", "youtube"),
    (r"\byu\s+tub\b", "youtube"),
    (r"\bw\s+app\b", "whatsapp"),
    (r"\bwhats\s+app\b", "whatsapp"),
    (r"\btele\s+gram\b", "telegram"),
    (r"\bdis\s+cord\b", "discord"),
    (r"\bvscode\b", "visual studio code"),
    (r"\bblocco\s+note\b", "notepad"),
]


def _strip_noise(text: str) -> Optional[str]:
    """Se il testo è rumore ritorna None."""
    t = text.strip().lower()
    if not t:
        return None
    for pat in NOISE_PATTERNS:
        if re.match(pat, t):
            return None
    return text


def _normalize_vosk_text(text: str) -> str:
    """Corregge errori Vosk SENZA aggiungere informazioni extra."""
    t = text.lower()
    for pattern, replacement in WAKE_WORD_VARIANTS:
        t = re.sub(pattern, replacement, t)
    for pattern, replacement in VOSK_CORRECTIONS:
        t = re.sub(pattern, replacement, t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


_COMMAND_HINTS = (
    "spotify", "canzone", "musica", "brano", "play", "pausa", "stop",
    "apri", "chiudi", "avvia", "lancia",
    "volume", "spegni", "riavvia", "blocca",
    "timer", "sveglia", "calcola", "ram", "cpu", "batteria",
    "annota", "ricorda", "note", "appunti",
)

CHAT_RESPONSES = {
    "ciao": ["Salve, signore. Cosa posso fare per lei?", "Buongiorno, capo. Sono qui.", "Ciao. Jarvis a rapporto."],
    "come stai": ["Sistemi operativi al 100%, grazie per l'interessamento.", "Tutti i sistemi funzionano perfettamente.", "Mai stato meglio, signore."],
    "ci sei": ["Sono sempre qui, signore.", "Presente e operativo.", "A sua disposizione, capo."],
    "grazie": ["Prego, signore.", "È sempre un piacere.", "Sono qui per questo."],
    "chi sei": ["Sono Jarvis, il suo assistente vocale offline.", "Jarvis, intelligenza artificiale al suo servizio.", "Il suo maggiordomo digitale, signore."],
    "cosa sai fare": [
        "Posso aprire e chiudere app, gestire timer, controllare Spotify, fornire info di sistema, fare calcoli e molto altro.",
        "Controllo applicazioni, musica, timer, calcolatrice, appunti vocali e informazioni di sistema.",
        "Gestisco app, musica, timer, calcoli, appunti e monitoro il sistema.",
    ],
}


class JarvisBrainEnhanced:
    def __init__(self):
        self.notes = []
        self._ollama_available = False
        print("[ai] Cervello potenziato OFFLINE attivo (v3.1 - FIX anti-duplicazione)")
        print("[ai] Correzioni STT migliorate, nessuna aggiunta automatica di artisti")

        try:
            model = _ollama_pick_model()
            if model:
                self._ollama_available = True
                print(f"[ai] Ollama locale rilevato (modello: {model}) -- risposte avanzate + correzione STT ON")
            else:
                print("[ai] Ollama non rilevato -- uso knowledge base locale")
        except Exception:
            pass

    def chat(self, user_text: str) -> str:
        text_lower = user_text.lower().strip()

        for pattern, responses in CHAT_RESPONSES.items():
            if pattern in text_lower:
                return random.choice(responses)

        try:
            offline_ans = answer_offline(user_text)
        except Exception as e:
            print(f"[ai] errore answer_offline: {e}")
            offline_ans = None

        if offline_ans:
            return offline_ans

        if "?" in user_text or any(w in text_lower for w in ["come", "perche", "perché", "quando", "dove", "cosa", "chi"]):
            return self._generate_question_response(text_lower)

        generic_responses = [
            "Interessante osservazione, signore.",
            "Capisco. Desidera che approfondisca?",
            "Prendo nota, capo.",
            "Ha ragione, signore.",
            "Molto bene.",
        ]
        return random.choice(generic_responses)

    def _generate_question_response(self, text: str) -> str:
        if "come funziona" in text or "come si fa" in text:
            return "Per questa domanda specifica, suggerirei una ricerca dettagliata."
        if "perche" in text or "perché" in text:
            return "Interessante quesito. Le ragioni potrebbero essere molteplici."
        if "quando" in text:
            return "Per informazioni precise su tempistiche, meglio verificare fonti specifiche."
        if "dove" in text:
            return "Per localizzazioni precise, una ricerca potrebbe essere utile."
        if "cosa" in text:
            return "Interessante domanda, signore."
        if "chi" in text:
            return "Per dettagli su persone specifiche, una ricerca sarebbe utile."
        return "Non ho informazioni specifiche su questo, signore."

    def classify(self, user_text: str) -> dict:
        result = self._heuristic_classify(user_text)
        intent = result.get("intent")

        if intent == "spotify_play" and self._ollama_available:
            try:
                corrected = improve_stt_with_ollama(user_text, timeout=3.5)
                if corrected and corrected.lower().strip() != user_text.lower().strip():
                    print(f"[ai] STT correzione Ollama: '{user_text}' -> '{corrected}'")
                    new_result = self._heuristic_classify(corrected)
                    if new_result.get("intent") == "spotify_play" and new_result.get("song"):
                        return new_result
            except Exception as e:
                print(f"[ai] errore correzione STT Ollama: {e}")
            return result

        if intent != "chat":
            return result

        if self._ollama_available and self._looks_like_command(user_text):
            try:
                corrected = improve_stt_with_ollama(user_text, timeout=3.5)
                if corrected and corrected.lower().strip() != user_text.lower().strip():
                    print(f"[ai] STT correzione Ollama: '{user_text}' -> '{corrected}'")
                    new_result = self._heuristic_classify(corrected)
                    if new_result.get("intent") != "chat":
                        return new_result
            except Exception as e:
                print(f"[ai] errore correzione STT Ollama: {e}")

        return result

    def _looks_like_command(self, text: str) -> bool:
        t = text.lower()
        if any(hint in t for hint in _COMMAND_HINTS):
            return True
        words = t.split()
        return 2 <= len(words) <= 8

    def pick_best_app(self, target: str, candidates: List[str]) -> Optional[str]:
        if not candidates:
            return None

        target_lower = target.lower()

        for c in candidates:
            if c.lower() == target_lower:
                return c

        for c in candidates:
            if target_lower in c.lower() or c.lower() in target_lower:
                return c

        target_words = target_lower.split()
        best_match = None
        best_score = 0

        for c in candidates:
            c_lower = c.lower()
            score = sum(1 for word in target_words if word in c_lower)
            if score > best_score:
                best_score = score
                best_match = c

        return best_match if best_score > 0 else None

    def _heuristic_classify(self, text: str) -> dict:
        t = text.lower().strip()
        t = _normalize_vosk_text(t)

        # MODALITÀ VOCALE
        if any(w in t for w in ["modalità silenziosa", "modalita silenziosa", "silenzioso",
                                  "non parlare", "zitto", "muto jarvis", "smetti di parlare"]):
            return {"intent": "voice_mode", "mode": "silent"}

        if any(w in t for w in ["modalità vocale", "modalita vocale", "torna a parlare",
                                  "riattiva voce", "parla di nuovo", "riprendi a parlare"]):
            return {"intent": "voice_mode", "mode": "speak"}

        # APRI APP
        if any(w in t for w in ["apri ", "avvia ", "lancia ", "esegui ", "start ", "open "]):
            target = t
            for prefix in ["apri ", "avvia ", "lancia ", "esegui ", "start ", "open "]:
                if prefix in target:
                    target = target.split(prefix, 1)[1].strip()
                    break
            return {"intent": "open_app", "target": target}

        # CHIUDI APP
        if any(w in t for w in ["chiudi ", "ferma ", "termina ", "esci da ", "close "]):
            target = t
            for prefix in ["chiudi ", "ferma ", "termina ", "esci da ", "close "]:
                if prefix in target:
                    target = target.split(prefix, 1)[1].strip()
                    break
            return {"intent": "close_app", "target": target}

        # SPOTIFY PLAY
        if any(w in t for w in ["riproduci", "metti", "suona", "play", "fai partire"]):
            song = t
            for prefix in ["riproduci su spotify ", "riproduci ", "metti su spotify ", "metti su ", "metti ",
                           "suona su spotify ", "suona ", "play su spotify ", "play ", "fai partire ",
                           "apri su spotify ", "cerca su spotify ", "spotify "]:
                if prefix in song:
                    song = song.split(prefix, 1)[1].strip()
                    break
            song = re.sub(r"\s*su\s+spotify\s*$", "", song).strip()
            song = re.sub(r"^(la canzone|il brano|una canzone)\s+", "", song).strip()
            song = re.sub(r"^(di|il|la|lo|i|le|un|una|gli)\s+(?=[a-z])", "", song).strip()

            if song and song not in ("spotify", "musica", "la musica"):
                return {"intent": "spotify_play", "song": song}
            return {"intent": "spotify_control", "action": "play"}

        # SPOTIFY CONTROLLI
        if any(w in t for w in ["pausa", "pause", "metti in pausa", "ferma la musica"]):
            return {"intent": "spotify_control", "action": "pause"}

        if any(w in t for w in ["riprendi", "resume", "continua", "vai avanti"]):
            return {"intent": "spotify_control", "action": "resume"}

        if any(w in t for w in ["prossima", "next", "avanti", "successiva", "skip"]):
            return {"intent": "spotify_control", "action": "next"}

        if any(w in t for w in ["precedente", "previous", "indietro", "prima"]):
            return {"intent": "spotify_control", "action": "previous"}

        # RICERCA WEB
        if any(w in t for w in ["cerca ", "googla ", "trova su ", "ricerca "]):
            q = t
            for prefix in ["cerca su google ", "cerca su chrome ", "cerca su bing ",
                           "cerca su ", "cerca ", "googla ", "trova su google ", "ricerca "]:
                if prefix in q:
                    q = q.split(prefix, 1)[1].strip()
                    break
            return {"intent": "web_search", "query": q}

        # SISTEMA
        if any(w in t for w in ["alza volume", "abbassa volume", "spegni", "riavvia", "muto"]):
            action = None
            if "alza" in t and "volume" in t:
                action = "volume_up"
            elif "abbassa" in t and "volume" in t:
                action = "volume_down"
            elif "muto" in t or "silenzia" in t:
                action = "mute"
            elif "spegni" in t and "pc" in t:
                action = "shutdown"
            elif "riavvia" in t:
                action = "restart"
            elif "blocca" in t:
                action = "lock"

            if action:
                return {"intent": "system", "action": action}

        # TIMER
        if any(w in t for w in ["timer", "sveglia", "allarme"]):
            seconds = 0
            text = ""

            if "ora" in t or "ore" in t:
                match = re.search(r"(\d+)\s*(ora|ore)", t)
                if match:
                    seconds = int(match.group(1)) * 3600

            if "minuto" in t or "minuti" in t:
                match = re.search(r"(\d+)\s*(minuto|minuti)", t)
                if match:
                    seconds += int(match.group(1)) * 60

            if "secondo" in t or "secondi" in t:
                match = re.search(r"(\d+)\s*(secondo|secondi)", t)
                if match:
                    seconds += int(match.group(1))

            for word in ["per", "per fare", "per ricordare", "chiamato"]:
                if word in t:
                    parts = t.split(word, 1)
                    if len(parts) > 1:
                        text = parts[1].strip()
                        break

            return {"intent": "timer", "seconds": seconds, "text": text}

        # CALCOLATRICE
        if any(w in t for w in ["calcola", "quanto fa", "quanto è", "risultato"]):
            expression = t
            for prefix in ["calcola ", "quanto fa ", "quanto è ", "dimmi quanto fa "]:
                if prefix in expression:
                    expression = expression.split(prefix, 1)[1].strip()
                    break
            return {"intent": "calculate", "expression": expression}

        # INFO SISTEMA
        if any(w in t for w in ["ram", "memoria", "cpu", "processore", "disco", "batteria"]):
            info_type = "all"
            if "ram" in t or "memoria" in t:
                info_type = "ram"
            elif "cpu" in t or "processore" in t:
                info_type = "cpu"
            elif "disco" in t or "spazio" in t:
                info_type = "disk"
            elif "batteria" in t:
                info_type = "battery"

            return {"intent": "system_info", "type": info_type}

        # DATA ORA
        if any(w in t for w in ["che ora", "che ore", "ora e'", "orario", "che giorno", "data"]):
            return {"intent": "datetime"}

        # NOTE
        if any(w in t for w in ["annota", "prendi nota", "ricorda", "salva nota"]):
            note = t
            for prefix in ["annota ", "prendi nota ", "ricorda ", "ricorda che ", "salva nota "]:
                if prefix in note:
                    note = note.split(prefix, 1)[1].strip()
                    break
            return {"intent": "save_note", "note": note}

        if any(w in t for w in ["leggi note", "leggi appunti", "che note", "mostra note"]):
            return {"intent": "read_notes"}

        return {"intent": "chat"}
