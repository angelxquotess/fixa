"""
shortcuts_manager.py
--------------------
Sistema di scorciatoie vocali personalizzate create a voce.

Flusso conversazionale:
  Utente: "jarvis crea scorciatoia"
  Jarvis: "Come si chiama la scorciatoia?"
  Utente: "twitch"
  Jarvis: "Cosa devo fare quando dico twitch?"
  Utente: "apri twitch sul browser"   (o "apri l'app twitch", o url diretto)
  Jarvis: "Fatto. Adesso, dicendo 'jarvis twitch', aprirò Twitch sul browser."

Tipi di azione supportati:
  - app:   apre un'applicazione installata (via app_finder)
  - url:   apre una URL nel browser di default
  - cmd:   esegue un comando shell (Windows .bat / .exe / start ...)
  - macro: sequenza di comandi (lista)

Storage: shortcuts.json nella cartella del progetto.
"""
from __future__ import annotations

import json
import re
import webbrowser
from pathlib import Path
from typing import Callable

SHORTCUTS_FILE = Path(__file__).parent / "shortcuts.json"


def _load() -> dict:
    if not SHORTCUTS_FILE.exists():
        return {}
    try:
        return json.loads(SHORTCUTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: dict):
    SHORTCUTS_FILE.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )


# -----------------------------------------------------------------------------
# Parsing dell'azione descritta a voce
# -----------------------------------------------------------------------------
_URL_RX = re.compile(r"https?://\S+")
_DOMAIN_RX = re.compile(r"\b([a-z0-9-]+\.[a-z]{2,}(?:/\S*)?)\b", re.IGNORECASE)


def parse_action(description: str) -> dict:
    """
    Converte la descrizione parlata in una azione strutturata.

    Esempi:
      "apri twitch sul browser"     -> {"type":"url", "target":"https://twitch.tv"}
      "apri l'app twitch"           -> {"type":"app", "target":"twitch"}
      "apri https://github.com"     -> {"type":"url", "target":"https://github.com"}
      "esegui notepad"              -> {"type":"app", "target":"notepad"}
    """
    text = description.strip().lower()

    # 1. URL esplicito
    m = _URL_RX.search(description)
    if m:
        return {"type": "url", "target": m.group(0)}

    # 2. dominio senza http
    m = _DOMAIN_RX.search(text)
    if m and "app" not in text:
        return {"type": "url", "target": "https://" + m.group(1)}

    # 3. parole chiave "browser" / "sito"  -> url
    web_kw = re.search(r"\b(browser|sito|web|chrome|firefox|edge)\b", text)
    app_kw = re.search(r"\b(app|applicazione|programma|software|desktop)\b", text)

    # estrai il nome target rimuovendo verbi/preposizioni
    cleaned = re.sub(
        r"\b(apri|esegui|avvia|lancia|fai partire|fammi partire|mi apri|mostra|"
        r"l'|lo|la|il|sul|sull'|su|in|con|del|della|app|applicazione|programma|"
        r"browser|sito|web|desktop)\b",
        " ",
        text,
    )
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .,'")

    if not cleaned:
        cleaned = text

    if web_kw and not app_kw:
        # tipo URL: prova a derivare dominio noto
        known = {
            "twitch": "https://twitch.tv",
            "youtube": "https://youtube.com",
            "google": "https://google.com",
            "github": "https://github.com",
            "spotify": "https://open.spotify.com",
            "netflix": "https://netflix.com",
            "twitter": "https://twitter.com",
            "x": "https://x.com",
            "instagram": "https://instagram.com",
            "discord": "https://discord.com/app",
            "reddit": "https://reddit.com",
            "amazon": "https://amazon.it",
        }
        for k, url in known.items():
            if k in cleaned:
                return {"type": "url", "target": url}
        return {"type": "url", "target": "https://" + cleaned.split()[0] + ".com"}

    # default -> app
    return {"type": "app", "target": cleaned.split()[0] if cleaned else "notepad"}


# -----------------------------------------------------------------------------
# Manager principale
# -----------------------------------------------------------------------------
class ShortcutsManager:
    """
    Stato conversazionale:
      mode = None | 'await_name' | 'await_action' | 'await_confirm'
    """

    def __init__(self, app_opener: Callable[[str], bool] | None = None):
        """
        app_opener: funzione che prova ad aprire un'app installata.
                    Tipicamente system_actions_enhanced.open_app
                    Deve ritornare True se è riuscita.
        """
        self.data = _load()
        self.mode: str | None = None
        self._pending_name: str | None = None
        self._pending_action: dict | None = None
        self.app_opener = app_opener

    # ---- query ----------------------------------------------------------
    def list_names(self) -> list[str]:
        return sorted(self.data.keys())

    def find(self, text: str) -> dict | None:
        """Trova scorciatoia matchando l'intero comando utente."""
        t = text.lower().strip()
        # match esatto su tutto il testo (es. "twitch")
        if t in self.data:
            return self.data[t]
        # match: una delle parole è uno shortcut
        for name in self.data:
            if re.search(rf"\b{re.escape(name)}\b", t):
                return self.data[name]
        return None

    def delete(self, name: str) -> bool:
        name = name.lower().strip()
        if name in self.data:
            del self.data[name]
            _save(self.data)
            return True
        return False

    # ---- esecuzione -----------------------------------------------------
    def run(self, action: dict) -> str:
        t = action.get("type")
        target = action.get("target", "")
        if t == "url":
            webbrowser.open(target)
            return f"Apertura {target}"
        if t == "app":
            if self.app_opener and self.app_opener(target):
                return f"Aperto {target}"
            # fallback browser cercando il sito
            webbrowser.open(f"https://www.google.com/search?q={target}")
            return f"App {target} non trovata, cercata sul web"
        if t == "cmd":
            import subprocess
            subprocess.Popen(target, shell=True)
            return "Eseguito comando"
        if t == "macro":
            results = []
            for step in action.get("steps", []):
                results.append(self.run(step))
            return " ; ".join(results)
        return "Tipo di azione sconosciuto"

    # ---- flusso di creazione conversazionale ---------------------------
    def start_creation(self) -> str:
        self.mode = "await_name"
        self._pending_name = None
        self._pending_action = None
        return "Va bene. Come si chiama la nuova scorciatoia?"

    def cancel_creation(self) -> str:
        self.mode = None
        self._pending_name = None
        self._pending_action = None
        return "Creazione scorciatoia annullata."

    def handle_input(self, text: str) -> tuple[bool, str]:
        """
        Ritorna (handled, response).
        handled=True se siamo nel mezzo della creazione.
        """
        if self.mode is None:
            return False, ""

        text = text.strip()
        low = text.lower()

        # comando di annullamento universale
        if any(kw in low for kw in ["annulla", "lascia stare", "stop creazione"]):
            return True, self.cancel_creation()

        if self.mode == "await_name":
            name = re.sub(r"^(jarvis\s+)?", "", low).strip(" .,'")
            name = re.split(r"\s", name)[0]
            if not name:
                return True, "Non ho capito il nome, ripeti."
            self._pending_name = name
            self.mode = "await_action"
            return True, f"Scorciatoia '{name}'. Adesso descrivimi cosa devo fare quando la chiami."

        if self.mode == "await_action":
            action = parse_action(text)
            self._pending_action = action
            self.mode = "await_confirm"
            human = (
                f"aprire l'URL {action['target']}" if action["type"] == "url"
                else f"aprire l'app {action['target']}" if action["type"] == "app"
                else f"eseguire '{action['target']}'"
            )
            return True, (
                f"Quindi quando dirai 'jarvis {self._pending_name}' dovrò {human}. "
                "Confermi? Dì sì oppure no."
            )

        if self.mode == "await_confirm":
            if re.search(r"\b(sì|si|conferma|ok|va bene|certo|esatto|yes)\b", low):
                self.data[self._pending_name] = self._pending_action
                _save(self.data)
                name = self._pending_name
                self.mode = None
                self._pending_name = None
                self._pending_action = None
                return True, f"Fatto. Scorciatoia '{name}' salvata."
            if re.search(r"\b(no|annulla|niente|sbagliato)\b", low):
                return True, self.cancel_creation()
            return True, "Non ho capito, dì sì per confermare o no per annullare."

        return False, ""


# -----------------------------------------------------------------------------
# CLI di prova
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    sm = ShortcutsManager()
    print(sm.start_creation())
    print(sm.handle_input("twitch"))
    print(sm.handle_input("apri twitch sul browser"))
    print(sm.handle_input("sì"))
    print("Salvato:", sm.data)
    print("Trovata:", sm.find("jarvis twitch"))
