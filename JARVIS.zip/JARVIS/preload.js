const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('jarvis', {
  isElectron: true,

  // Window controls
  minimize: () => ipcRenderer.invoke('app:minimize'),
  maximize: () => ipcRenderer.invoke('app:maximize'),
  close: () => ipcRenderer.invoke('app:close'),
  quit: () => ipcRenderer.invoke('app:quit'),

  // External
  openExternal: (url) => ipcRenderer.invoke('app:open-external', url),
  openPath: (p) => ipcRenderer.invoke('app:open-path', p),
  openApp: (n) => ipcRenderer.invoke('app:open-app', n),
  browserSearch: (browser, query) => ipcRenderer.invoke('app:browser-search', { browser, query }),

  // System
  sysInfo: () => ipcRenderer.invoke('sys:info'),

  // Files
  fileRead: (p) => ipcRenderer.invoke('file:read', p),
  fileWrite: (p, c) => ipcRenderer.invoke('file:write', { filePath: p, content: c }),
  filePick: () => ipcRenderer.invoke('file:pick'),
  fileSaveAs: (content, defaultPath) => ipcRenderer.invoke('file:save-as', { content, defaultPath }),

  // Memory
  memoryRead: () => ipcRenderer.invoke('memory:read'),
  memoryWrite: (data) => ipcRenderer.invoke('memory:write', data),
  remember: (category, item) => ipcRenderer.invoke('memory:remember', { category, item }),
  forget: (category, id) => ipcRenderer.invoke('memory:forget', { category, id }),

  // Shell (limited)
  shellExec: (cmd) => ipcRenderer.invoke('shell:exec', cmd),

  // Events
  onMicStart: (cb) => ipcRenderer.on('mic:start', cb),
});
