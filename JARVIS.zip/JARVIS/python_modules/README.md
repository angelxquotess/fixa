# JARVIS python modules — riservato a estensioni future opzionali
# Le funzionalità core dell'applicazione non richiedono Python.
