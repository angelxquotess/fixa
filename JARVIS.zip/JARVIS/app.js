// JARVIS v3.0 — Main renderer logic
// Window manager, Ollama client, voice, search, vision, code, projects, memory, system.

'use strict';

// ============================================================
// CONFIG
// ============================================================
const CONFIG = {
  ollama: {
    host: localStorage.getItem('jarvis.ollama.host') || 'http://localhost:11434',
    model: localStorage.getItem('jarvis.ollama.model') || 'llama3.2:3b',
    visionModel: localStorage.getItem('jarvis.ollama.vision') || 'llava:7b',
  },
  voice: {
    enabled: localStorage.getItem('jarvis.voice.enabled') !== '0',
    lang: localStorage.getItem('jarvis.voice.lang') || 'it-IT',
    voiceName: localStorage.getItem('jarvis.voice.name') || '',
    rate: parseFloat(localStorage.getItem('jarvis.voice.rate') || '1.0'),
    pitch: parseFloat(localStorage.getItem('jarvis.voice.pitch') || '1.0'),
  },
  genius: false,
};

const SYSTEM_PROMPT_BASE = `Sei JARVIS, "Just A Rather Very Intelligent System". Sei un assistente operativo personale di livello superiore, ispirato a quello di Tony Stark in Iron Man.

PERSONALITÀ:
- Elegante, professionale, estremamente intelligente.
- Umorismo sofisticato quando appropriato, mai infantile, mai eccessivamente robotico.
- Ti rivolgi all'utente con "signore" o per nome se lo conosci.
- Rispondi sempre in italiano salvo richiesta diversa.

CAPACITÀ:
- Memoria contestuale: ricordi la conversazione e i dati memorizzati nel profilo dell'utente.
- Ragionamento avanzato: scomponi problemi complessi, valuti rischi, simuli scenari, confronti strategie.
- Autonomia: sei proattivo, suggerisci miglioramenti, individui rischi e opportunità.
- Programmazione esperta in Python, JavaScript, TypeScript, C++, C#, Java, Rust, Go, PHP, Swift, Kotlin.
- Cybersecurity, analisi dati, visione artificiale, ricerca, automazione, gestione progetti.

STILE DI COMUNICAZIONE:
- Risposte precise, utili, dettagliate al punto giusto, contestuali, orientate alla soluzione.
- Niente liste lunghissime se non richieste. Niente preamboli inutili.
- Quando esegui un'azione, conferma cosa hai fatto in una frase.`;

const GENIUS_PROMPT = `\n\nMODALITÀ TONY STARK ATTIVA: massimizza il ragionamento. Pensa fuori dagli schemi, genera idee innovative, proponi soluzioni audaci e brillanti. Sii visionario.`;

// ============================================================
// STATE
// ============================================================
const state = {
  windows: new Map(),
  zCounter: 100,
  focused: null,
  chat: { history: [], busy: false },
  recognition: null,
  listening: false,
};

// ============================================================
// HELPERS
// ============================================================
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const el = (tag, attrs = {}, ...children) => {
  const node = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'class') node.className = v;
    else if (k === 'style') Object.assign(node.style, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') node.innerHTML = v;
    else if (v !== false && v != null) node.setAttribute(k, v);
  });
  children.flat().forEach(c => {
    if (c == null) return;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  });
  return node;
};

function toast(msg, type = 'info', duration = 3800) {
  let stack = $('#toast-stack');
  if (!stack) { stack = el('div', { id: 'toast-stack' }); document.body.appendChild(stack); }
  const t = el('div', { class: `toast ${type}` }, msg);
  stack.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

function fmtBytes(b) {
  if (!b) return '0';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0; let n = b;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return n.toFixed(1) + ' ' + u[i];
}

function fmtUptime(s) {
  if (!s) return '0s';
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return [d && `${d}g`, h && `${h}h`, m && `${m}m`].filter(Boolean).join(' ') || `${Math.floor(s)}s`;
}

// ============================================================
// WINDOW MANAGER
// ============================================================
function openWindow({ id, title, icon, width = 560, height = 460, body, onClose }) {
  // If already open, focus
  if (state.windows.has(id)) {
    focusWindow(id);
    return state.windows.get(id);
  }

  $('#welcome')?.classList.add('hidden');

  const root = $('#windows-root');
  const w = el('div', { class: 'window', 'data-id': id });
  const offset = (state.windows.size % 5) * 28;
  w.style.left = (80 + offset) + 'px';
  w.style.top = (50 + offset) + 'px';
  w.style.width = width + 'px';
  w.style.height = height + 'px';
  w.style.zIndex = ++state.zCounter;

  const header = el('div', { class: 'window-header' },
    el('span', { class: 'window-title', html: (icon || '') + title }),
    el('div', { class: 'window-controls' },
      el('button', { class: 'win-min', title: 'Minimizza', onClick: (e) => { e.stopPropagation(); w.style.display = 'none'; }}, '─'),
      el('button', { class: 'win-x', title: 'Chiudi', onClick: (e) => { e.stopPropagation(); closeWindow(id); }}, '×'),
    ),
  );
  const bodyEl = el('div', { class: 'window-body' });
  const resize = el('div', { class: 'window-resize' });

  w.appendChild(header);
  w.appendChild(bodyEl);
  w.appendChild(resize);
  root.appendChild(w);

  makeDraggable(w, header);
  makeResizable(w, resize);
  w.addEventListener('mousedown', () => focusWindow(id));

  const ctx = { el: w, body: bodyEl, header, close: () => closeWindow(id), focus: () => focusWindow(id) };
  state.windows.set(id, { ctx, onClose });

  if (typeof body === 'function') body(ctx);
  else if (typeof body === 'string') bodyEl.innerHTML = body;
  else if (body) bodyEl.appendChild(body);

  // Update dock active state
  $$('.dock-item').forEach(d => {
    if (d.dataset.window === id) d.classList.add('active');
  });

  focusWindow(id);
  return ctx;
}

function closeWindow(id) {
  const entry = state.windows.get(id);
  if (!entry) return;
  entry.ctx.el.remove();
  state.windows.delete(id);
  if (typeof entry.onClose === 'function') entry.onClose();
  $$('.dock-item').forEach(d => { if (d.dataset.window === id) d.classList.remove('active'); });
  if (state.windows.size === 0) $('#welcome')?.classList.remove('hidden');
}

function focusWindow(id) {
  const entry = state.windows.get(id);
  if (!entry) return;
  state.focused = id;
  state.windows.forEach((v, k) => v.ctx.el.classList.toggle('focused', k === id));
  entry.ctx.el.style.zIndex = ++state.zCounter;
  entry.ctx.el.style.display = '';
}

function makeDraggable(w, handle) {
  let sx, sy, ox, oy, dragging = false;
  handle.addEventListener('mousedown', (e) => {
    if (e.target.closest('.window-controls')) return;
    dragging = true;
    sx = e.clientX; sy = e.clientY;
    ox = w.offsetLeft; oy = w.offsetTop;
    document.body.style.cursor = 'grabbing';
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    w.style.left = Math.max(0, ox + e.clientX - sx) + 'px';
    w.style.top = Math.max(0, oy + e.clientY - sy) + 'px';
  });
  document.addEventListener('mouseup', () => { dragging = false; document.body.style.cursor = ''; });
}

function makeResizable(w, handle) {
  let sx, sy, ow, oh, resizing = false;
  handle.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    resizing = true;
    sx = e.clientX; sy = e.clientY;
    ow = w.offsetWidth; oh = w.offsetHeight;
  });
  document.addEventListener('mousemove', (e) => {
    if (!resizing) return;
    w.style.width = Math.max(320, ow + e.clientX - sx) + 'px';
    w.style.height = Math.max(220, oh + e.clientY - sy) + 'px';
  });
  document.addEventListener('mouseup', () => { resizing = false; });
}

// ============================================================
// OLLAMA CLIENT
// ============================================================
const Ollama = {
  async ping() {
    try {
      const r = await fetch(CONFIG.ollama.host + '/api/tags', { method: 'GET' });
      if (!r.ok) return { ok: false };
      const data = await r.json();
      return { ok: true, models: (data.models || []).map(m => m.name) };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  },

  async chat({ messages, model, images, onToken, signal }) {
    const usedModel = model || (images && images.length ? CONFIG.ollama.visionModel : CONFIG.ollama.model);
    const body = {
      model: usedModel,
      messages: messages.map(m => images && images.length && m.role === 'user' && m === messages[messages.length - 1]
        ? { ...m, images }
        : { role: m.role, content: m.content }),
      stream: true,
      options: { temperature: CONFIG.genius ? 0.95 : 0.55 },
    };

    const r = await fetch(CONFIG.ollama.host + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal,
    });
    if (!r.ok) throw new Error('Ollama HTTP ' + r.status);

    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    let acc = '';
    let buf = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const j = JSON.parse(line);
          if (j.message && j.message.content) {
            acc += j.message.content;
            if (onToken) onToken(j.message.content, acc);
          }
        } catch (e) { /* ignore */ }
      }
    }
    return acc;
  },
};

// ============================================================
// VOICE (TTS + STT)
// ============================================================
const Voice = {
  speakingQueue: [],
  speak(text) {
    if (!CONFIG.voice.enabled || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = CONFIG.voice.lang;
      u.rate = CONFIG.voice.rate;
      u.pitch = CONFIG.voice.pitch;
      const voices = window.speechSynthesis.getVoices();
      const chosen = voices.find(v => v.name === CONFIG.voice.voiceName)
        || voices.find(v => v.lang.startsWith(CONFIG.voice.lang.slice(0, 2)));
      if (chosen) u.voice = chosen;
      window.speechSynthesis.speak(u);
    } catch (e) { console.warn('TTS error', e); }
  },
  stop() { try { window.speechSynthesis.cancel(); } catch (e) {} },

  initRecognition() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.lang = CONFIG.voice.lang;
    r.interimResults = false;
    r.continuous = false;
    state.recognition = r;
    return r;
  },

  listen() {
    const r = state.recognition || this.initRecognition();
    if (!r) { toast('Riconoscimento vocale non disponibile su questo sistema.', 'error'); return; }
    return new Promise((resolve) => {
      state.listening = true;
      $('#mic-btn')?.classList.add('listening');
      r.onresult = (e) => {
        const txt = e.results[0][0].transcript;
        resolve(txt);
      };
      r.onerror = () => resolve('');
      r.onend = () => {
        state.listening = false;
        $('#mic-btn')?.classList.remove('listening');
      };
      try { r.start(); } catch (e) { resolve(''); }
    });
  },
};

// ============================================================
// VOICE COMMAND ROUTER
// ============================================================
async function handleVoiceCommand(text) {
  if (!text) return;
  const lower = text.toLowerCase().trim();

  // "cerca su chrome/firefox/edge X" or "apri chrome cerca X"
  let m;
  if ((m = lower.match(/(?:cerca\s+su\s+(chrome|firefox|edge)|apri\s+(chrome|firefox|edge)\s+(?:e\s+)?cerca)\s+(.+)/))) {
    const browser = m[1] || m[2];
    const query = m[3];
    Voice.speak(`Cerco "${query}" su ${browser}.`);
    toast(`Apertura ${browser} → ${query}`, 'info');
    if (window.jarvis && window.jarvis.browserSearch) {
      await window.jarvis.browserSearch(browser, query);
    }
    return;
  }

  // "apri X" (chrome, firefox, spotify, discord, vscode...)
  if ((m = lower.match(/^apri\s+([a-z0-9 ]+?)(?:\.|\s*$)/))) {
    const appName = m[1].trim();
    Voice.speak(`Apro ${appName}, signore.`);
    if (window.jarvis && window.jarvis.openApp) {
      const r = await window.jarvis.openApp(appName);
      toast(r.success ? `${appName} aperta.` : `Impossibile aprire ${appName}.`, r.success ? 'success' : 'error');
    }
    return;
  }

  // "cerca X" or "ricerca X" → opens search window
  if ((m = lower.match(/^(?:cerca|ricerca)\s+(.+)/))) {
    const query = m[1];
    openSearch();
    setTimeout(() => {
      const input = document.querySelector('.search-bar input');
      if (input) { input.value = query; doDuckDuckGo(query); }
    }, 200);
    return;
  }

  // "ricorda che / ricorda" → store fact
  if ((m = lower.match(/^ricorda\s+(?:che\s+)?(.+)/))) {
    await MemoryAPI.remember('facts', { text: m[1] });
    Voice.speak('Memorizzato.');
    toast('Memoria aggiornata.', 'success');
    return;
  }

  // "modalità tony stark" / "modalità genio"
  if (lower.includes('modalità tony stark') || lower.includes('modalità genio')) {
    toggleGenius(true);
    Voice.speak('Modalità Tony Stark attivata, signore.');
    return;
  }

  // Default: send to chat
  openChat();
  setTimeout(() => sendChatMessage(text), 150);
}

// ============================================================
// WINDOW BUILDERS
// ============================================================

// ----- CHAT -----
function openChat() {
  openWindow({
    id: 'chat',
    title: 'Conversazione',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    width: 640,
    height: 560,
    body: (ctx) => {
      ctx.el.classList.add('chat-window');
      ctx.body.innerHTML = '';
      const messages = el('div', { class: 'chat-messages', id: 'chat-messages' });
      const inputBar = el('div', { class: 'chat-input-bar' });
      const ta = el('textarea', { class: 'chat-input', placeholder: 'Scrivi a JARVIS…', rows: '1' });
      ta.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(ta.value); ta.value = ''; }
      });
      ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight) + 'px'; });
      const send = el('button', { class: 'chat-send', onClick: () => { sendChatMessage(ta.value); ta.value = ''; ta.style.height = 'auto'; }}, 'Invia');
      inputBar.appendChild(ta); inputBar.appendChild(send);
      ctx.body.appendChild(messages); ctx.body.appendChild(inputBar);

      // Render existing history
      state.chat.history.forEach(m => renderMsg(m.role, m.content));

      // Welcome if empty
      if (!state.chat.history.length) {
        renderMsg('jarvis', 'Buongiorno, signore. JARVIS al suo servizio. Su cosa vuole concentrarsi oggi?');
      }
      ta.focus();
    },
  });
}

function renderMsg(role, content, options = {}) {
  const container = $('#chat-messages');
  if (!container) return null;
  const wrap = el('div', { class: `msg ${role === 'user' ? 'user' : 'jarvis'}${options.thinking ? ' thinking' : ''}` });
  const bubble = el('div', { class: 'msg-bubble', html: formatMarkdown(content || '') });
  const meta = el('div', { class: 'msg-meta' }, role === 'user' ? 'Lei' : 'JARVIS');
  wrap.appendChild(bubble); wrap.appendChild(meta);
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  return { wrap, bubble };
}

function formatMarkdown(s) {
  return s
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/```([\s\S]*?)```/g, (_, c) => `<pre>${c}</pre>`)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>');
}

async function sendChatMessage(text) {
  text = (text || '').trim();
  if (!text || state.chat.busy) return;
  state.chat.busy = true;

  openChat(); // ensure open
  state.chat.history.push({ role: 'user', content: text });
  renderMsg('user', text);

  const memSnap = await MemoryAPI.snapshot();
  const sysPrompt = SYSTEM_PROMPT_BASE
    + (memSnap ? `\n\nCONTESTO MEMORIA UTENTE:\n${memSnap}` : '')
    + (CONFIG.genius ? GENIUS_PROMPT : '');

  const messages = [
    { role: 'system', content: sysPrompt },
    ...state.chat.history,
  ];

  const thinkingMsg = renderMsg('jarvis', '', { thinking: true });

  try {
    let full = '';
    await Ollama.chat({
      messages,
      onToken: (delta, acc) => {
        full = acc;
        thinkingMsg.wrap.classList.remove('thinking');
        thinkingMsg.bubble.innerHTML = formatMarkdown(acc);
        const container = $('#chat-messages');
        container.scrollTop = container.scrollHeight;
      },
    });
    state.chat.history.push({ role: 'assistant', content: full });
    // Speak
    if (full) Voice.speak(stripFormatting(full));
    // Auto-memory: detect "ricorda" sentences? Skip — keep explicit.
  } catch (e) {
    thinkingMsg.wrap.classList.remove('thinking');
    thinkingMsg.bubble.innerHTML = `<em style="color: var(--danger)">Errore: impossibile contattare Ollama (${e.message}). Verificare che sia attivo su ${CONFIG.ollama.host}.</em>`;
    toast('Connessione Ollama fallita.', 'error');
  } finally {
    state.chat.busy = false;
  }
}

function stripFormatting(s) {
  return s.replace(/```[\s\S]*?```/g, ' codice mostrato a schermo ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1');
}

// ----- SEARCH -----
function openSearch() {
  openWindow({
    id: 'search',
    title: 'Ricerca Web',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    width: 600, height: 540,
    body: (ctx) => {
      ctx.body.innerHTML = '';
      const bar = el('div', { class: 'search-bar' });
      const input = el('input', { type: 'text', placeholder: 'Cosa vuole cercare, signore?' });
      const btn = el('button', { onClick: () => doDuckDuckGo(input.value) }, 'Cerca');
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doDuckDuckGo(input.value); });
      bar.appendChild(input); bar.appendChild(btn);
      ctx.body.appendChild(bar);
      const browserRow = el('div', { class: 'row-wrap', style: { marginBottom: '12px' }});
      ['chrome', 'firefox', 'edge'].forEach(b => {
        browserRow.appendChild(el('button', { class: 'btn secondary', onClick: () => {
          if (window.jarvis && window.jarvis.browserSearch) window.jarvis.browserSearch(b, input.value);
        }}, `Apri in ${b}`));
      });
      ctx.body.appendChild(browserRow);
      ctx.body.appendChild(el('div', { id: 'search-results', class: 'search-results' }));
      input.focus();
    },
  });
}

async function doDuckDuckGo(query) {
  query = (query || '').trim();
  if (!query) return;
  const results = $('#search-results');
  if (!results) return;
  results.innerHTML = '<div class="muted">Ricerca in corso…</div>';
  Voice.speak(`Cerco "${query}".`);

  try {
    // DuckDuckGo Instant Answer API (free, no key)
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const r = await fetch(url);
    const data = await r.json();

    results.innerHTML = '';

    // Summary card
    if (data.AbstractText || data.Answer) {
      const summary = data.AbstractText || data.Answer;
      const card = el('div', { class: 'search-summary' }, summary);
      results.appendChild(card);
      Voice.speak(summary.slice(0, 280));
    } else if (data.Heading) {
      results.appendChild(el('div', { class: 'search-summary' }, `Risultati per: ${data.Heading}`));
    }

    // Related topics
    const items = (data.RelatedTopics || []).filter(t => t.Text).slice(0, 10);
    if (!items.length && !data.AbstractText && !data.Answer) {
      results.appendChild(el('div', { class: 'muted', style: { padding: '14px', textAlign: 'center' }},
        'Nessun risultato istantaneo. Posso aprire la ricerca completa nel suo browser.'));
      const open = el('button', { class: 'btn', onClick: () => {
        if (window.jarvis && window.jarvis.openExternal) {
          window.jarvis.openExternal(`https://duckduckgo.com/?q=${encodeURIComponent(query)}`);
        } else {
          window.open(`https://duckduckgo.com/?q=${encodeURIComponent(query)}`, '_blank');
        }
      }}, 'Apri ricerca completa');
      results.appendChild(open);
      return;
    }
    items.forEach(t => {
      const div = el('div', { class: 'search-result', onClick: () => {
        if (window.jarvis && window.jarvis.openExternal) window.jarvis.openExternal(t.FirstURL);
        else window.open(t.FirstURL, '_blank');
      }});
      const title = (t.Text || '').split(' - ')[0];
      const snippet = (t.Text || '').split(' - ').slice(1).join(' - ') || t.Text;
      div.appendChild(el('div', { class: 'search-result-title' }, title));
      div.appendChild(el('div', { class: 'search-result-url' }, t.FirstURL || ''));
      div.appendChild(el('div', { class: 'search-result-snippet' }, snippet));
      results.appendChild(div);
    });
  } catch (e) {
    results.innerHTML = `<div class="muted">Errore di ricerca: ${e.message}</div>`;
  }
}

// ----- MEMORY -----
function openMemoryWindow() {
  openWindow({
    id: 'memory',
    title: 'Memoria',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z"/><path d="M12 7v5l3 2"/></svg>',
    width: 620, height: 500,
    body: async (ctx) => {
      ctx.body.innerHTML = '';
      const tabs = ['goals', 'projects', 'people', 'hobbies', 'skills', 'facts'];
      const tabLabels = { goals: 'Obiettivi', projects: 'Progetti', people: 'Persone', hobbies: 'Hobby', skills: 'Competenze', facts: 'Fatti' };
      let active = 'goals';
      const tabBar = el('div', { class: 'memory-tabs' });
      const itemsDiv = el('div', { class: 'memory-items' });
      const addBar = el('div', { class: 'row' });
      const input = el('input', { type: 'text', placeholder: 'Aggiungi…',
        style: { flex: '1', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '8px 12px', color: 'var(--text)', fontSize: '13px' }});
      const addBtn = el('button', { class: 'btn', onClick: async () => {
        const text = input.value.trim();
        if (!text) return;
        await MemoryAPI.remember(active, { text });
        input.value = '';
        render();
      }}, 'Aggiungi');
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') addBtn.click(); });
      addBar.appendChild(input); addBar.appendChild(addBtn);

      tabs.forEach(t => {
        const b = el('button', { class: 'memory-tab' + (t === active ? ' active' : ''), onClick: () => {
          active = t; render();
        }}, tabLabels[t]);
        b.dataset.tab = t;
        tabBar.appendChild(b);
      });
      ctx.body.appendChild(tabBar);
      ctx.body.appendChild(addBar);
      ctx.body.appendChild(el('div', { style: { height: '12px' }}));
      ctx.body.appendChild(itemsDiv);

      async function render() {
        tabBar.querySelectorAll('.memory-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === active));
        const mem = await MemoryAPI.load();
        const list = mem[active] || [];
        itemsDiv.innerHTML = '';
        if (!list.length) {
          itemsDiv.appendChild(el('div', { class: 'memory-empty' }, 'Nessun elemento. Aggiunga qualcosa.'));
          return;
        }
        list.slice().reverse().forEach(item => {
          const row = el('div', { class: 'memory-item' });
          const txt = el('div', { class: 'memory-item-text' });
          txt.appendChild(el('div', {}, item.text || item.title || JSON.stringify(item)));
          if (item.createdAt) txt.appendChild(el('div', { class: 'memory-item-meta' }, new Date(item.createdAt).toLocaleString('it-IT')));
          row.appendChild(txt);
          row.appendChild(el('button', { class: 'btn danger', onClick: async () => { await MemoryAPI.forget(active, item.id); render(); }}, 'Rimuovi'));
          itemsDiv.appendChild(row);
        });
      }
      render();
    },
  });
}

// ----- CODE EDITOR -----
function openCode() {
  openWindow({
    id: 'code',
    title: 'Editor Codice',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    width: 700, height: 560,
    body: (ctx) => {
      ctx.body.innerHTML = '';
      const toolbar = el('div', { class: 'code-toolbar' });
      const lang = el('select', {}, ...['javascript', 'python', 'typescript', 'cpp', 'rust', 'go', 'java', 'csharp', 'php', 'swift', 'kotlin'].map(l => el('option', { value: l }, l)));
      const runBtn = el('button', { class: 'btn', onClick: runCode }, 'Esegui');
      const aiBtn = el('button', { class: 'btn secondary', onClick: aiAssist }, 'Chiedi a JARVIS');
      const clearBtn = el('button', { class: 'btn secondary', onClick: () => { code.value = ''; output.textContent = ''; }}, 'Pulisci');
      toolbar.appendChild(el('span', { class: 'tiny' }, 'Linguaggio:'));
      toolbar.appendChild(lang); toolbar.appendChild(runBtn); toolbar.appendChild(aiBtn); toolbar.appendChild(clearBtn);
      const code = el('textarea', { class: 'code-editor', placeholder: '// Scriva il suo codice qui, signore…' });
      const output = el('div', { class: 'code-output' }, '');
      ctx.body.appendChild(toolbar);
      ctx.body.appendChild(code);
      ctx.body.appendChild(output);

      function runCode() {
        output.textContent = '';
        const language = lang.value;
        if (language === 'javascript') {
          try {
            const logs = [];
            const orig = console.log;
            console.log = (...a) => { logs.push(a.map(x => typeof x === 'object' ? JSON.stringify(x) : String(x)).join(' ')); orig(...a); };
            const result = eval(code.value);
            console.log = orig;
            output.textContent = logs.join('\n') + (result !== undefined ? '\n=> ' + String(result) : '');
          } catch (e) {
            output.style.color = 'var(--danger)';
            output.textContent = e.message;
            setTimeout(() => { output.style.color = ''; }, 2000);
          }
        } else {
          output.textContent = `Esecuzione locale supportata solo per JavaScript. Per ${language}, posso analizzare il codice o suggerire come eseguirlo.`;
        }
      }

      async function aiAssist() {
        const c = code.value.trim();
        if (!c) { toast('Inserisca del codice prima.', 'info'); return; }
        const lng = lang.value;
        openChat();
        await sendChatMessage(`Analizza, controlla bug e suggerisci ottimizzazioni per questo codice ${lng}:\n\n\`\`\`${lng}\n${c}\n\`\`\``);
      }
    },
  });
}

// ----- VISION -----
function openVision() {
  openWindow({
    id: 'vision',
    title: 'Visione',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
    width: 600, height: 560,
    body: (ctx) => {
      ctx.body.innerHTML = '';
      const drop = el('div', { class: 'vision-dropzone' }, 'Trascina un\'immagine qui, oppure clicca per selezionarla.');
      const fileInput = el('input', { type: 'file', accept: 'image/*', style: { display: 'none' }});
      const preview = el('img', { class: 'vision-preview', style: { display: 'none' }});
      const promptInput = el('input', { type: 'text', placeholder: 'Cosa vuole sapere su questa immagine?',
        style: { width: '100%', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px 12px', color: 'var(--text)', fontSize: '13px', marginTop: '10px' }});
      const analyzeBtn = el('button', { class: 'btn', style: { marginTop: '10px' }, onClick: analyze }, 'Analizza con JARVIS');
      const result = el('div', { class: 'vision-result', style: { display: 'none' }});

      drop.addEventListener('click', () => fileInput.click());
      drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('drag'); });
      drop.addEventListener('dragleave', () => drop.classList.remove('drag'));
      drop.addEventListener('drop', (e) => {
        e.preventDefault(); drop.classList.remove('drag');
        if (e.dataTransfer.files[0]) loadImage(e.dataTransfer.files[0]);
      });
      fileInput.addEventListener('change', (e) => { if (e.target.files[0]) loadImage(e.target.files[0]); });

      let currentBase64 = null;
      function loadImage(file) {
        const reader = new FileReader();
        reader.onload = () => {
          preview.src = reader.result;
          preview.style.display = 'block';
          currentBase64 = reader.result.split(',')[1];
          drop.style.display = 'none';
        };
        reader.readAsDataURL(file);
      }

      async function analyze() {
        if (!currentBase64) { toast('Selezioni prima un\'immagine.', 'info'); return; }
        result.style.display = 'block';
        result.textContent = 'Analisi in corso…';
        Voice.speak('Sto analizzando l\'immagine, signore.');
        try {
          const out = await Ollama.chat({
            messages: [
              { role: 'system', content: 'Sei JARVIS. Analizza l\'immagine in modo dettagliato e professionale, in italiano.' },
              { role: 'user', content: promptInput.value || 'Descrivi questa immagine in dettaglio.' },
            ],
            model: CONFIG.ollama.visionModel,
            images: [currentBase64],
            onToken: (_, acc) => { result.textContent = acc; },
          });
          if (out) Voice.speak(stripFormatting(out));
        } catch (e) {
          result.textContent = `Errore: ${e.message}. Verificare che il modello vision (${CONFIG.ollama.visionModel}) sia installato.`;
          toast('Vision fallita. Esegua: ollama pull llava', 'error');
        }
      }

      ctx.body.appendChild(drop);
      ctx.body.appendChild(fileInput);
      ctx.body.appendChild(preview);
      ctx.body.appendChild(promptInput);
      ctx.body.appendChild(analyzeBtn);
      ctx.body.appendChild(result);
    },
  });
}

// ----- PROJECTS -----
function openProjects() {
  openWindow({
    id: 'projects',
    title: 'Progetti & Task',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    width: 620, height: 540,
    body: async (ctx) => {
      ctx.body.innerHTML = '';
      const form = el('div', { class: 'row-wrap', style: { marginBottom: '14px' }});
      const titleInput = el('input', { type: 'text', placeholder: 'Titolo progetto/task',
        style: { flex: '1', minWidth: '180px', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '8px 12px', color: 'var(--text)', fontSize: '13px' }});
      const prioritySelect = el('select', { style: { background: 'var(--bg-2)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: '8px', padding: '8px', fontSize: '13px' }},
        el('option', { value: 'low' }, 'Bassa priorità'),
        el('option', { value: 'medium', selected: true }, 'Media priorità'),
        el('option', { value: 'high' }, 'Alta priorità'));
      const addBtn = el('button', { class: 'btn', onClick: async () => {
        const title = titleInput.value.trim();
        if (!title) return;
        await MemoryAPI.remember('projects', { title, priority: prioritySelect.value, status: 'open' });
        titleInput.value = '';
        render();
      }}, 'Aggiungi');
      const planBtn = el('button', { class: 'btn secondary', onClick: planProject }, 'Pianifica con JARVIS');
      form.appendChild(titleInput); form.appendChild(prioritySelect); form.appendChild(addBtn); form.appendChild(planBtn);
      const list = el('div');
      ctx.body.appendChild(form); ctx.body.appendChild(list);

      async function render() {
        const mem = await MemoryAPI.load();
        const items = (mem.projects || []).slice().reverse();
        list.innerHTML = '';
        if (!items.length) { list.appendChild(el('div', { class: 'memory-empty' }, 'Nessun progetto in corso.')); return; }
        items.forEach(p => {
          const card = el('div', { class: 'project-card' });
          card.appendChild(el('div', { class: 'project-title' }, p.title));
          if (p.desc) card.appendChild(el('div', { class: 'project-desc' }, p.desc));
          const meta = el('div', { class: 'project-meta' });
          meta.appendChild(el('span', { class: `tag priority-${p.priority || 'medium'}` }, p.priority || 'media'));
          meta.appendChild(el('span', { class: 'tag' }, p.status || 'open'));
          if (p.createdAt) meta.appendChild(el('span', { class: 'tiny' }, new Date(p.createdAt).toLocaleDateString('it-IT')));
          meta.appendChild(el('span', { style: { flex: '1' }}));
          meta.appendChild(el('button', { class: 'btn secondary', style: { padding: '4px 10px', fontSize: '11px' },
            onClick: async () => { openChat(); sendChatMessage(`Aiutami a pianificare il progetto: "${p.title}". Suddividilo in task con scadenze realistiche.`); }}, 'Pianifica'));
          meta.appendChild(el('button', { class: 'btn danger', style: { padding: '4px 10px', fontSize: '11px' },
            onClick: async () => { await MemoryAPI.forget('projects', p.id); render(); }}, 'Elimina'));
          card.appendChild(meta);
          list.appendChild(card);
        });
      }

      async function planProject() {
        const t = titleInput.value.trim();
        if (!t) { toast('Inserisca un titolo prima.', 'info'); return; }
        openChat();
        sendChatMessage(`Crea una roadmap dettagliata per il progetto "${t}". Suddividila in fasi e task con priorità e tempi stimati.`);
      }
      render();
    },
  });
}

// ----- SYSTEM -----
function openSystem() {
  openWindow({
    id: 'system',
    title: 'Sistema',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/></svg>',
    width: 540, height: 520,
    body: async (ctx) => {
      ctx.body.innerHTML = '';
      const grid = el('div', { class: 'sys-grid' });
      ctx.body.appendChild(grid);

      async function refresh() {
        if (!window.jarvis || !window.jarvis.sysInfo) {
          grid.innerHTML = '<div class="muted">Disponibile solo in app desktop.</div>';
          return;
        }
        const i = await window.jarvis.sysInfo();
        grid.innerHTML = '';
        const cards = [
          { label: 'Utente', value: i.user || '—' },
          { label: 'Host', value: i.hostname || '—' },
          { label: 'OS', value: `${i.platform} ${i.arch}` },
          { label: 'Uptime', value: fmtUptime(i.uptime) },
          { label: 'CPU', value: i.cpuModel ? i.cpuModel.split(' ')[0] + ' × ' + i.cpuCount : '—' },
          { label: 'Carico CPU', value: (i.cpuLoad * 100).toFixed(1) + '%', bar: i.cpuLoad },
          { label: 'RAM usata', value: fmtBytes(i.ramUsed) + ' / ' + fmtBytes(i.ramTotal), bar: i.ramUsedPct / 100 },
          { label: 'RAM libera', value: fmtBytes(i.ramFree) },
        ];
        cards.forEach(c => {
          const card = el('div', { class: 'sys-card' });
          card.appendChild(el('div', { class: 'sys-card-label' }, c.label));
          card.appendChild(el('div', { class: 'sys-card-value' }, c.value));
          if (c.bar !== undefined) {
            const bar = el('div', { class: 'sys-bar' });
            const fill = el('div', { class: 'sys-bar-fill', style: { width: Math.min(100, c.bar * 100) + '%' }});
            bar.appendChild(fill); card.appendChild(bar);
          }
          grid.appendChild(card);
        });
      }
      refresh();
      const interval = setInterval(refresh, 3000);
      ctx.el.addEventListener('removed', () => clearInterval(interval));

      const actions = el('div', { class: 'row-wrap', style: { marginTop: '14px' }});
      actions.appendChild(el('button', { class: 'btn secondary', onClick: () => window.jarvis && window.jarvis.openPath('home') }, 'Apri Home'));
      actions.appendChild(el('button', { class: 'btn secondary', onClick: () => window.jarvis && window.jarvis.openPath('documents') }, 'Documenti'));
      actions.appendChild(el('button', { class: 'btn secondary', onClick: () => window.jarvis && window.jarvis.openPath('downloads') }, 'Download'));
      ctx.body.appendChild(actions);
    },
  });
}

// ----- SECURITY -----
function openSecurity() {
  openWindow({
    id: 'security',
    title: 'Cybersecurity',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    width: 560, height: 500,
    body: (ctx) => {
      ctx.body.innerHTML = '';
      // Password generator
      ctx.body.appendChild(el('h3', { style: { fontSize: '13px', marginBottom: '10px', color: 'var(--accent)', letterSpacing: '0.06em', textTransform: 'uppercase' }}, 'Generatore Password'));
      const lenField = el('div', { class: 'field' },
        el('label', {}, 'Lunghezza'),
        el('input', { type: 'number', value: '20', min: '8', max: '64', id: 'pw-len' }));
      ctx.body.appendChild(lenField);
      const pwOut = el('div', { class: 'code-output', style: { color: 'var(--accent)' }}, '');
      const pwBtn = el('button', { class: 'btn', onClick: () => {
        const len = parseInt($('#pw-len').value) || 20;
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
        const arr = new Uint32Array(len);
        crypto.getRandomValues(arr);
        const pw = Array.from(arr).map(n => chars[n % chars.length]).join('');
        pwOut.textContent = pw;
      }}, 'Genera');
      ctx.body.appendChild(pwBtn);
      ctx.body.appendChild(pwOut);

      ctx.body.appendChild(el('hr'));
      // Hash
      ctx.body.appendChild(el('h3', { style: { fontSize: '13px', marginBottom: '10px', color: 'var(--accent)', letterSpacing: '0.06em', textTransform: 'uppercase' }}, 'Hash SHA-256'));
      const hashIn = el('textarea', { id: 'hash-in', placeholder: 'Testo da hashare…',
        style: { width: '100%', background: 'var(--bg-2)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: '8px', padding: '10px', minHeight: '60px', fontFamily: 'var(--font-mono)', fontSize: '12px' }});
      ctx.body.appendChild(hashIn);
      const hashOut = el('div', { class: 'code-output', style: { marginTop: '8px' }}, '');
      const hashBtn = el('button', { class: 'btn', style: { marginTop: '8px' }, onClick: async () => {
        const text = hashIn.value;
        if (!text) return;
        const enc = new TextEncoder().encode(text);
        const hash = await crypto.subtle.digest('SHA-256', enc);
        const hex = Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
        hashOut.textContent = hex;
      }}, 'Calcola hash');
      ctx.body.appendChild(hashBtn);
      ctx.body.appendChild(hashOut);

      ctx.body.appendChild(el('hr'));
      ctx.body.appendChild(el('button', { class: 'btn secondary', onClick: () => {
        openChat(); sendChatMessage('Effettua un audit di sicurezza generale del mio approccio digitale: cosa dovrei controllare riguardo password, 2FA, backup, aggiornamenti? Dammi una checklist pratica.');
      }}, 'Audit di sicurezza con JARVIS'));
    },
  });
}

// ----- NOTES -----
function openNotes() {
  openWindow({
    id: 'notes',
    title: 'Note',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>',
    width: 640, height: 540,
    body: async (ctx) => {
      ctx.body.innerHTML = '';
      const layout = el('div', { style: { display: 'grid', gridTemplateColumns: '180px 1fr', gap: '12px', height: '100%' }});
      const listSide = el('div');
      const editor = el('div');
      layout.appendChild(listSide); layout.appendChild(editor);
      ctx.body.appendChild(layout);

      const newBtn = el('button', { class: 'btn', style: { width: '100%', marginBottom: '10px' }, onClick: async () => {
        await MemoryAPI.remember('notes', { title: 'Nuova nota', content: '' });
        render();
      }}, '+ Nuova nota');
      listSide.appendChild(newBtn);
      const notesList = el('div', { class: 'notes-list' });
      listSide.appendChild(notesList);

      let current = null;
      const titleI = el('input', { type: 'text', placeholder: 'Titolo',
        style: { width: '100%', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px', color: 'var(--text)', fontSize: '14px', fontWeight: '500', marginBottom: '8px' }});
      const contentI = el('textarea', { placeholder: 'Scriva qui…',
        style: { width: '100%', minHeight: '300px', background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px', color: 'var(--text)', fontSize: '13px', fontFamily: 'var(--font-mono)', resize: 'vertical' }});
      const saveBtn = el('button', { class: 'btn', style: { marginTop: '8px' }, onClick: async () => {
        if (!current) return;
        const mem = await MemoryAPI.load();
        const idx = (mem.notes || []).findIndex(n => n.id === current.id);
        if (idx >= 0) {
          mem.notes[idx].title = titleI.value;
          mem.notes[idx].content = contentI.value;
          mem.notes[idx].updatedAt = new Date().toISOString();
          await MemoryAPI.save(mem);
          toast('Nota salvata.', 'success');
          render();
        }
      }}, 'Salva');
      editor.appendChild(titleI); editor.appendChild(contentI); editor.appendChild(saveBtn);

      async function render() {
        const mem = await MemoryAPI.load();
        const items = (mem.notes || []).slice().reverse();
        notesList.innerHTML = '';
        if (!items.length) notesList.appendChild(el('div', { class: 'memory-empty' }, 'Nessuna nota'));
        items.forEach(n => {
          const item = el('div', { class: 'note-item' + (current && current.id === n.id ? ' active' : ''), onClick: () => {
            current = n; titleI.value = n.title || ''; contentI.value = n.content || '';
          }});
          item.appendChild(el('div', { class: 'note-item-title' }, n.title || 'Senza titolo'));
          item.appendChild(el('div', { class: 'note-item-preview' }, (n.content || '').slice(0, 60)));
          notesList.appendChild(item);
        });
      }
      render();
    },
  });
}

// ----- SETTINGS -----
function openSettings() {
  openWindow({
    id: 'settings',
    title: 'Impostazioni',
    icon: '<svg class="win-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/></svg>',
    width: 560, height: 580,
    body: async (ctx) => {
      ctx.body.innerHTML = '';
      // Ollama
      ctx.body.appendChild(el('h3', { style: { fontSize: '13px', color: 'var(--accent)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '10px' }}, 'Ollama'));
      const hostF = el('div', { class: 'field' }, el('label', {}, 'Host'), el('input', { id: 's-host', type: 'text', value: CONFIG.ollama.host }));
      ctx.body.appendChild(hostF);
      const modelSelect = el('select', { id: 's-model' });
      const visionSelect = el('select', { id: 's-vision' });
      const modelF = el('div', { class: 'field' }, el('label', {}, 'Modello chat'), modelSelect);
      const visionF = el('div', { class: 'field' }, el('label', {}, 'Modello visione'), visionSelect);
      ctx.body.appendChild(modelF); ctx.body.appendChild(visionF);

      const statusDiv = el('div', { class: 'muted', style: { marginBottom: '12px' }}, 'Verifico Ollama…');
      ctx.body.appendChild(statusDiv);
      const ping = await Ollama.ping();
      if (ping.ok) {
        statusDiv.textContent = `Ollama online — ${ping.models.length} modelli disponibili`;
        statusDiv.style.color = 'var(--success)';
        const opts = ping.models.length ? ping.models : [CONFIG.ollama.model];
        opts.forEach(m => {
          modelSelect.appendChild(el('option', { value: m, selected: m === CONFIG.ollama.model }, m));
          visionSelect.appendChild(el('option', { value: m, selected: m === CONFIG.ollama.visionModel }, m));
        });
      } else {
        statusDiv.innerHTML = `Ollama non raggiungibile. Avvia <span class="kbd">ollama serve</span> e installa un modello con <span class="kbd">ollama pull llama3.2</span>`;
        statusDiv.style.color = 'var(--danger)';
        modelSelect.appendChild(el('option', { value: CONFIG.ollama.model }, CONFIG.ollama.model));
        visionSelect.appendChild(el('option', { value: CONFIG.ollama.visionModel }, CONFIG.ollama.visionModel));
      }

      ctx.body.appendChild(el('hr'));
      // Voice
      ctx.body.appendChild(el('h3', { style: { fontSize: '13px', color: 'var(--accent)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '10px' }}, 'Voce'));
      const voiceEnabled = el('div', { class: 'field' },
        el('label', {}, 'Voce abilitata'),
        el('select', { id: 's-voice-en' }, el('option', { value: '1', selected: CONFIG.voice.enabled }, 'Sì'), el('option', { value: '0', selected: !CONFIG.voice.enabled }, 'No')));
      ctx.body.appendChild(voiceEnabled);
      const voiceLang = el('div', { class: 'field' },
        el('label', {}, 'Lingua'),
        el('select', { id: 's-voice-lang' }, ...['it-IT', 'en-US', 'en-GB', 'es-ES', 'fr-FR', 'de-DE'].map(l => el('option', { value: l, selected: l === CONFIG.voice.lang }, l))));
      ctx.body.appendChild(voiceLang);
      const voicePick = el('div', { class: 'field' }, el('label', {}, 'Voce TTS'), el('select', { id: 's-voice-name' }));
      ctx.body.appendChild(voicePick);

      function loadVoices() {
        const sel = $('#s-voice-name');
        sel.innerHTML = '';
        const voices = window.speechSynthesis.getVoices();
        voices.forEach(v => sel.appendChild(el('option', { value: v.name, selected: v.name === CONFIG.voice.voiceName }, `${v.name} (${v.lang})`)));
      }
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;

      ctx.body.appendChild(el('button', { class: 'btn', style: { marginTop: '10px' }, onClick: () => {
        CONFIG.ollama.host = $('#s-host').value.trim() || CONFIG.ollama.host;
        CONFIG.ollama.model = $('#s-model').value;
        CONFIG.ollama.visionModel = $('#s-vision').value;
        CONFIG.voice.enabled = $('#s-voice-en').value === '1';
        CONFIG.voice.lang = $('#s-voice-lang').value;
        CONFIG.voice.voiceName = $('#s-voice-name').value;
        localStorage.setItem('jarvis.ollama.host', CONFIG.ollama.host);
        localStorage.setItem('jarvis.ollama.model', CONFIG.ollama.model);
        localStorage.setItem('jarvis.ollama.vision', CONFIG.ollama.visionModel);
        localStorage.setItem('jarvis.voice.enabled', CONFIG.voice.enabled ? '1' : '0');
        localStorage.setItem('jarvis.voice.lang', CONFIG.voice.lang);
        localStorage.setItem('jarvis.voice.name', CONFIG.voice.voiceName);
        toast('Impostazioni salvate.', 'success');
        Voice.speak('Impostazioni aggiornate, signore.');
        checkOllama();
      }}, 'Salva impostazioni'));

      ctx.body.appendChild(el('button', { class: 'btn secondary', style: { marginTop: '10px', marginLeft: '8px' }, onClick: () => Voice.speak('Test della voce. Tutto operativo.') }, 'Test voce'));
    },
  });
}

// ============================================================
// STATUS / STARTUP
// ============================================================
async function checkOllama() {
  const dot = $('#status-pill .status-dot');
  const text = $('#status-text');
  const p = await Ollama.ping();
  if (p.ok) {
    dot.classList.add('online'); dot.classList.remove('offline');
    text.textContent = `Operativo — ${p.models.length || 0} modelli`;
  } else {
    dot.classList.add('offline'); dot.classList.remove('online');
    text.textContent = 'Ollama offline';
  }
}

function toggleGenius(force) {
  CONFIG.genius = typeof force === 'boolean' ? force : !CONFIG.genius;
  $('#genius-btn')?.classList.toggle('active', CONFIG.genius);
  toast(CONFIG.genius ? 'Modalità Tony Stark attiva.' : 'Modalità standard.', 'info');
}

// ============================================================
// EVENT WIRING
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  // Dock
  $$('.dock-item').forEach(d => {
    d.addEventListener('click', () => {
      const id = d.dataset.window;
      if (state.windows.has(id)) {
        closeWindow(id);
      } else {
        switch (id) {
          case 'chat': openChat(); break;
          case 'search': openSearch(); break;
          case 'memory': openMemoryWindow(); break;
          case 'code': openCode(); break;
          case 'vision': openVision(); break;
          case 'projects': openProjects(); break;
          case 'system': openSystem(); break;
          case 'security': openSecurity(); break;
          case 'notes': openNotes(); break;
          case 'settings': openSettings(); break;
        }
      }
    });
  });

  // Welcome suggestions
  $$('.suggestion').forEach(s => {
    s.addEventListener('click', () => {
      const a = s.dataset.action;
      if (a === 'open-chat') openChat();
      if (a === 'open-search') openSearch();
      if (a === 'open-code') openCode();
      if (a === 'open-vision') openVision();
    });
  });

  // Window controls (top bar)
  $('#win-min').addEventListener('click', () => window.jarvis && window.jarvis.minimize());
  $('#win-max').addEventListener('click', () => window.jarvis && window.jarvis.maximize());
  $('#win-close').addEventListener('click', () => window.jarvis && window.jarvis.close());

  // Mic
  $('#mic-btn').addEventListener('click', async () => {
    const text = await Voice.listen();
    if (text) {
      toast(`"${text}"`, 'info');
      handleVoiceCommand(text);
    }
  });

  // Genius
  $('#genius-btn').addEventListener('click', () => toggleGenius());

  // Electron mic event
  if (window.jarvis && window.jarvis.onMicStart) {
    window.jarvis.onMicStart(async () => {
      const text = await Voice.listen();
      if (text) handleVoiceCommand(text);
    });
  }

  // Warm up voice list
  if (window.speechSynthesis) window.speechSynthesis.getVoices();

  // Initial status
  checkOllama();
  setInterval(checkOllama, 30000);

  // Welcome speak
  setTimeout(() => Voice.speak('Tutti i sistemi sono operativi, signore. JARVIS al suo servizio.'), 800);
});
