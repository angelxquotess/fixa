# JARVIS — Just A Rather Very Intelligent System

> Assistente operativo personale di livello superiore, ispirato a quello di Tony Stark.

JARVIS è una **applicazione desktop Electron** che ti offre un partner digitale avanzato per studio, lavoro, ricerca, programmazione, organizzazione, produttività e analisi. Non è un semplice chatbot: ogni capacità apre la propria finestra mobile all'interno del banco da lavoro, parla con voce sintetizzata e ricorda il contesto a lungo termine.

---

## CARATTERISTICHE

- **Cervello AI locale** via **Ollama** (nessuna chiave API necessaria, tutto in locale)
- **Memoria persistente** (obiettivi, progetti, persone, hobby, competenze, fatti, note)
- **Voce**: Text-To-Speech in italiano + riconoscimento vocale (STT)
- **Ricerca Web** con DuckDuckGo e apertura diretta in Chrome / Firefox / Edge
- **Visione artificiale** (analisi immagini con LLaVA)
- **Editor di codice** con esecuzione JavaScript locale e analisi AI multi-linguaggio
- **Gestione Progetti & Task** con priorità e roadmap generate da JARVIS
- **Cybersecurity**: generatore password sicure, hash SHA-256, audit assistito
- **Sistema**: monitor CPU/RAM in tempo reale, accesso rapido cartelle
- **Note** persistenti
- **Modalità Tony Stark**: massimizza il ragionamento e la creatività
- **Comandi vocali naturali**: "apri chrome cerca …", "ricorda che …", "modalità Tony Stark"
- **Finestre mobili**: ogni funzione ha una finestra trascinabile e ridimensionabile

---

## INSTALLAZIONE

### Prerequisiti
1. **Node.js v16+** — [nodejs.org](https://nodejs.org)
2. **Ollama** — [ollama.ai](https://ollama.ai)

### Setup

```bash
# 1. Estrai lo zip e apri il terminale nella cartella
cd jarvis

# 2. Installa le dipendenze
npm install

# 3. Installa il modello AI (una sola volta)
ollama pull llama3.2:3b
ollama pull llava:7b   # opzionale, per la visione

# 4. Avvia Ollama (se non è già attivo)
ollama serve

# 5. Avvia JARVIS in modalità sviluppo
npm start

# 6. Compila l'app eseguibile
npm run dist          # auto (Win/Mac/Linux)
npm run dist:win      # Windows
npm run dist:mac      # macOS
npm run dist:linux    # Linux
```

Gli installer/binari saranno in `dist/`.

---

## COMANDI VOCALI

Premi **Insert** (o il bottone microfono) e parla:

| Frase | Azione |
|-------|--------|
| `Ciao JARVIS, come stai?` | Avvia la conversazione |
| `Cerca <argomento>` | Apre la finestra di ricerca |
| `Cerca su chrome <argomento>` | Apre Chrome con la ricerca |
| `Cerca su firefox <argomento>` | Apre Firefox con la ricerca |
| `Apri spotify` / `Apri vscode` | Lancia l'app sul sistema |
| `Ricorda che <fatto>` | Salva in memoria a lungo termine |
| `Modalità Tony Stark` | Attiva la modalità genio |

---

## SHORTCUT TASTIERA

- `Ctrl + Alt + J` — Mostra/nasconde JARVIS
- `Insert` — Attiva il microfono

---

## ARCHITETTURA

```
jarvis/
├── main.js          # Electron main process (IPC, system, memory file)
├── preload.js       # IPC bridge (contextIsolation)
├── index.html       # UI shell (topbar, workspace, dock)
├── styles.css       # Design system
├── app.js           # Renderer: window manager, Ollama, voice, search…
├── memory.js        # Memory subsystem (long-term store via Electron IPC)
└── package.json     # electron-builder config
```

La memoria a lungo termine è salvata in:
- **Windows**: `%APPDATA%\jarvis\jarvis_memory.json`
- **macOS**: `~/Library/Application Support/jarvis/jarvis_memory.json`
- **Linux**: `~/.config/jarvis/jarvis_memory.json`

---

## TROUBLESHOOTING

**Ollama offline** → assicurati che il demone sia attivo:
```bash
ollama serve
curl http://localhost:11434/api/tags
```

**Microfono non funziona** → controlla i permessi del sistema operativo.

**Visione non funziona** → installa il modello multimodale:
```bash
ollama pull llava:7b
```

---

## PRIVACY

Tutto è in locale: la conversazione, la memoria e la voce non lasciano mai il tuo computer. L'unica eccezione è la **ricerca DuckDuckGo** (chiamata API pubblica gratuita) e l'apertura del browser quando richiesto esplicitamente.

---

## LICENZA

MIT

---

**"Tutti i sistemi sono operativi, signore."**
