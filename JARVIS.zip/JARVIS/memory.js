// JARVIS - Memory subsystem (renderer-side helpers)
// Wraps the IPC bridge with convenience methods.

const MemoryAPI = {
  async load() {
    if (window.jarvis && window.jarvis.memoryRead) {
      return await window.jarvis.memoryRead();
    }
    // Fallback to localStorage when running outside Electron
    try {
      return JSON.parse(localStorage.getItem('jarvis_memory')) || {
        profile: {}, preferences: {}, goals: [], projects: [], people: [],
        hobbies: [], skills: [], events: [], facts: [], conversations: [],
      };
    } catch (e) {
      return {};
    }
  },
  async save(mem) {
    if (window.jarvis && window.jarvis.memoryWrite) {
      return await window.jarvis.memoryWrite(mem);
    }
    localStorage.setItem('jarvis_memory', JSON.stringify(mem));
    return true;
  },
  async remember(category, item) {
    if (window.jarvis && window.jarvis.remember) {
      return await window.jarvis.remember(category, item);
    }
    const mem = await this.load();
    if (!Array.isArray(mem[category])) mem[category] = [];
    mem[category].push({ ...item, id: Date.now().toString(36), createdAt: new Date().toISOString() });
    await this.save(mem);
    return mem;
  },
  async forget(category, id) {
    if (window.jarvis && window.jarvis.forget) {
      return await window.jarvis.forget(category, id);
    }
    const mem = await this.load();
    if (Array.isArray(mem[category])) {
      mem[category] = mem[category].filter(x => x.id !== id);
      await this.save(mem);
    }
    return mem;
  },
  // Build a compact memory snapshot for the LLM context
  async snapshot() {
    const m = await this.load();
    const lines = [];
    if (m.profile && Object.keys(m.profile).length) lines.push(`Profilo utente: ${JSON.stringify(m.profile)}`);
    if (m.preferences && Object.keys(m.preferences).length) lines.push(`Preferenze: ${JSON.stringify(m.preferences)}`);
    if (m.goals && m.goals.length) lines.push(`Obiettivi: ${m.goals.map(g => g.text).join('; ')}`);
    if (m.projects && m.projects.length) lines.push(`Progetti: ${m.projects.map(p => p.title).join('; ')}`);
    if (m.people && m.people.length) lines.push(`Persone importanti: ${m.people.map(p => `${p.name}${p.relation ? ' ('+p.relation+')' : ''}`).join('; ')}`);
    if (m.hobbies && m.hobbies.length) lines.push(`Hobby: ${m.hobbies.map(h => h.text).join('; ')}`);
    if (m.skills && m.skills.length) lines.push(`Competenze: ${m.skills.map(s => s.text).join('; ')}`);
    if (m.facts && m.facts.length) lines.push(`Fatti rilevanti: ${m.facts.slice(-10).map(f => f.text).join('; ')}`);
    return lines.join('\n');
  },
};

window.MemoryAPI = MemoryAPI;
