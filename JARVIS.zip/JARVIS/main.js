// JARVIS - Electron main process v3.0
// Just A Rather Very Intelligent System
const { app, BrowserWindow, globalShortcut, Tray, Menu, shell, ipcMain, nativeImage, dialog } = require('electron');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { exec, spawn } = require('child_process');

let mainWin = null;
let tray = null;

// Memory file path - persistent long-term memory
const MEMORY_FILE = path.join(app.getPath('userData'), 'jarvis_memory.json');

function ensureMemoryFile() {
  if (!fs.existsSync(MEMORY_FILE)) {
    const initial = {
      profile: {},
      preferences: {},
      goals: [],
      projects: [],
      people: [],
      hobbies: [],
      skills: [],
      events: [],
      facts: [],
      conversations: [],
      lastUpdate: new Date().toISOString(),
    };
    fs.writeFileSync(MEMORY_FILE, JSON.stringify(initial, null, 2));
  }
}

function readMemory() {
  try {
    ensureMemoryFile();
    return JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
  } catch (e) {
    return {};
  }
}

function writeMemory(data) {
  data.lastUpdate = new Date().toISOString();
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2));
  return true;
}

// Ensure single instance
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); return; }
app.on('second-instance', () => { if (mainWin) { mainWin.show(); mainWin.focus(); }});

function createWindow() {
  mainWin = new BrowserWindow({
    width: 1500,
    height: 950,
    minWidth: 1100,
    minHeight: 700,
    frame: false,
    backgroundColor: '#0a0e14',
    title: 'JARVIS',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false,
    },
  });

  mainWin.loadFile('index.html');

  mainWin.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault();
      mainWin.hide();
    }
  });
}

function buildTray() {
  try {
    const iconPath = path.join(__dirname, 'assets', 'icon.png');
    tray = fs.existsSync(iconPath) ? new Tray(iconPath) : new Tray(nativeImage.createEmpty());
  } catch (e) {
    tray = new Tray(nativeImage.createEmpty());
  }

  const menu = Menu.buildFromTemplate([
    { label: 'Mostra JARVIS', click: () => { if (mainWin) { mainWin.show(); mainWin.focus(); }}},
    { label: 'Nascondi', click: () => { if (mainWin) mainWin.hide(); }},
    { type: 'separator' },
    {
      label: 'Avvio automatico',
      type: 'checkbox',
      checked: app.getLoginItemSettings().openAtLogin,
      click: (mi) => app.setLoginItemSettings({ openAtLogin: mi.checked, openAsHidden: true })
    },
    { type: 'separator' },
    { label: 'Esci', click: () => { app.isQuiting = true; app.quit(); }},
  ]);

  tray.setToolTip('JARVIS');
  tray.setContextMenu(menu);
  tray.on('click', () => {
    if (!mainWin) return;
    mainWin.isVisible() ? mainWin.hide() : mainWin.show();
  });
}

// ====== IPC: Window controls ======
ipcMain.handle('app:minimize', () => mainWin && mainWin.minimize());
ipcMain.handle('app:maximize', () => {
  if (!mainWin) return;
  mainWin.isMaximized() ? mainWin.unmaximize() : mainWin.maximize();
});
ipcMain.handle('app:close', () => mainWin && mainWin.hide());
ipcMain.handle('app:quit', () => { app.isQuiting = true; app.quit(); });

// ====== IPC: External / system ======
ipcMain.handle('app:open-external', (_, url) => shell.openExternal(url));

ipcMain.handle('app:open-path', (_, p) => {
  const map = {
    desktop: app.getPath('desktop'),
    documents: app.getPath('documents'),
    downloads: app.getPath('downloads'),
    pictures: app.getPath('pictures'),
    music: app.getPath('music'),
    videos: app.getPath('videos'),
    home: app.getPath('home'),
  };
  return shell.openPath(map[p] || p);
});

// Open browser with search query
ipcMain.handle('app:browser-search', async (_, { browser, query }) => {
  const q = encodeURIComponent(query);
  const url = `https://www.google.com/search?q=${q}`;
  const platform = process.platform;
  return new Promise((resolve) => {
    let cmd;
    if (browser === 'firefox') {
      cmd = platform === 'win32' ? `start firefox "${url}"`
        : platform === 'darwin' ? `open -a Firefox "${url}"`
        : `firefox "${url}"`;
    } else if (browser === 'edge') {
      cmd = platform === 'win32' ? `start msedge "${url}"`
        : platform === 'darwin' ? `open -a "Microsoft Edge" "${url}"`
        : `microsoft-edge "${url}"`;
    } else {
      // chrome (default)
      cmd = platform === 'win32' ? `start chrome "${url}"`
        : platform === 'darwin' ? `open -a "Google Chrome" "${url}"`
        : `google-chrome "${url}"`;
    }
    exec(cmd, (err) => {
      if (err) {
        // Fallback to default browser
        shell.openExternal(url);
        resolve({ success: true, fallback: true });
      } else {
        resolve({ success: true });
      }
    });
  });
});

// Open any app
ipcMain.handle('app:open-app', (_, appName) => {
  const platform = process.platform;
  const lower = appName.toLowerCase();
  const winMap = {
    spotify: 'spotify.exe', discord: 'Discord.exe', vscode: 'Code.exe',
    chrome: 'chrome.exe', firefox: 'firefox.exe', edge: 'msedge.exe',
    notepad: 'notepad.exe', calculator: 'calc.exe',
  };
  const macMap = {
    spotify: 'Spotify', discord: 'Discord', vscode: 'Visual Studio Code',
    chrome: 'Google Chrome', firefox: 'Firefox', safari: 'Safari',
  };
  let cmd;
  if (platform === 'win32') {
    cmd = `start ${winMap[lower] || appName + '.exe'}`;
  } else if (platform === 'darwin') {
    cmd = `open -a "${macMap[lower] || appName}"`;
  } else {
    cmd = lower;
  }
  return new Promise((resolve) => {
    exec(cmd, (err) => {
      if (err) {
        const webUrls = {
          spotify: 'https://open.spotify.com',
          discord: 'https://discord.com/app',
          vscode: 'https://vscode.dev',
        };
        if (webUrls[lower]) {
          shell.openExternal(webUrls[lower]);
          resolve({ success: true, method: 'web' });
        } else {
          resolve({ success: false, error: err.message });
        }
      } else {
        resolve({ success: true, method: 'native' });
      }
    });
  });
});

// ====== IPC: System info ======
ipcMain.handle('sys:info', () => {
  const total = os.totalmem();
  const free = os.freemem();
  const cpus = os.cpus();
  let user = 0, total_t = 0;
  cpus.forEach(c => {
    Object.values(c.times).forEach(t => total_t += t);
    user += c.times.user + c.times.sys;
  });
  return {
    platform: os.platform(),
    hostname: os.hostname(),
    arch: os.arch(),
    uptime: os.uptime(),
    cpuModel: cpus[0] && cpus[0].model,
    cpuCount: cpus.length,
    cpuLoad: user / Math.max(1, total_t),
    ramTotal: total,
    ramFree: free,
    ramUsed: total - free,
    ramUsedPct: ((total - free) / total) * 100,
    user: os.userInfo().username,
  };
});

// ====== IPC: File system ======
ipcMain.handle('file:read', async (_, filePath) => {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return { success: true, content };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('file:write', async (_, { filePath, content }) => {
  try {
    fs.writeFileSync(filePath, content);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('file:pick', async () => {
  const result = await dialog.showOpenDialog(mainWin, {
    properties: ['openFile'],
  });
  if (result.canceled) return { canceled: true };
  return { canceled: false, path: result.filePaths[0] };
});

ipcMain.handle('file:save-as', async (_, { content, defaultPath }) => {
  const result = await dialog.showSaveDialog(mainWin, { defaultPath });
  if (result.canceled) return { canceled: true };
  fs.writeFileSync(result.filePath, content);
  return { canceled: false, path: result.filePath };
});

// ====== IPC: Memory ======
ipcMain.handle('memory:read', () => readMemory());
ipcMain.handle('memory:write', (_, data) => writeMemory(data));
ipcMain.handle('memory:remember', (_, { category, item }) => {
  const mem = readMemory();
  if (!Array.isArray(mem[category])) mem[category] = [];
  mem[category].push({ ...item, id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), createdAt: new Date().toISOString() });
  writeMemory(mem);
  return mem;
});
ipcMain.handle('memory:forget', (_, { category, id }) => {
  const mem = readMemory();
  if (Array.isArray(mem[category])) {
    mem[category] = mem[category].filter(x => x.id !== id);
    writeMemory(mem);
  }
  return mem;
});

// ====== IPC: Shell command exec (limited & explicit) ======
ipcMain.handle('shell:exec', (_, command) => {
  return new Promise((resolve) => {
    exec(command, { timeout: 15000 }, (err, stdout, stderr) => {
      resolve({ success: !err, stdout, stderr: stderr || (err && err.message) });
    });
  });
});

// ====== APP READY ======
app.whenReady().then(() => {
  ensureMemoryFile();
  createWindow();
  buildTray();

  globalShortcut.register('Control+Alt+J', () => {
    if (!mainWin) return;
    mainWin.isVisible() ? mainWin.hide() : (mainWin.show(), mainWin.focus());
  });
  globalShortcut.register('Insert', () => {
    if (!mainWin) return;
    mainWin.show(); mainWin.focus();
    mainWin.webContents.send('mic:start');
  });
});

app.on('window-all-closed', () => {
  // Keep running in tray
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});
