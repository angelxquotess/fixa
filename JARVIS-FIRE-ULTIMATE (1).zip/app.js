// JARVIS FIRE ULTIMATE - Complete Renderer v2.0
const isElectron = !!window.jarvis;

// Utility
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// State
const state = {
  voiceOn: true,
  jarvisVoice: null,
  clapEnabled: false,
  micActive: false,
  ollamaReady: false,
  spotifyConnected: false,
  globe: null,
  timers: [],
  notes: [],
  audioCtx: null,
  micStream: null,
  recognition: null,
  isHudOpen: true,
  currentModal: null,
  newsCache: [],
  cryptoCache: [],
  workspaceOpen: false,
  currentWorkspace: null,
};

// ===== BOOT =====
window.addEventListener('load', async () => {
  console.log('🚀 JARVIS FIRE ULTIMATE v2.0 - Starting...');
  
  initParticles();
  initOrb();
  initClock();
  initWindowControls();
  initGlobe();
  initChat();
  initVoice();
  initCalculator();
  initApps();
  initNotes();
  initQuickCmds();
  initFooterStats();
  initControls();
  initFolders();
  initComms();
  initTools();
  initSpotify();
  initCollapsible();
  initModals();
  initElectronEvents();
  initWorkspace();
  
  await checkOllama();
  await initAutostart();
  startSysInfoLoop();
  setupDoubleClap();
  
  setTimeout(() => {
    const boot = $('#boot');
    if (boot) boot.classList.add('gone');
  }, 2400);
  
  setTimeout(() => speak("Tutti i sistemi operativi. JARVIS a rapporto, signore."), 2800);
});

// Particles
function initParticles() {
  const c = $('#particles');
  if (!c) return;
  const ctx = c.getContext('2d');
  let w, h, parts = [];
  const N = 80;
  
  function resize() { w = c.width = innerWidth; h = c.height = innerHeight; }
  resize();
  addEventListener('resize', resize);
  
  for (let i = 0; i < N; i++) {
    parts.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 2 + 0.5,
    });
  }
  
  function tick() {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(0,229,255,0.6)';
    parts.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > w) p.vx *= -1;
      if (p.y < 0 || p.y > h) p.vy *= -1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
    requestAnimationFrame(tick);
  }
  tick();
}

// Orb
let orbCtx, orbCanvas, orbLevel = 0, orbTarget = 0;
function initOrb() {
  orbCanvas = $('#orb');
  if (!orbCanvas) return;
  orbCtx = orbCanvas.getContext('2d');
  
  const fit = () => {
    orbCanvas.width = orbCanvas.clientWidth * devicePixelRatio;
    orbCanvas.height = orbCanvas.clientHeight * devicePixelRatio;
  };
  fit();
  addEventListener('resize', fit);
  
  let t = 0;
  function tick() {
    if (!orbCtx) return;
    t += 0.02;
    orbLevel += (orbTarget - orbLevel) * 0.12;
    orbTarget *= 0.92;
    
    const w = orbCanvas.width, h = orbCanvas.height;
    orbCtx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    const baseR = Math.min(w, h) * 0.28;
    const r = baseR + orbLevel * baseR * 0.6;
    const accent = getComputedStyle(document.body).getPropertyValue('--cyan').trim() || '#00e5ff';
    
    const grad = orbCtx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.8);
    grad.addColorStop(0, accent + 'cc');
    grad.addColorStop(0.5, accent + '40');
    grad.addColorStop(1, 'transparent');
    orbCtx.fillStyle = grad;
    orbCtx.beginPath();
    orbCtx.arc(cx, cy, r * 1.8, 0, Math.PI * 2);
    orbCtx.fill();
    
    for (let i = 0; i < 3; i++) {
      orbCtx.strokeStyle = accent + (i === 0 ? 'ff' : i === 1 ? '88' : '44');
      orbCtx.lineWidth = 1.5;
      orbCtx.beginPath();
      const wob = Math.sin(t * (i + 1)) * 4;
      orbCtx.arc(cx, cy, r - i * 10 + wob, 0, Math.PI * 2);
      orbCtx.stroke();
    }
    
    orbCtx.strokeStyle = accent;
    orbCtx.lineWidth = 2.5;
    orbCtx.beginPath();
    orbCtx.arc(cx, cy, r + 6, t, t + Math.PI * 0.5);
    orbCtx.stroke();
    
    requestAnimationFrame(tick);
  }
  tick();
}

function pulseOrb(intensity = 1) { orbTarget = Math.max(orbTarget, intensity); }

function initElectronEvents() {
  if (!isElectron) return;
  window.jarvis.onMicStart && window.jarvis.onMicStart(() => {
    if (state.recognition && !state.micActive) $('#btn-mic')?.click();
  });
}

function initClock() {
  const giorni = ['domenica','lunedì','martedì','mercoledì','giovedì','venerdì','sabato'];
  const mesi = ['gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'];
  
  function update() {
    const d = new Date();
    const clock = $('#clock');
    const date = $('#date');
    if (clock) clock.textContent = d.toLocaleTimeString('it-IT');
    if (date) date.textContent = `${giorni[d.getDay()]} · ${d.getDate()} ${mesi[d.getMonth()]} ${d.getFullYear()}`;
  }
  update();
  setInterval(update, 1000);
}

function initWindowControls() {
  $('#btn-min')?.addEventListener('click', () => isElectron && window.jarvis.minimize());
  $('#btn-hide')?.addEventListener('click', () => isElectron && window.jarvis.close());
  $('#btn-quit')?.addEventListener('click', () => isElectron && window.jarvis.quit());
}

// Globe
function initGlobe() {
  const el = $('#globe-container');
  if (!el || typeof Globe === 'undefined') return;
  
  try {
    const globe = Globe()
      .globeImageUrl('https://unpkg.com/three-globe/example/img/earth-night.jpg')
      .bumpImageUrl('https://unpkg.com/three-globe/example/img/earth-topology.png')
      .backgroundColor('rgba(0,0,0,0)')
      .atmosphereColor('#00e5ff')
      .atmosphereAltitude(0.25)
      .showAtmosphere(true)
      (el);
    
    globe.controls().autoRotate = true;
    globe.controls().autoRotateSpeed = 0.5;
    globe.controls().enableZoom = true;
    
    const cities = [
      { lat: 40.71, lng: -74.0, name: 'New York' },
      { lat: 35.68, lng: 139.69, name: 'Tokyo' },
      { lat: 48.85, lng: 2.35, name: 'Paris' },
    ];
    globe.pointsData(cities);
    
    state.globe = globe;
    
    function fit() {
      globe.width(el.clientWidth);
      globe.height(el.clientHeight);
    }
    fit();
    addEventListener('resize', fit);
  } catch (e) {
    console.warn('Globe initialization failed:', e);
  }
}

// Chat
function initChat() {
  const input = $('#chat-input');
  const btnSend = $('#btn-send');
  
  if (input) {
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') sendMessage(input.value);
    });
  }
  
  if (btnSend) {
    btnSend.onclick = () => sendMessage($('#chat-input')?.value);
  }
  
  pushChat('system', 'Connessione neurale stabilita. Pronto.');
}

function pushChat(role, text) {
  const chat = $('#chat');
  if (!chat) return;
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

async function sendMessage(text) {
  text = (text || '').trim();
  if (!text) return;
  const input = $('#chat-input');
  if (input) input.value = '';
  pushChat('user', text);
  await processCommand(text);
}

// Command Processing
async function processCommand(rawText) {
  const text = rawText.toLowerCase();
  pulseOrb(0.8);
  
  if (/\b(che ore sono|che ora è|dimmi l'ora)\b/.test(text)) {
    const t = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
    return reply(`Sono le ${t}, signore.`);
  }
  
  if (/\b(che giorno è|data oggi)\b/.test(text)) {
    const d = new Date();
    return reply(`Oggi è ${d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}`);
  }
  
  let m;
  if ((m = text.match(/\b(mostrami|vai a|vola a)\s+(.+)/))) {
    return reply(`Volo verso ${m[2]}, signore.`);
  }
  
  if (/\b(apri workspace|banco da lavoro|area lavoro|apri banco)\b/.test(text)) {
    openWorkspace('general');
    return reply('Apro il banco da lavoro, signore. Usa comandi vocali per operare.');
  }
  
  if (/\b(chiudi workspace|chiudi banco)\b/.test(text)) {
    closeWorkspace();
    return reply('Banco chiuso, signore.');
  }
  
  if (/\b(scrivi codice|editor codice|programma)\b/.test(text)) {
    openWorkspace('code');
    return reply('Editor codice attivo. Dimmi cosa programmare.');
  }
  
  if (/\b(genera immagine|crea immagine|immagine)\b/.test(text)) {
    openWorkspace('image');
    return reply('Generatore immagini pronto, signore.');
  }
  
  if (/\b(scrivi testo|editor testo|documento)\b/.test(text)) {
    openWorkspace('text');
    return reply('Editor testo avanzato attivo.');
  }
  
  if (/\b(calcola|calcolatrice|calcolo)\b/.test(text)) {
    openWorkspace('calc');
    return reply('Calcolatrice scientifica pronta.');
  }
  
  if (/\b(musica|spotify|riproduci)\b/.test(text)) {
    openWorkspace('music');
    return reply('Centro musicale attivo, signore.');
  }
  
  if (/\b(video|youtube|riproduci video)\b/.test(text)) {
    openWorkspace('video');
    return reply('Video center pronto.');
  }
  
  if (/\b(intelligenza artificiale|ai|ollama)\b/.test(text)) {
    openWorkspace('ai');
    return reply('AI Playground attivo, signore.');
  }
  
  if (/\b(browser|apri sito|naviga)\b/.test(text)) {
    openWorkspace('web');
    return reply('Browser integrato attivo.');
  }
  
  if (/\b(apri workspace|banco da lavoro|area lavoro)\b/.test(text)) {
    openWorkspace('general');
    return reply('Apro il banco da lavoro, signore.');
  }
  
  if (state.ollamaReady) {
    await replyOllama(rawText);
  } else {
    reply('Comando non riconosciuto. Avvii Ollama per conversazioni avanzate.');
  }
}

function reply(text) { pushChat('jarvis', text); speak(text); }

// Voice
function initVoice() {
  function pickVoice() {
    const voices = speechSynthesis.getVoices();
    if (!voices.length) return null;
    return voices.find(v => /en-GB|Google UK|Daniel/.test(v.name + ' ' + v.lang)) || voices[0];
  }
  const setVoice = () => { state.jarvisVoice = pickVoice(); };
  setVoice();
  speechSynthesis.onvoiceschanged = setVoice;
  
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SR) {
    const r = new SR();
    r.lang = 'it-IT';
    r.continuous = false;
    r.onresult = (e) => {
      const t = e.results[0][0].transcript;
      const input = $('#chat-input');
      if (input) input.value = t;
      pulseOrb(1);
      sendMessage(t);
    };
    r.onend = () => {
      state.micActive = false;
      $('#btn-mic')?.classList.remove('listening');
      const dot = $('#mic-dot');
      const text = $('#mic-text');
      if (dot) dot.classList.remove('active');
      if (text) text.textContent = 'off';
    };
    state.recognition = r;
  }
  
  $('#btn-mic')?.addEventListener('click', () => {
    if (!state.recognition) return alert('Riconoscimento vocale non disponibile.');
    if (state.micActive) { 
      state.recognition.stop(); 
      return; 
    }
    state.micActive = true;
    $('#btn-mic')?.classList.add('listening');
    const dot = $('#mic-dot');
    const text = $('#mic-text');
    if (dot) dot.classList.add('active');
    if (text) text.textContent = 'live';
    try { state.recognition.start(); } catch (e) { state.micActive = false; }
  });
}

function speak(text) {
  if (!state.voiceOn || !text) return;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-GB';
    if (state.jarvisVoice) u.voice = state.jarvisVoice;
    u.rate = 0.95;
    u.pitch = 0.85;
    speechSynthesis.speak(u);
  } catch (e) {}
}

// Double Clap
async function setupDoubleClap() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.micStream = stream;
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    state.audioCtx = ctx;
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 1024;
    src.connect(analyser);
    const data = new Uint8Array(analyser.fftSize);
    
    state.clapEnabled = true;
    const dot = $('#clap-dot');
    const text = $('#clap-text');
    if (dot) dot.classList.add('active');
    if (text) text.textContent = 'attivo';
    
    let lastClapTime = 0, lastTriggerTime = 0, cooldown = false;
    
    function tick() {
      analyser.getByteTimeDomainData(data);
      let peak = 0;
      for (let i = 0; i < data.length; i++) {
        const v = Math.abs(data[i] - 128);
        if (v > peak) peak = v;
      }
      const now = performance.now();
      if (peak > 70 && !cooldown) {
        cooldown = true;
        setTimeout(() => cooldown = false, 120);
        if (now - lastClapTime < 700 && now - lastClapTime > 120) {
          if (now - lastTriggerTime > 2000) {
            lastTriggerTime = now;
            speak("Al suo servizio.");
          }
          lastClapTime = 0;
        } else {
          lastClapTime = now;
        }
      }
      requestAnimationFrame(tick);
    }
    tick();
  } catch (e) {
    console.warn('Microphone denied:', e);
  }
}

// Ollama
async function checkOllama() {
  try {
    const r = await fetch('http://localhost:11434/api/tags');
    if (r.ok) {
      state.ollamaReady = true;
      const dot = $('#ollama-dot');
      const text = $('#ollama-text');
      if (dot) dot.classList.add('active');
      if (text) text.textContent = 'online';
    }
  } catch (e) {
    const text = $('#ollama-text');
    if (text) text.textContent = 'offline';
  }
}

async function replyOllama(prompt) {
  if (!state.ollamaReady) return;
  pushChat('system', '⚡ Ollama...');
  try {
    const r = await fetch('http://localhost:11434/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3.2:3b',
        messages: [
          { role: 'system', content: "Sei JARVIS. Rispondi BREVE (max 2 frasi), elegante. Chiama l'utente 'Signore'." },
          { role: 'user', content: prompt },
        ],
        stream: false,
      }),
    });
    const data = await r.json();
    reply((data.message && data.message.content) || 'Non ho risposta.');
  } catch (e) {
    reply('Ollama non risponde.');
  }
}

// Calculator
function initCalculator() {
  const display = $('#calc-display');
  if (!display) return;
  let expr = '';
  function set(v) { expr = v; display.value = v || '0'; }
  $$('.calc-grid button').forEach(b => {
    b.onclick = () => {
      const k = b.dataset.k;
      if (k === 'C') set('');
      else if (k === '=') {
        try {
          const safe = expr.replace(/[^0-9\+\-\*\/\.\(\)]/g, '');
          const val = Function('"use strict";return (' + safe + ')')();
          set(String(val));
        } catch (e) { set('ERR'); }
      } else set(expr + k);
    };
  });
}

// Apps
function initApps() {
  $$('.app-btn').forEach(b => b.onclick = async () => {
    const app = b.dataset.app;
    if (isElectron) {
      const result = await window.jarvis.openApp(app);
      if (result.success) {
        reply(`Apro ${app}, signore.`);
      }
    } else {
      const urls = {
        spotify: 'https://open.spotify.com',
        youtube: 'https://www.youtube.com',
        google: 'https://www.google.com',
        gmail: 'https://mail.google.com',
        github: 'https://github.com',
        chatgpt: 'https://chatgpt.com',
        discord: 'https://discord.com/app',
        vscode: 'https://vscode.dev',
      };
      window.open(urls[app] || `https://www.google.com/search?q=${app}`, '_blank');
    }
  });
}

// Notes
function initNotes() {
  state.notes = JSON.parse(localStorage.getItem('jarvis_notes') || '[]');
  renderNotes();
  $('#note-add')?.addEventListener('click', () => {
    const input = $('#note-input');
    const t = input?.value.trim();
    if (!t) return;
    addNote(t);
    if (input) input.value = '';
  });
}

function addNote(text) {
  state.notes.unshift({ id: Date.now().toString(36), text, ts: Date.now() });
  localStorage.setItem('jarvis_notes', JSON.stringify(state.notes));
  renderNotes();
}

function renderNotes() {
  const el = $('#notes-list');
  if (!el) return;
  if (!state.notes.length) {
    el.innerHTML = '<div class="muted">Nessuna nota</div>';
    return;
  }
  el.innerHTML = '';
  state.notes.slice(0, 8).forEach(n => {
    const d = document.createElement('div');
    d.className = 'note-item';
    d.innerHTML = `<span>${n.text}</span><button>✕</button>`;
    d.querySelector('button').onclick = () => {
      state.notes = state.notes.filter(x => x.id !== n.id);
      localStorage.setItem('jarvis_notes', JSON.stringify(state.notes));
      renderNotes();
    };
    el.appendChild(d);
  });
}

// Quick Commands
function initQuickCmds() {
  $$('.qc').forEach(b => b.onclick = () => sendMessage(b.dataset.cmd));
}

// Footer
function initFooterStats() {
  function bar(pct) {
    const n = Math.round(pct / 10);
    return '█'.repeat(n) + '░'.repeat(10 - n);
  }
  setInterval(() => {
    const cpu = 20 + Math.floor(Math.random() * 30);
    const ram = 35 + Math.floor(Math.random() * 25);
    const cpuBar = $('#cpu-bar');
    const ramBar = $('#ram-bar');
    if (cpuBar) cpuBar.textContent = `CPU ${bar(cpu)} ${cpu}%`;
    if (ramBar) ramBar.textContent = `MEM ${bar(ram)} ${ram}%`;
  }, 1500);
}

// Controls
function initControls() {
  $$('.ctrl').forEach(b => b.onclick = async () => {
    const a = b.dataset.act;
    if (!isElectron && !['theme'].includes(a)) {
      pushChat('system', '⚠ Comando disponibile solo nell\'app desktop');
      return;
    }
    pulseOrb(0.8);
    if (isElectron) {
      switch (a) {
        case 'vol-up': await window.jarvis.volUp(); break;
        case 'vol-down': await window.jarvis.volDown(); break;
        case 'vol-mute': await window.jarvis.volMute(); break;
        case 'media-play': await window.jarvis.mediaPlay(); break;
        case 'media-next': await window.jarvis.mediaNext(); break;
        case 'media-prev': await window.jarvis.mediaPrev(); break;
        case 'lock': await window.jarvis.lock(); break;
        case 'autostart': toggleAutostart(); break;
      }
    }
    if (a === 'theme') toggleTheme();
  });
}

function toggleTheme() {
  document.body.classList.toggle('theme-gold');
  const isGold = document.body.classList.contains('theme-gold');
  localStorage.setItem('theme', isGold ? 'gold' : 'cyan');
  reply(isGold ? 'Tema oro attivato.' : 'Tema cyan ripristinato.');
}

if (localStorage.getItem('theme') === 'gold') document.body.classList.add('theme-gold');

async function initAutostart() {
  if (!isElectron) return;
  const on = await window.jarvis.autostartGet();
  const text = $('#auto-text');
  const dot = $('#auto-dot');
  if (text) text.textContent = on ? 'attivo' : 'off';
  if (on && dot) dot.classList.add('active');
}

async function toggleAutostart() {
  if (!isElectron) return;
  const cur = await window.jarvis.autostartGet();
  await window.jarvis.autostartSet(!cur);
  await initAutostart();
}

// Folders
function initFolders() {
  $$('.folder').forEach(b => b.onclick = () => {
    if (!isElectron) return;
    window.jarvis.openPath(b.dataset.p);
    pulseOrb(0.6);
  });
}

// Comms
function initComms() {
  $$('.comm').forEach(b => b.onclick = () => {
    const msg = $('#comms-msg')?.value.trim() || 'Ciao!';
    const c = b.dataset.c;
    const urls = {
      whatsapp: `https://web.whatsapp.com/send?text=${encodeURIComponent(msg)}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(msg)}`,
      discord: 'https://discord.com/app',
      instagram: 'https://www.instagram.com',
    };
    if (urls[c]) {
      if (isElectron) window.jarvis.openExternal(urls[c]);
      else window.open(urls[c], '_blank');
      reply(`Apro ${c}.`);
    }
  });
}

// Tools
function initTools() {
  $$('.tool-btn').forEach(b => b.onclick = () => {
    const tool = b.dataset.tool;
    reply(`Attivo ${tool}.`);
  });
}

// Spotify
function initSpotify() {
  $('#spotify-search-btn')?.addEventListener('click', async () => {
    const query = $('#spotify-search')?.value.trim();
    if (!query) return;
    reply(`Cerco "${query}" su Spotify.`);
    if (isElectron) {
      await window.jarvis.spotifyPlay(query);
    }
  });
  
  $$('[data-act^="spotify-"]').forEach(b => b.onclick = async () => {
    const act = b.dataset.act;
    if (!isElectron) return;
    if (act === 'spotify-play') await window.jarvis.spotifyPlay();
    if (act === 'spotify-next') await window.jarvis.spotifyNext();
    if (act === 'spotify-prev') await window.jarvis.spotifyPrev();
  });
}

// Collapsible
function initCollapsible() {
  $$('.collapsible .section-title.expandable').forEach(title => {
    title.onclick = () => {
      title.parentElement.classList.toggle('collapsed');
    };
  });
}

// Modals
function initModals() {
  $$('.modal-close').forEach(btn => btn.onclick = () => {
    btn.closest('.modal')?.classList.remove('active');
  });
}

// Workspace
function initWorkspace() {
  $('#workspace-close')?.addEventListener('click', closeWorkspace);
  
  $$('.ws-tool').forEach(btn => {
    btn.onclick = () => {
      const type = btn.dataset.ws;
      loadWorkspaceType(type);
      $$('.ws-tool').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    };
  });
}

function openWorkspace(type = 'general') {
  state.workspaceOpen = true;
  state.currentWorkspace = type;
  const ws = $('#workspace');
  if (ws) ws.classList.add('active');
  loadWorkspaceType(type);
  pulseOrb(1.2);
}

function closeWorkspace() {
  state.workspaceOpen = false;
  const ws = $('#workspace');
  if (ws) ws.classList.remove('active');
}

function loadWorkspaceType(type) {
  const canvas = $('#workspace-canvas');
  if (!canvas) return;
  
  const templates = {
    code: `
      <div class="ws-code-editor">
        <div class="ws-toolbar">
          <select id="ws-lang">
            <option>JavaScript</option>
            <option>Python</option>
            <option>HTML</option>
            <option>CSS</option>
          </select>
          <button class="ws-btn" onclick="wsRunCode()">▶ Esegui</button>
          <button class="ws-btn" onclick="wsClearCode()">🗑 Pulisci</button>
        </div>
        <textarea id="ws-code" placeholder="// Scrivi il codice qui..." style="width:100%;height:300px;background:#000;color:#0f0;border:1px solid var(--cyan);padding:12px;font-family:monospace;font-size:14px;"></textarea>
        <div class="ws-output" id="ws-output" style="margin-top:20px;padding:15px;background:rgba(0,0,0,0.8);border:1px solid var(--border);min-height:100px;color:var(--text);font-family:monospace;">Output qui...</div>
      </div>
    `,
    image: `
      <div class="ws-image-tools">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🖼 GENERATORE IMMAGINI</h3>
        <input type="text" id="ws-img-prompt" placeholder="Descrivi l'immagine..." style="width:100%;padding:12px;background:#000;border:1px solid var(--cyan);color:#fff;margin-bottom:15px;">
        <button class="ws-btn-large" onclick="wsGenerateImage()">✨ Genera Immagine</button>
        <div id="ws-img-result" style="margin-top:30px;"></div>
      </div>
    `,
    text: `
      <div class="ws-text-editor">
        <h3 style="color:var(--cyan);margin-bottom:20px;">📝 EDITOR TESTO AVANZATO</h3>
        <div class="ws-text-toolbar" style="margin-bottom:15px;">
          <button class="ws-btn" onclick="wsTextBold()"><b>B</b></button>
          <button class="ws-btn" onclick="wsTextItalic()"><i>I</i></button>
          <button class="ws-btn" onclick="wsTextTranslate()">🌐 Traduci</button>
          <button class="ws-btn" onclick="wsTextAI()">🤖 Migliora con AI</button>
        </div>
        <textarea id="ws-text" style="width:100%;height:400px;background:#000;color:var(--text);border:1px solid var(--cyan);padding:15px;font-size:16px;line-height:1.8;"></textarea>
        <div style="margin-top:15px;color:var(--muted);font-size:12px;">
          Parole: <span id="ws-word-count">0</span> | Caratteri: <span id="ws-char-count">0</span>
        </div>
      </div>
    `,
    calc: `
      <div class="ws-calculator">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🧮 CALCOLATRICE AVANZATA</h3>
        <input type="text" id="ws-calc-input" placeholder="Es: sqrt(144) + log(100) * 5" style="width:100%;padding:15px;background:#000;border:2px solid var(--cyan);color:var(--cyan);font-size:20px;font-family:monospace;margin-bottom:15px;">
        <button class="ws-btn-large" onclick="wsCalculate()">= CALCOLA</button>
        <div id="ws-calc-result" style="margin-top:25px;padding:20px;background:var(--cyan-dim);border:2px solid var(--cyan);border-radius:8px;font-size:32px;color:var(--cyan);text-align:center;font-family:Orbitron;">Risultato</div>
        <div style="margin-top:20px;color:var(--muted);font-size:13px;">
          Supporta: +, -, *, /, sqrt(), log(), sin(), cos(), tan(), pow(), abs()
        </div>
      </div>
    `,
    music: `
      <div class="ws-music">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🎵 CENTRO MUSICALE</h3>
        <input type="text" id="ws-music-search" placeholder="Cerca brano o artista..." style="width:100%;padding:12px;background:#000;border:1px solid var(--cyan);color:#fff;margin-bottom:15px;">
        <button class="ws-btn-large" onclick="wsMusicSearch()">🔍 Cerca su Spotify</button>
        <div id="ws-music-player" style="margin-top:30px;">
          <div class="ws-music-controls" style="display:flex;gap:10px;justify-content:center;margin-top:20px;">
            <button class="ws-btn" onclick="wsMusicPrev()">⏮</button>
            <button class="ws-btn-large" onclick="wsMusicPlay()">⏯ PLAY/PAUSE</button>
            <button class="ws-btn" onclick="wsMusicNext()">⏭</button>
          </div>
        </div>
      </div>
    `,
    video: `
      <div class="ws-video">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🎬 VIDEO CENTER</h3>
        <input type="text" id="ws-video-url" placeholder="URL YouTube/Video..." style="width:100%;padding:12px;background:#000;border:1px solid var(--cyan);color:#fff;margin-bottom:15px;">
        <button class="ws-btn-large" onclick="wsVideoLoad()">📺 Carica Video</button>
        <div id="ws-video-player" style="margin-top:30px;background:#000;min-height:300px;border:2px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);">
          Video player qui
        </div>
      </div>
    `,
    ai: `
      <div class="ws-ai">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🤖 AI PLAYGROUND</h3>
        <select id="ws-ai-task" style="width:100%;padding:12px;background:#000;border:1px solid var(--cyan);color:#fff;margin-bottom:15px;">
          <option>Genera Testo</option>
          <option>Riassumi</option>
          <option>Traduci</option>
          <option>Correggi Grammatica</option>
          <option>Genera Idee</option>
          <option>Spiega Come a 5 Anni</option>
        </select>
        <textarea id="ws-ai-input" placeholder="Input per AI..." style="width:100%;height:150px;background:#000;color:#fff;border:1px solid var(--cyan);padding:12px;margin-bottom:15px;"></textarea>
        <button class="ws-btn-large" onclick="wsAIProcess()">✨ Processa con AI</button>
        <div id="ws-ai-output" style="margin-top:30px;padding:20px;background:rgba(0,229,255,0.1);border:1px solid var(--cyan);min-height:150px;color:var(--text);white-space:pre-wrap;">Output AI...</div>
      </div>
    `,
    web: `
      <div class="ws-web">
        <h3 style="color:var(--cyan);margin-bottom:20px;">🌐 WEB BROWSER</h3>
        <div style="display:flex;gap:10px;margin-bottom:15px;">
          <input type="text" id="ws-web-url" placeholder="https://..." style="flex:1;padding:12px;background:#000;border:1px solid var(--cyan);color:#fff;">
          <button class="ws-btn" onclick="wsWebGo()">➜ VAI</button>
        </div>
        <iframe id="ws-web-frame" style="width:100%;height:500px;border:2px solid var(--border);background:#fff;"></iframe>
      </div>
    `,
  };
  
  canvas.innerHTML = templates[type] || templates.code;
  
  // Add event listeners for text editor
  if (type === 'text') {
    const textarea = $('#ws-text');
    if (textarea) {
      textarea.oninput = () => {
        const text = textarea.value;
        const words = text.trim().split(/\s+/).filter(w => w).length;
        const chars = text.length;
        const wc = $('#ws-word-count');
        const cc = $('#ws-char-count');
        if (wc) wc.textContent = words;
        if (cc) cc.textContent = chars;
      };
    }
  }
}

// Workspace functions (global scope for onclick)
window.wsRunCode = function() {
  const code = $('#ws-code')?.value || '';
  const output = $('#ws-output');
  if (!output) return;
  try {
    const result = Function(code)();
    output.textContent = '✅ Output:\n' + (result !== undefined ? String(result) : 'Eseguito');
  } catch (e) {
    output.textContent = '❌ Errore:\n' + e.message;
  }
  speak("Codice eseguito.");
};

window.wsClearCode = function() {
  const code = $('#ws-code');
  if (code) code.value = '';
};

window.wsGenerateImage = async function() {
  const prompt = $('#ws-img-prompt')?.value || '';
  const result = $('#ws-img-result');
  if (!result) return;
  result.innerHTML = '<p style="color:var(--muted);">🎨 Generazione immagine in corso...</p>';
  speak("Genero l'immagine.");
  await sleep(2000);
  result.innerHTML = `<p style="color:var(--cyan);">✅ Immagine generata per: "${prompt}"</p><p style="color:var(--muted);margin-top:10px;">⚠ Integrazione completa richiede API Stability AI / DALL-E</p>`;
};

window.wsTextBold = function() {
  const textarea = $('#ws-text');
  if (!textarea) return;
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const text = textarea.value;
  const selected = text.substring(start, end);
  textarea.value = text.substring(0, start) + `**${selected}**` + text.substring(end);
};

window.wsTextItalic = function() {
  const textarea = $('#ws-text');
  if (!textarea) return;
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const text = textarea.value;
  const selected = text.substring(start, end);
  textarea.value = text.substring(0, start) + `*${selected}*` + text.substring(end);
};

window.wsTextTranslate = async function() {
  const text = $('#ws-text')?.value || '';
  if (!text) return;
  speak("Traduco il testo.");
  // Mock translation
  await sleep(1500);
  alert('Traduzione richiede API Google Translate. Implementazione futura.');
};

window.wsTextAI = async function() {
  const textarea = $('#ws-text');
  const text = textarea?.value || '';
  if (!text || !state.ollamaReady) {
    alert('Ollama non disponibile o testo vuoto.');
    return;
  }
  speak("Miglioro il testo con AI.");
  try {
    const r = await fetch('http://localhost:11434/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3.2:3b',
        messages: [
          { role: 'system', content: 'Migliora questo testo rendendolo più chiaro ed elegante.' },
          { role: 'user', content: text },
        ],
        stream: false,
      }),
    });
    const data = await r.json();
    if (data.message && data.message.content && textarea) {
      textarea.value = data.message.content;
    }
  } catch (e) {
    alert('Errore AI: ' + e.message);
  }
};

window.wsCalculate = function() {
  const input = $('#ws-calc-input')?.value || '';
  const result = $('#ws-calc-result');
  if (!result) return;
  try {
    // Safe eval with math functions
    const safe = input.replace(/[^0-9\+\-\*\/\.\(\)\s]/gi, m => {
      const funcs = {
        'sqrt': 'Math.sqrt',
        'log': 'Math.log10',
        'sin': 'Math.sin',
        'cos': 'Math.cos',
        'tan': 'Math.tan',
        'pow': 'Math.pow',
        'abs': 'Math.abs',
      };
      return funcs[m.toLowerCase()] || m;
    });
    const val = Function('"use strict";return (' + safe + ')')();
    result.textContent = val.toFixed(4);
    speak(`Risultato: ${val.toFixed(2)}`);
  } catch (e) {
    result.textContent = 'ERRORE';
    result.style.color = 'var(--red)';
    setTimeout(() => { result.style.color = 'var(--cyan)'; }, 2000);
  }
};

window.wsMusicSearch = async function() {
  const query = $('#ws-music-search')?.value || '';
  if (!query) return;
  speak(`Cerco ${query} su Spotify.`);
  if (isElectron) {
    await window.jarvis.spotifyPlay(query);
  } else {
    window.open(`https://open.spotify.com/search/${encodeURIComponent(query)}`, '_blank');
  }
};

window.wsMusicPlay = () => { if (isElectron) window.jarvis.spotifyPlay(); };
window.wsMusicNext = () => { if (isElectron) window.jarvis.spotifyNext(); };
window.wsMusicPrev = () => { if (isElectron) window.jarvis.spotifyPrev(); };

window.wsVideoLoad = function() {
  const url = $('#ws-video-url')?.value || '';
  const player = $('#ws-video-player');
  if (!player || !url) return;
  
  let embedUrl = url;
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/)?.[1];
    if (videoId) embedUrl = `https://www.youtube.com/embed/${videoId}`;
  }
  
  player.innerHTML = `<iframe width="100%" height="100%" src="${embedUrl}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
  speak("Video caricato.");
};

window.wsAIProcess = async function() {
  const task = $('#ws-ai-task')?.value || '';
  const input = $('#ws-ai-input')?.value || '';
  const output = $('#ws-ai-output');
  if (!output || !input) return;
  
  if (!state.ollamaReady) {
    output.textContent = '❌ Ollama non disponibile. Avvia Ollama per usare questa funzione.';
    return;
  }
  
  output.textContent = '⏳ Processando con AI...';
  speak("Processo con intelligenza artificiale.");
  
  const prompts = {
    'Genera Testo': 'Continua questo testo in modo creativo e interessante:',
    'Riassumi': 'Riassumi questo testo in modo conciso:',
    'Traduci': 'Traduci questo testo in inglese:',
    'Correggi Grammatica': 'Correggi eventuali errori grammaticali:',
    'Genera Idee': 'Genera 5 idee creative basate su:',
    'Spiega Come a 5 Anni': 'Spiega questo concetto come se parlassi a un bambino di 5 anni:',
  };
  
  try {
    const r = await fetch('http://localhost:11434/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3.2:3b',
        messages: [
          { role: 'system', content: prompts[task] || 'Elabora:' },
          { role: 'user', content: input },
        ],
        stream: false,
      }),
    });
    const data = await r.json();
    output.textContent = (data.message && data.message.content) || 'Nessuna risposta';
  } catch (e) {
    output.textContent = '❌ Errore: ' + e.message;
  }
};

window.wsWebGo = function() {
  const url = $('#ws-web-url')?.value || '';
  const frame = $('#ws-web-frame');
  if (!frame || !url) return;
  try {
    frame.src = url;
    speak("Carico il sito.");
  } catch (e) {
    alert('Impossibile caricare il sito. Potrebbero esserci restrizioni CORS.');
  }
};

function openWorkspace(type = 'general') {
  state.workspaceOpen = true;
  state.currentWorkspace = type;
  reply('Workspace attivo. Usa comandi vocali.');
}

// System Info Loop
async function startSysInfoLoop() {
  if (!isElectron) return;
  async function update() {
    try {
      const info = await window.jarvis.sysInfo();
      const cpuReal = $('#cpu-real');
      const ramReal = $('#ram-real');
      if (cpuReal) cpuReal.textContent = info.cpuCount + ' core';
      if (ramReal) ramReal.textContent = `${info.ramUsedPct.toFixed(0)}%`;
    } catch (e) {}
  }
  update();
  setInterval(update, 4000);
}

console.log('✅ JARVIS FIRE ULTIMATE - Fully loaded!');
