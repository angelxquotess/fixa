const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('jarvis', {
  isElectron: true,
  
  // Window controls
  minimize: () => ipcRenderer.invoke('app:minimize'),
  close: () => ipcRenderer.invoke('app:close'),
  quit: () => ipcRenderer.invoke('app:quit'),
  
  // External/paths
  openExternal: (url) => ipcRenderer.invoke('app:open-external', url),
  openPath: (p) => ipcRenderer.invoke('app:open-path', p),
  openApp: (appName) => ipcRenderer.invoke('app:open-app', appName),
  
  // HUD control
  toggleHud: () => ipcRenderer.invoke('app:toggle-hud'),
  hudVisible: () => ipcRenderer.invoke('app:hud-visible'),
  micTrigger: () => ipcRenderer.invoke('app:mic-trigger'),
  
  // Autostart
  autostartGet: () => ipcRenderer.invoke('app:autostart-get'),
  autostartSet: (on) => ipcRenderer.invoke('app:autostart-set', on),
  
  // System info
  sysInfo: () => ipcRenderer.invoke('sys:info'),
  
  // Media controls
  volUp: () => ipcRenderer.invoke('sys:vol-up'),
  volDown: () => ipcRenderer.invoke('sys:vol-down'),
  volMute: () => ipcRenderer.invoke('sys:vol-mute'),
  mediaPlay: () => ipcRenderer.invoke('sys:media-play'),
  mediaNext: () => ipcRenderer.invoke('sys:media-next'),
  mediaPrev: () => ipcRenderer.invoke('sys:media-prev'),
  lock: () => ipcRenderer.invoke('sys:lock'),
  
  // Spotify controls
  spotifySearch: (query) => ipcRenderer.invoke('spotify:search', query),
  spotifyPlay: (track) => ipcRenderer.invoke('spotify:play', track),
  spotifyPause: () => ipcRenderer.invoke('spotify:pause'),
  spotifyNext: () => ipcRenderer.invoke('spotify:next'),
  spotifyPrev: () => ipcRenderer.invoke('spotify:prev'),
  spotifyGetCurrent: () => ipcRenderer.invoke('spotify:get-current'),
  
  // File operations
  fileSearch: (query) => ipcRenderer.invoke('file:search', query),
  screenshot: (options) => ipcRenderer.invoke('screen:capture', options),
  
  // Events
  onMicStart: (cb) => ipcRenderer.on('mic:start', cb),
  onHudVisible: (cb) => ipcRenderer.on('hud:visible', (_, v) => cb(v)),
  onSpotifyUpdate: (cb) => ipcRenderer.on('spotify:update', (_, data) => cb(data)),
});
