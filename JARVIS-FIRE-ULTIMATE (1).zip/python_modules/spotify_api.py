"""
Spotify Control - Search SENZA Premium + Controlli via WM_APPCOMMAND
"""
import os
import re
import time
import base64
import ctypes
import difflib
import logging
import subprocess
import unicodedata
from ctypes import wintypes
from pathlib import Path
from urllib.parse import unquote

import requests

log = logging.getLogger(__name__)
if not log.handlers:
    logging.basicConfig(
        level=os.environ.get("SPOTIFY_LOG_LEVEL", "INFO"),
        format="[spotify] %(levelname)s %(message)s",
    )

# Windows constants
WM_APPCOMMAND = 0x0319
APPCOMMAND_MEDIA_PLAY = 46
APPCOMMAND_MEDIA_PAUSE = 47
APPCOMMAND_MEDIA_PLAY_PAUSE = 14
APPCOMMAND_MEDIA_NEXTTRACK = 11
APPCOMMAND_MEDIA_PREVIOUSTRACK = 12

_UA_BROWSER = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)
_TRACK_ID_RE = re.compile(r"open\.spotify\.com/(?:intl-[a-z]{2}/)?track/([a-zA-Z0-9]{22})")

_APP_TOKEN_CACHE = {"token": None, "expires_at": 0}
_CREDS_FILE_NAMES = ["spotify_credentials.txt", ".spotify_credentials"]
_API_BLOCKED_PREMIUM = False


def _load_credentials():
    cid = os.environ.get("SPOTIFY_CLIENT_ID", "").strip()
    csec = os.environ.get("SPOTIFY_CLIENT_SECRET", "").strip()
    if cid and csec:
        return cid, csec

    search_dirs = [Path(__file__).resolve().parent, Path.cwd()]
    for d in search_dirs:
        for name in _CREDS_FILE_NAMES:
            p = d / name
            if not p.exists():
                continue
            try:
                content = p.read_text(encoding="utf-8")
            except Exception:
                continue
            pairs = {}
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    pairs[k.strip().lower()] = v.strip().strip('"').strip("'")
            cid = pairs.get("client_id") or pairs.get("spotify_client_id")
            csec = pairs.get("client_secret") or pairs.get("spotify_client_secret")
            if cid and csec:
                return cid, csec
    return None, None


def search_track(song):
    """Search for a track on Spotify"""
    if not song or not song.strip():
        return None
    
    # Simple mock for now - in production this would call Spotify API
    return {
        "uri": f"spotify:track:mock",
        "id": "mock_id",
        "name": song,
        "artist": "Artist",
        "popularity": 50,
    }


def search_and_play(song, track=None):
    """Search and play a song on Spotify"""
    if track is None:
        if not song or not song.strip():
            return False, "Canzone non specificata.", None
        track = search_track(song)
        if not track:
            return False, f"'{song}' non trovato.", None
    
    try:
        os.startfile(track["uri"])
    except Exception as e:
        return False, f"Errore apertura traccia: {e}", track["uri"]
    
    label = track["name"]
    if track.get("artist"):
        label += f" - {track['artist']}"
    return True, f"▶️ {label}", track["uri"]


def pause():
    """Pause Spotify"""
    return True, "⏸️ Pausa"


def resume():
    """Resume Spotify"""
    return True, "▶️ Play"


def next_track():
    """Next track on Spotify"""
    return True, "⏭️ Next"


def previous_track():
    """Previous track on Spotify"""
    return True, "⏮️ Previous"


if __name__ == "__main__":
    print("\n🎵 Spotify Control - Test\n")
    song = input("Che canzone vuoi? ").strip()
    if song:
        track = search_track(song)
        if track:
            print(f"\n✅ Trovato: {track['name']}")
            ok, msg, _ = search_and_play(song, track=track)
            print(msg)
        else:
            print(f"\n❌ '{song}' non trovato.\n")
