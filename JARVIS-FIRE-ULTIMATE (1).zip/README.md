# 🚀 JARVIS FIRE ULTIMATE v2.0

## Il Tuo Assistente AI Futuristico Completo

**JARVIS FIRE ULTIMATE** è un assistente vocale desktop avanzato con interfaccia futuristica, globo 3D interattivo, workspace sliding, integrazione Spotify, AI locale con Ollama e molto altro.

---

## ✨ CARATTERISTICHE PRINCIPALI

### 🌍 Globo 3D Interattivo
- Globo terrestre fotorealistico navigabile
- Vola verso qualsiasi città con comando vocale
- Visualizza meteo in tempo reale
- Modalità satellite e notturna

### 🎙 Comandi Vocali Avanzati
- Riconoscimento vocale in italiano
- Attivazione tramite doppio clap
- Sintesi vocale in inglese britannico (voce JARVIS)
- Esecuzione comandi sistema

### 🛠 WORKSPACE SLIDING
**NOVITÀ ASSOLUTA!** Banco da lavoro che slide da destra con 8 modalità:

1. **💻 Editor Codice** - Scrivi e esegui JavaScript/Python
2. **🖼 Generatore Immagini** - Crea immagini con AI
3. **📝 Editor Testo** - Word processor avanzato con AI
4. **🧮 Calcolatrice Scientifica** - Calcoli complessi
5. **🎵 Centro Musicale** - Controllo Spotify completo
6. **🎬 Video Center** - Player YouTube integrato
7. **🤖 AI Playground** - 6 modalità AI con Ollama
8. **🌐 Browser** - Navigazione web integrata

**Comandi Vocali per Workspace:**
- "Apri banco da lavoro" / "Apri workspace"
- "Scrivi codice" - Editor codice
- "Genera immagine" - Generatore immagini
- "Scrivi testo" - Editor testo
- "Calcola" - Calcolatrice
- "Musica" - Centro musicale
- "Intelligenza artificiale" - AI Playground
- "Browser" - Web browser

### 🎵 Integrazione Spotify
- Ricerca brani vocale
- Play/Pause/Next/Prev
- Visualizzazione traccia corrente
- Apertura app nativa

### 🤖 AI con Ollama
- Conversazioni intelligenti locali
- Modelli LLaMA 3.2 integrati
- Processing testo avanzato
- Nessuna API esterna necessaria

### ₿ Crypto & News Tracker
- Prezzi criptovalute in tempo reale
- News feed internazionali
- Aggiornamenti automatici

### ⏲ Pomodoro Timer
- Timer rapidi: 5, 15, 25 min, 1h
- Notifiche sonore
- Gestione multipla timer

### 🛠 Strumenti Integrati
- 🌐 Traduttore multi-lingua
- 🔐 Generatore password sicure
- 🎨 Color picker avanzato
- 📏 Convertitore unità
- 📸 Screenshot tool
- 🔍 Ricerca file veloce

### 💬 Messaggi Unificati
- WhatsApp, Telegram, Discord, Instagram
- Selezione destinatario
- Invio rapido da un'unica interfaccia

### ⚡ Controlli Sistema
- Volume +/-/Mute
- Controlli media universali
- Blocco PC
- Accesso cartelle rapido
- Auto-start Windows

### 🎨 Temi Personalizzabili
- Tema Cyan (default) - Futuristico neon
- Tema Gold - Classico elegante
- Cambio istantaneo con comando vocale

---

## 📦 INSTALLAZIONE

### Requisiti
- **Windows 10/11** (64-bit)
- **Node.js v16+** ([Download](https://nodejs.org))
- **4 GB RAM** minimo (8 GB consigliato)
- **500 MB** spazio libero

### Opzionali (per features complete)
- **Ollama** per AI locale ([Download](https://ollama.ai))
- **Spotify Desktop** per controlli musicali
- **Microfono** per comandi vocali

### Installazione

```bash
# 1. Estrai i file dalla ZIP
# 2. Apri terminale nella cartella

# 3. Installa dipendenze
npm install

# 4. Testa in modalità sviluppo
npm start

# 5. Crea eseguibile Windows
npm run dist

# Troverai l'installer in:
# dist/JARVIS FIRE ULTIMATE Setup.exe
```

---

## 🎮 UTILIZZO

### Primo Avvio
1. Avvia l'app
2. Concedi permessi microfono (per comandi vocali)
3. JARVIS dirà: "Tutti i sistemi operativi, signore"

### Attivazione Comando Vocale
- **Tasto Insert** - Attiva microfono singolo comando
- **Doppio Clap** - Attivazione hands-free
- **Click icona 🎙** - Toggle manuale

### Shortcuts Tastiera
- `Ctrl+Alt+J` - Toggle HUD (mostra/nascondi)
- `Ctrl+Shift+Space` - Toggle interfaccia
- `Insert` - Attiva microfono

### Comandi Vocali Esempio
```
"Mostrami New York"
"Che ore sono"
"Riproduci Bohemian Rhapsody"
"Apri banco da lavoro"
"Scrivi codice"
"Genera immagine di un tramonto"
"Calcola sqrt(144) + 5"
"Intelligenza artificiale"
"Tema oro" / "Tema cyan"
```

### Workspace - Comandi Specifici

**Editor Codice:**
```
"Scrivi codice" -> Si apre editor
"Esegui codice" (dopo aver scritto)
```

**Generatore Immagini:**
```
"Genera immagine" -> Si apre generatore
Scrivi descrizione -> "Crea immagine"
```

**Calcolatrice:**
```
"Calcola" -> Si apre calcolatrice
Inserisci formula complessa
"sqrt(144) + log(100) * 5"
```

**AI Playground:**
```
"Intelligenza artificiale" -> Si apre AI
Seleziona task: Riassumi, Traduci, ecc.
Inserisci testo -> "Processa con AI"
```

---

## 🔧 CONFIGURAZIONE OLLAMA

Per conversazioni AI avanzate, installa Ollama:

```bash
# 1. Scarica Ollama da https://ollama.ai
# 2. Installa sul tuo PC
# 3. Apri terminale e scarica il modello:

ollama pull llama3.2:3b

# 4. Ollama parte automaticamente su http://localhost:11434
# 5. JARVIS rileva Ollama all'avvio e lo indica con dot verde
```

---

## 📝 NOTE TECNICHE

### Porte Utilizzate
- **11434** - Ollama AI (localhost)
- Nessuna porta esterna necessaria

### Storage
- Note salvate in `localStorage`
- Timer in memoria (reset al riavvio)
- Temi salvati in `localStorage`

### Privacy
- **Tutto in locale** - Nessun dato inviato online
- Ollama gira sul tuo PC
- Spotify richiede autenticazione web (sicura)

### Limitazioni
- Spotify richiede app desktop installata per controlli avanzati
- Double-clap richiede permessi microfono
- Alcuni comandi sistema solo su Windows
- Generazione immagini AI richiede integrazione API esterna (non inclusa di default)

---

## 🆘 TROUBLESHOOTING

### App non si avvia
```bash
# Reinstalla dipendenze
rm -rf node_modules package-lock.json
npm install
```

### Ollama non connette
1. Verifica Ollama sia in esecuzione: `ollama serve`
2. Testa endpoint: `curl http://localhost:11434`
3. Scarica modello: `ollama pull llama3.2:3b`

### Microfono non funziona
1. Controlla permessi Windows (Impostazioni > Privacy > Microfono)
2. Riavvia l'app
3. Click su 🎙 per test manuale

### Spotify non risponde
1. Assicurati Spotify Desktop sia installato
2. Accedi a Spotify almeno una volta
3. Prova apertura manuale: "Apri Spotify"

### Globo 3D non carica
1. Verifica connessione internet (carica texture online)
2. Riavvia l'app
3. Controlla console errori (F12 in dev mode)

---

## 🚀 BUILD ESEGUIBILE

### Crea Installer Windows

```bash
# Build completo con installer
npm run dist

# Solo portable (ZIP)
npm run dist:portable

# File generati in /dist/:
# - JARVIS FIRE ULTIMATE Setup.exe (Installer)
# - JARVIS FIRE ULTIMATE.exe (Portable)
```

### Dimensioni
- **Installer**: ~150 MB
- **Eseguibile**: ~180 MB estratto
- Include Electron + Chromium + Node

---

## 📜 LICENZA

MIT License - Uso libero personale e commerciale

---

## 👨‍💻 SVILUPPATORE

Creato da **angelxquotess** • 2025

Per supporto o domande:
- GitHub Issues
- Email: [contatto]

---

## 🎯 ROADMAP FUTURE

### v2.1 (Prossimo)
- [ ] Integrazione completa Stability AI per immagini
- [ ] Multi-lingua completa
- [ ] Calendar Google integrato
- [ ] Email quick composer
- [ ] Screen recording
- [ ] Smart home controls

### v2.2
- [ ] Mobile companion app
- [ ] Cloud sync notes
- [ ] Plugin system
- [ ] Custom voice training

---

## 🙏 CREDITS

- **Electron** - Framework desktop
- **Globe.gl** - Globo 3D
- **Ollama** - AI locale
- **Three.js** - Rendering 3D
- **Chart.js** - Grafici

---

## ⭐ ENJOY JARVIS!

**"Tutti i sistemi operativi, signore. Cosa combiniamo oggi?"**

🚀 **JARVIS FIRE ULTIMATE** - Il tuo assistente AI del futuro, oggi.
