// JARVIS FIRE ULTIMATE - Electron main process v2.0
const { app, BrowserWindow, globalShortcut, Tray, Menu, shell, ipcMain, nativeImage, screen } = require('electron');
const path = require('path');
const os = require('os');
const { exec } = require('child_process');
const fs = require('fs');

let mainWin = null;
let tray = null;
let isHudVisible = true;

// Ensure single instance
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); return; }
app.on('second-instance', () => { if (mainWin) { mainWin.show(); mainWin.focus(); }});

function createWindow() {
  mainWin = new BrowserWindow({
    width: 1600, height: 1000,
    minWidth: 1200, minHeight: 800,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    icon: path.join(__dirname, 'assets', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false, // For globe.gl and external resources
    },
  });
  
  mainWin.loadFile('index.html');
  
  // Uncomment for dev
  // mainWin.webContents.openDevTools();
  
  mainWin.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault();
      mainWin.hide();
      isHudVisible = false;
    }
  });
  
  mainWin.on('show', () => {
    isHudVisible = true;
    mainWin.webContents.send('hud:visible', true);
  });
  
  mainWin.on('hide', () => {
    isHudVisible = false;
    mainWin.webContents.send('hud:visible', false);
  });
}

function buildTray() {
  try {
    const iconPath = path.join(__dirname, 'assets', 'icon.ico');
    if (fs.existsSync(iconPath)) {
      tray = new Tray(iconPath);
    } else {
      tray = new Tray(nativeImage.createEmpty());
    }
  } catch (e) {
    tray = new Tray(nativeImage.createEmpty());
  }
  
  const menu = Menu.buildFromTemplate([
    { label: '🚀 Mostra JARVIS', click: () => toggleHud(true) },
    { label: '👁 Nascondi', click: () => toggleHud(false) },
    { type: 'separator' },
    {
      label: '⚡ Avvio automatico Windows',
      type: 'checkbox',
      checked: app.getLoginItemSettings().openAtLogin,
      click: (mi) => app.setLoginItemSettings({ openAtLogin: mi.checked, openAsHidden: true })
    },
    { type: 'separator' },
    { label: '❌ Esci', click: () => { app.isQuiting = true; app.quit(); } },
  ]);
  
  tray.setToolTip('JARVIS FIRE ULTIMATE v2.0');
  tray.setContextMenu(menu);
  tray.on('click', () => toggleHud());
}

function toggleHud(force) {
  if (!mainWin) return;
  const target = typeof force === 'boolean' ? force : !isHudVisible;
  if (target) {
    mainWin.show();
    mainWin.focus();
  } else {
    mainWin.hide();
  }
}

// ===== IPC HANDLERS =====

// Window controls
ipcMain.handle('app:minimize', () => mainWin && mainWin.minimize());
ipcMain.handle('app:close', () => mainWin && mainWin.hide());
ipcMain.handle('app:quit', () => { app.isQuiting = true; app.quit(); });

// External/paths
ipcMain.handle('app:open-external', (_, url) => shell.openExternal(url));

ipcMain.handle('app:open-path', (_, p) => {
  let resolved = p;
  const map = {
    desktop: app.getPath('desktop'),
    documents: app.getPath('documents'),
    downloads: app.getPath('downloads'),
    pictures: app.getPath('pictures'),
    music: app.getPath('music'),
    videos: app.getPath('videos'),
    home: app.getPath('home'),
  };
  if (map[p]) resolved = map[p];
  return shell.openPath(resolved);
});

// Open native apps
ipcMain.handle('app:open-app', (_, appName) => {
  const appPaths = {
    spotify: 'spotify.exe',
    discord: 'Discord.exe',
    vscode: 'Code.exe',
    chrome: 'chrome.exe',
    firefox: 'firefox.exe',
    edge: 'msedge.exe',
  };
  
  const exeName = appPaths[appName.toLowerCase()] || `${appName}.exe`;
  
  // Try to open directly
  return new Promise((resolve) => {
    exec(`start ${exeName}`, (error) => {
      if (error) {
        // Fallback to web version
        const webUrls = {
          spotify: 'https://open.spotify.com',
          discord: 'https://discord.com/app',
          vscode: 'https://vscode.dev',
        };
        if (webUrls[appName.toLowerCase()]) {
          shell.openExternal(webUrls[appName.toLowerCase()]);
          resolve({ success: true, method: 'web' });
        } else {
          resolve({ success: false, error: error.message });
        }
      } else {
        resolve({ success: true, method: 'native' });
      }
    });
  });
});

// HUD control
ipcMain.handle('app:toggle-hud', () => toggleHud());
ipcMain.handle('app:hud-visible', () => isHudVisible);
ipcMain.handle('app:mic-trigger', () => {
  if (mainWin) {
    mainWin.show();
    mainWin.focus();
    mainWin.webContents.send('mic:start');
  }
});

// Autostart
ipcMain.handle('app:autostart-get', () => app.getLoginItemSettings().openAtLogin);
ipcMain.handle('app:autostart-set', (_, on) => {
  app.setLoginItemSettings({ openAtLogin: !!on, openAsHidden: true });
});

// System info (real)
ipcMain.handle('sys:info', () => {
  const total = os.totalmem();
  const free = os.freemem();
  const cpus = os.cpus();
  
  let user = 0, total_t = 0;
  cpus.forEach(c => {
    Object.values(c.times).forEach(t => total_t += t);
    user += c.times.user + c.times.sys;
  });
  
  return {
    platform: os.platform(),
    hostname: os.hostname(),
    arch: os.arch(),
    uptime: os.uptime(),
    cpuModel: cpus[0] && cpus[0].model,
    cpuCount: cpus.length,
    cpuLoad: user / Math.max(1, total_t),
    ramTotal: total,
    ramFree: free,
    ramUsed: total - free,
    ramUsedPct: ((total - free) / total) * 100,
  };
});

// System actions (Windows PowerShell)
function run(cmd) {
  return new Promise(res => exec(cmd, () => res()));
}

ipcMain.handle('sys:vol-up', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]175)"'));
ipcMain.handle('sys:vol-down', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]174)"'));
ipcMain.handle('sys:vol-mute', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"'));
ipcMain.handle('sys:media-play', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]179)"'));
ipcMain.handle('sys:media-next', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]176)"'));
ipcMain.handle('sys:media-prev', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]177)"'));
ipcMain.handle('sys:lock', () => run('rundll32.exe user32.dll,LockWorkStation'));

// Spotify (simplified - opens Spotify URIs)
ipcMain.handle('spotify:search', async (_, query) => {
  // Mock search - in production would call actual Spotify API
  return {
    success: true,
    track: {
      name: query,
      artist: 'Artist',
      uri: `spotify:search:${encodeURIComponent(query)}`
    }
  };
});

ipcMain.handle('spotify:play', async (_, track) => {
  try {
    await shell.openExternal(track.uri || `spotify:search:${encodeURIComponent(track)}`);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('spotify:pause', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]179)"'));
ipcMain.handle('spotify:next', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]176)"'));
ipcMain.handle('spotify:prev', () => run('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]177)"'));
ipcMain.handle('spotify:get-current', () => ({ track: 'Nessun brano', artist: '' }));

// File search (Windows search)
ipcMain.handle('file:search', (_, query) => {
  return new Promise((resolve) => {
    const homeDir = os.homedir();
    exec(`powershell -Command "Get-ChildItem -Path '${homeDir}' -Recurse -Filter '*${query}*' -ErrorAction SilentlyContinue | Select-Object -First 20 | Select-Object FullName"`,
      { timeout: 5000 },
      (error, stdout) => {
        if (error) {
          resolve({ success: false, results: [] });
        } else {
          const lines = stdout.split('\n').filter(l => l.trim() && !l.includes('FullName') && !l.includes('---'));
          resolve({ success: true, results: lines.map(l => l.trim()) });
        }
      }
    );
  });
});

// Screenshot (Windows Snipping Tool)
ipcMain.handle('screen:capture', () => {
  return new Promise((resolve) => {
    exec('snippingtool', (error) => {
      resolve({ success: !error });
    });
  });
});

// ===== APP READY =====
app.whenReady().then(() => {
  createWindow();
  buildTray();
  
  // Global shortcuts
  globalShortcut.register('Control+Alt+J', () => toggleHud());
  globalShortcut.register('Control+Shift+Space', () => toggleHud());
  
  // Mic trigger - Insert key
  globalShortcut.register('Insert', () => {
    if (!mainWin) return;
    if (!isHudVisible) mainWin.show();
    mainWin.focus();
    mainWin.webContents.send('mic:start');
  });
});

app.on('window-all-closed', () => {
  // Keep app running in tray
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});
